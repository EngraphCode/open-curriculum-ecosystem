# Deep Dives: The Six Mechanisms Without Prior Art

**Scope.** Detailed design reports on the six mechanisms the earlier research identified as having no direct prior art in the agent literature: (1) invalidation conditions on tasks, (2) the anomaly ledger, (3) live causal-claim links on artefacts, (4) the counterfactual-competition ritual, (5) the computational Lakatos diagnostic, (6) altitude-diagnosis routing. Each chapter covers: definition, nearest ancestors (to cite and steal from, not reinvent), the design space with a recommended design, concrete implementation for a Claude Code multi-repo setup, how to validate it, and how it fails. A synthesis at the end gives build order and interaction effects.

**Epistemic status.** These are design proposals grounded in cited adjacent literature, not validated results. "No prior art" means none found within bounded searches of a fast-moving literature — strong evidence for the repo-mechanism forms, weaker for the conceptual framings. Citation confidence is graded inline; several 2026 preprints inherited from the earlier reports remain unverified and are marked. British English throughout.

---

## 1. Invalidation Conditions on Tasks

### Definition
A task artefact carries, from the moment of creation, machine-checkable conditions under which the task **ceases to be valid regardless of progress towards completion**. This is distinct from a termination condition (the task is done), a budget cap (effort exhausted), and a blocker (cannot proceed). An invalidated task may be 90% complete, unblocked, under budget, and still dead — because the reason it existed no longer holds.

Three families of condition:
- **Evidence-based**: the justifying hypothesis is weakened or falsified (links to the causal-claim registry, ch. 3).
- **Environment-based**: the world changed — a dependency shipped the feature, a platform deprecated the API, priorities moved.
- **Dominance-based**: a demonstrably cheaper or better route to the same parent outcome has emerged (links to the competition ritual, ch. 4).

### Nearest ancestors
- The **options framework** ([Sutton, Precup & Singh 1999](https://www.sciencedirect.com/science/article/pii/S0004370299000521)) gives temporally extended actions *initiation* and *termination* conditions but nothing that revokes an option's validity mid-execution; the HRL-with-language-subgoals line ([arXiv 2309.11564](https://arxiv.org/abs/2309.11564)) inherits the same gap. Adding invalidation as a third first-class condition is the genuine extension.
- **Tripwires** (Heath & Heath, *Decisive*, 2013): pre-set signals of type dates, budgets, metrics, or patterns that force a decision to be reconsidered. This is the decision-science ancestor; the contribution here is making tripwires *machine-checked attributes of the task artefact* rather than intentions in someone's head.
- **Kill criteria / "definition of dead"** (product-management practice): the complement of definition-of-done. Practitioner concept, no artefact-level enforcement anywhere.
- **Futility stopping in clinical trials** (group-sequential design): interim analyses with pre-registered conditional-power thresholds below which the trial stops. Two transferable ideas: the threshold is set *before* data arrives, and regulators favour **non-binding** futility rules — a fired condition triggers review, not automatic death. This maps directly onto the review-vs-kill design choice below.
- **Shape Up's circuit breaker** ([Basecamp](https://basecamp.com/shapeup/2.2-chapter-08)): default-kill on appetite overrun. This is a *budget-family* invalidation condition institutionalised; the mechanism here generalises it to evidence and dominance families.

### Recommended design
Attach a typed condition list to every task artefact at shaping time:

```yaml
# task frontmatter
claim: CLM-014            # justifying causal claim (ch. 3)
appetite: 6h              # reference-class budget, not agent estimate
invalidates_if:
  - type: evidence
    predicate: "CLM-014 arrow capability->behaviour marked weakened or falsified"
    check: scripts/check-claim-status.sh CLM-014
    on_fire: review        # non-binding: route to fresh-context reviewer
  - type: environment
    predicate: "upstream library X ships native caching (watch release feed)"
    check: scripts/check-upstream.sh
    on_fire: review
  - type: budget
    predicate: "effort > 1.5x appetite"
    check: scripts/check-effort.sh
    on_fire: kill          # binding: circuit breaker
  - type: dominance
    predicate: "competition ritual verdict = overturned"
    on_fire: kill
```

Design choices worth being opinionated about:
- **Binding for budget, non-binding for evidence.** Budget breaches are cheap to measure and expensive to argue about — automate the kill (circuit-breaker logic). Evidence conditions are noisier; a fired evidence condition should route to a fresh-context reviewer, mirroring non-binding futility rules, because the false-positive cost (killing a near-success) is real and asymmetric.
- **Conditions are immutable after tranche start.** The agent executing the task must not be able to edit its own invalidation conditions — enforce via a PreToolUse hook blocking edits to the `invalidates_if` block plus a settings deny-rule for defence in depth (hooks can tighten but never loosen deny rules, per the [Claude Code hooks docs](https://code.claude.com/docs/en/hooks)).
- **At least one evidence-type condition is mandatory.** A task with only budget conditions is a plan that cannot lose on the merits — Popper's complaint applies. Author conditions via a pre-mortem prompt at shaping time ("this task became a rabbit hole / became pointless — why?"), which Klein's prospective-hindsight evidence suggests materially improves failure-mode identification.

### Implementation (Claude Code, multi-repo)
- A `check-invalidation` script runs (a) as a cheap PreToolUse hook every N tool calls, (b) at every Stop-hook boundary, (c) as a CI gate on the tranche's promotion PR.
- The Stop hook refuses a completion claim unless the continuation-decision artefact asserts current invalidation status ("no condition fired" is an explicit, logged assertion, not a default).
- Fired conditions append to the anomaly ledger (ch. 2) with the condition id — killed tasks must produce a salvage record.
- Cross-repo: conditions referencing external state (release feeds, other repos' claim registries) run in the periodic aggregation job rather than per-tool-call.

### Validation
Track per condition-type: fire rate, kill rate, and outcome quality of killed-vs-continued tasks (did later evidence vindicate the kill?). The mechanism has its own kill criterion: if evidence-type conditions fire on fewer than ~1 in 20 tasks after a quarter of use, they are being written vacuously — redesign the authoring prompt, not the enforcement.

### Failure modes
- **Vacuous conditions** — conditions no plausible world satisfies. Mitigate with the mandatory-evidence rule and by having conditions reviewed by a differently-contexted agent at shaping time.
- **Gaming** — the agent completes the task *before* checking, or restructures work to dodge predicates. The Stop-hook assertion requirement plus immutability closes most of this.
- **Stale predicates** — checks referencing moved files or dead feeds silently pass. Treat a check that errors as *fired-for-review*, never as passed.

---

## 2. The Anomaly Ledger

### Definition
An **append-only, cross-task, cross-team, cross-time record of anomalies** — observations inconsistent with a currently held assumption — each linked to the assumption or programme it strains. Its purpose is to defeat the default failure: anomalies vanish into individual task histories and compressed hand-offs, so the organisation never notices that assumption A has now been strained eleven times by six different agents in three repos. Single anomalies are noise; accumulated, clustered anomalies are the primary signal for regime shifts, degenerating programmes (ch. 5), and altitude promotion (ch. 6).

### Nearest ancestors
- **Assumption logs and RAID registers** (project-management practice, PRINCE2 and PMI traditions): assumptions and risks are recorded at project level and reviewed in meetings. Right instinct, wrong mechanics — human-maintained, reviewed sporadically, not linked to artefacts, not append-only, never machine-analysed. No agent-org application found.
- **Blameless post-mortems / incident databases** (SRE practice): organisational learning from failure, but incident-triggered and post-hoc; the ledger captures *sub-incident* anomalies continuously, which is precisely the class of signal post-mortems miss.
- **The negative-results culture in science**: killed work must still yield a valued artefact. The ledger is the operational form: every kill writes a salvage record.
- **DeepMind's virtual agent economies** ([arXiv 2509.10147](https://arxiv.org/abs/2509.10147)) proposes immutable *transaction* ledgers for agent collectives — economic provenance, not epistemic anomalies. Structural precedent for "append-only shared ledger among agents", nothing more.
- Verdict unchanged from the earlier reports: **a cross-time epistemic anomaly ledger for agent organisations has no prior art.** Assumption registries likewise.

### Recommended design
One `ledger/anomalies.jsonl` per repo, plus a periodic cross-repo aggregation. Entry schema:

```json
{"ts": "...", "repo": "...", "tranche": "T-231",
 "assumption": "CLM-014.arrow2",
 "observation": "p95 latency unchanged after cache warm-up in staging",
 "source": "hook:posttooluse|agent|human|ci",
 "severity": "note|strain|contradiction",
 "expected_under_current_model": false,
 "salvage": "cache hit rate is high; latency dominated by serialisation"}
```

Design choices:
- **Plain JSONL in the repo, append-only enforced by CI** (a check that the diff to the ledger file is append-only), not a database. Versioned, greppable, reviewable in PRs, trivially aggregatable across repos. Git notes and external stores add machinery without adding trust.
- **Three population routes.** (a) *Mechanical*, via PostToolUse hooks: test-added-then-modified events, fix-of-fix chains, repeated near-identical diffs (thrashing), budget-threshold crossings, fired invalidation conditions. Observe-only, exit 0 — the hook never blocks. (b) *Agent-authored* at re-authorisation boundaries: the continuation-decision artefact requires an "anomalies observed this tranche" section, which the hook appends. (c) *Human-authored*, cheapest possible syntax.
- **Every entry should link to an assumption** (a claim id from ch. 3). Entries that cannot be linked go to a triage queue rather than being dropped — an unlinkable anomaly is sometimes the first evidence that the claim registry is missing a load-bearing assumption, which is itself a finding.

### Analysis layer
This is where the ledger earns its keep; without it, it is a diary.
- **Clustering by assumption**: entry counts and severity-weighted rates per claim arrow, surfaced in a weekly digest.
- **Change-point detection on anomaly rates**: run Bayesian online change-point detection ([Adams & MacKay 2007, arXiv 0710.3742](https://arxiv.org/abs/0710.3742)) — or CUSUM as the cheap frequentist fallback — on the per-assumption anomaly rate. A detected change-point is the formal version of the framework's question "has the process generating our observations changed?", distinguishing tactical noise from a regime shift. The earlier research found **no published application of change-point/SPC methods to agent-trajectory monitoring** — this remains greenfield, and the ledger supplies exactly the time series those methods need.
- **EVPI triage**: for each hot cluster, ask the one question that guards against ledger-driven rabbit holes — *which decision would change if this cluster were resolved?* No decision, no investigation.

### Validation
Retrospective replay: take historical rabbit-hole and pivot episodes from existing logs, reconstruct what the ledger would have contained, and measure lead time — would clustering have flagged the failing assumption before the human did? That is measurable with data Jim already has.

### Failure modes
- **Spam and alert fatigue** — mechanical hooks over-generate. Severity tiers, digest-not-interrupt delivery, and tuned thresholds; only `contradiction`-severity clusters may interrupt.
- **Goodharting the ledger** — if entry counts become legible signals of diligence, agents will produce them. Never reward entry volume; reward *resolved clusters*.
- **Write-only memory** — the honest historical failure of every rationale/log system: capture without consumption. The mitigation is structural: the Lakatos diagnostic (ch. 5) and altitude router (ch. 6) are mandatory consumers, so the ledger has automated readers from day one.

---

## 3. Live Causal-Claim Links on Artefacts

### Definition
Every durable artefact — task, spec, PR, significant module — carries a **machine-resolvable reference to the causal claim that justifies its existence**: the chain task → capability → behaviour → outcome → impact, with each arrow independently marked `assumed | evidenced | weakened | falsified | superseded`. "Live" is the operative word: CI re-evaluates the links, and when an upstream arrow is downgraded, every downstream artefact resting on it is flagged automatically. This is the mechanism that makes strategic entropy *visible*: work whose justification has died keeps compiling, keeps passing tests, and now also carries a visible dead-claim flag.

### Nearest ancestors
This mechanism has the richest — and most cautionary — ancestry of the six.

- **Design rationale capture** is the direct intellectual ancestor. IBIS (Kunz & Rittel, 1970) structured deliberation as issues, positions, and arguments; [gIBIS (Conklin & Begeman, 1988)](https://arxiv.org/pdf/cs/0504071) built the hypertext tool, and a field deployment [captured over 2,300 requirements and design decisions](https://www.tandfonline.com/doi/abs/10.1080/07370024.1991.9667172) with a deliberately low-tech notation. QOC and later DRED tools followed. The literature's verdict, though, is the important part: rationale capture repeatedly failed in industry because **the capture cost fell on busy humans mid-flow** — the tools didn't fit working methods, so the rationale graph rotted. That objection is the one thing agentic development actually dissolves: when the author is an LLM and the enforcement is a hook, the marginal cost of writing and maintaining structured rationale collapses. This is why a forty-year-old failed programme is worth reviving *now* — the economics flipped, and nobody in the design-rationale lineage has noticed yet.
- **Architecture Decision Records** (Nygard 2011; [adr.github.io](https://adr.github.io/)) contribute the immutability discipline — records are superseded, never edited — and proof that lightweight in-repo decision artefacts survive contact with real teams. But ADRs capture *architectural* choices; the impact hypothesis ("this capability will change that behaviour") is precisely the rationale the earlier research found is most commonly lost.
- **Hypothesis-driven development** exists as a practice essay genre; nothing wires hypotheses into artefacts or checks them mechanically. **As a machine-checked mechanism, no prior art** — the finding stands.

### Recommended design
A claims registry per repo, one YAML file per claim, arrows as first-class objects:

```yaml
# claims/CLM-014.yaml
statement: "Semantic caching reduces p95 latency enough that users complete flow X"
arrows:
  - {from: task, to: capability, status: evidenced, evidence: [ledger:2026-06-12T…]}
  - {from: capability, to: behaviour, status: weakened, evidence: [ledger:2026-07-02T…]}
  - {from: behaviour, to: outcome, status: assumed}
invalidates_if: […]          # ch. 1 conditions live here for the claim itself
superseded_by: null
```

Rules that make it live rather than decorative:
- **Statements are immutable; only arrow statuses change**, and a status change is only valid with an evidence link (a ledger entry, an eval result, a competition verdict). This imports the ADR supersession discipline and blocks silent rationale-rewriting.
- **Orphan check in CI**: a durable artefact entering the promotion gate without a claim reference fails. Start with tasks and specs; extend to modules only once the registry is stable — over-linking early is how rationale systems die.
- **Propagation check in CI**: any arrow downgraded to `weakened`/`falsified` flags every artefact referencing that claim or any claim downstream of it, opening a review item routed by altitude (ch. 6). This is the anti-drift payload: evidence at one level automatically confronts work at every level above it.
- **Authorship separation**: the chain is authored at shaping time — by the human or a separately-contexted agent — and *checked*, not written, by the builder. A builder writing its own justification post-hoc will produce fluent, plausible, unfalsifiable chains; the Duhem–Quine problem deserves better than autocomplete.
- **The runtime probe**: at Stop-hook boundaries, the agent must restate the causal chain from current work to intended impact in one pass. Inability, or degrading coherence across boundaries, is itself logged to the ledger — the "cannot state the causal chain" test operationalised.

### Validation
Two measurable questions. Coverage: what fraction of promoted artefacts carry live (not `assumed`-everywhere) chains after a quarter? Consequence: when arrows were downgraded, did flagged work actually stop or pivot, and how much effort was spent downstream of a dead claim before vs after adoption? The second number is the mechanism's whole justification.

### Failure modes
- **Performative chains** — the historically fatal one. Mitigations above (authorship separation, evidence-gated status changes, mandatory invalidation conditions per claim).
- **Graph sprawl** — one claim per intervention, not per task; chain depth capped at the five canonical arrows; deeper structure means the intervention should be split.
- **Status ossification** — arrows stuck at `assumed` forever. The ledger linkage is the forcing function: clusters against a claim with untouched statuses trigger a review of the claim owner, not just the claim.

---

## 4. The Counterfactual-Competition Ritual

### Definition
At every tranche boundary, the incumbent plan must **beat explicit alternatives before continuation is re-authorised**: achieve the same outcome another way; a different intervention entirely; gather information first; do nothing; stop. The incumbent enters the boundary with sunk context, accumulated artefacts, and role commitment on its side — the ritual exists to strip that structural advantage and make continuation a positive, argued decision rather than the default.

### Nearest ancestors — and why the obvious design fails
This is the mechanism where adjacent evidence most sharply constrains the design, because the naïve implementation — "spin up an agent and prompt it to argue against the plan" — is empirically the wrong one twice over.

- **Nemeth's dissent research**: role-played devil's advocacy fails to stimulate divergent thinking and tends to produce *cognitive bolstering* of the original position, whereas authentic dissent measurably improves thought quality ([Nemeth, Brown & Rogers 2001](https://onlinelibrary.wiley.com/doi/abs/10.1002/ejsp.58); [Nemeth, Connell, Rogers & Brown 2001](https://onlinelibrary.wiley.com/doi/abs/10.1111/j.1559-1816.2001.tb02481.x)). A prompted "now criticise this" clone is the LLM equivalent of a role-played devil's advocate — expect bolstering theatre, not challenge.
- **Escalation of commitment in LLMs** (arXiv 2508.01545, single-model, treat effect sizes as provisional): symmetric peer deliberation drove escalation to 99.2% of trials while asymmetric hierarchy roughly halved it. Symmetric agents *voting* is the second failure mode.
- **Debate evidence**: debate helps when the judge is genuinely weaker or differently informed and the question is verifiable ([Khan et al., arXiv 2402.06782](https://arxiv.org/abs/2402.06782); [Kenton et al., arXiv 2407.04622](https://arxiv.org/pdf/2407.04622) — gains require real information asymmetry).
- **Positive analogues to borrow**: pre-registered kill criteria (ch. 1) as the ritual's decidable questions; the marginal value theorem ([Charnov 1976](https://en.wikipedia.org/wiki/Marginal_value_theorem)) as the continuation criterion — leave when marginal decision-relevant gain drops below the backlog average; Gittins-index logic for portfolios of cheap probes; and the "contra-memo" investment practice (days spent writing why the decision is wrong — a costly, effortful clone of authentic dissent, not ten minutes of role-play).

### Recommended design
Four principles, each traceable to the evidence above:

1. **Asymmetry by construction.** The challenger runs in a fresh context with *different information*: the claims registry, the anomaly ledger, a diff summary, and the backlog — but not the builder's trajectory, and ideally a different model family and tool set. It is advisory to a decision procedure, never a voting peer.
2. **Generate-then-compare, not critique.** The challenger independently derives its own best plan for the parent claim *before seeing the incumbent*, then the two are compared. This sidesteps the role-play problem entirely: independent generation is the closest available approximation to authentic dissent, and it converts the ritual from rhetoric into variation-and-selection.
3. **Verifiable questions only.** The verdict must answer decidable questions: *Which invalidation condition is closest to firing, and what would fire it? State a cheaper causal route and the single probe that would confirm it within budget. What is the marginal expected gain of the next tranche versus the best backlog alternative?* Free-form critique is banned output.
4. **The incumbent bears the burden of proof.** Re-authorisation requires a `COMPETITION.md` verdict; a Stop/SubagentStop hook blocks tranche continuation without one. Scale ritual depth to stakes and irreversibility — a five-minute checklist for a reversible tranche, an overnight probe portfolio before an architectural commitment.

When uncertainty is genuinely high, replace argument with evidence: run two or three cheap parallel probes in separate worktrees (the ch. 6 substrate) and let selection, not debate, pick the winner.

### Validation
The ritual has an unusually clean decorative-failure test: track the **overturn rate** and the downstream value of overturns. A challenger that never overturns is theatre; one that overturns constantly is thrash. Calibrate the trigger threshold against both, and log every verdict to the ledger so the challenger's own calibration is measurable per ch. 2.

### Failure modes
- **Ritual theatre** — verdicts written to be filed. The verifiable-question constraint plus overturn-rate monitoring is the counter.
- **Correlated challenger** — same model, same priors, same blind spots. Different model family, restricted context, and independent generation reduce but do not eliminate correlation; treat residual correlation as a known ceiling.
- **Boundary tax** — the ritual costs real tokens and latency at every boundary. Price it against the documented cost of the alternative: long, polished excursions in the wrong direction. If a tranche is too small to afford the checklist form of the ritual, the tranche boundary is in the wrong place.

---

## 5. The Computational Lakatos Diagnostic

### Definition
A trajectory-level metric distinguishing **progressive** work (sub-tasks that produce novel, corroborated, decision-relevant output) from **degenerating** work (sub-tasks that only patch anomalies the work itself created). Lakatos's core insight transfers cleanly: degeneration is a property of the *series*, not of any single step — so rabbit-hole detection must be trajectory-level, and a single hard step is never, by itself, evidence of a rabbit hole. The diagnostic yields a rolling progressive ratio per tranche, consumed as an alarm signal by the altitude router.

### Nearest ancestors
- **Lakatos (1970)**, *Methodology of Scientific Research Programmes*: progressive programmes generate novel corroborated predictions; degenerating ones accumulate ad-hoc patches. The earlier research found the closest formal work ("Stagnant Lakatosian Research Programmes", arXiv 2404.18307) and **no computational operationalisation for agent trajectories** — the finding stands.
- **The overthinking score** ([Cuadron et al., arXiv 2502.08235](https://arxiv.org/abs/2502.08235)) is the nearest *validated* trajectory metric, but it measures the reasoning–action balance, not output novelty; the two are complementary detectors, and the overthinking score is the natural baseline to beat.
- **Code-churn research** provides the crucial feasibility evidence: relative churn measures computed from version history are highly predictive of defect density ([Nagappan & Ball, ICSE 2005](https://dl.acm.org/doi/10.1145/1062455.1062514)). The methodological lesson — *relative* measures work where absolute ones fail, and repeated-modification patterns recoverable from diffs carry real signal — transfers directly.

### Operationalisation
Classify each sub-task (commit, or tool-call cluster) into event types, mechanically where possible:

| Event | Definition | Mechanical proxy |
|---|---|---|
| NEW-PREDICTION | Asserts previously untested *external* behaviour, and it holds | New test/eval on pre-existing or user-facing surface, passing first time |
| CORROBORATION | A pre-registered expectation (claim arrow, invalidation predicate) met | Claim-status change with evidence link |
| PATCH | Modifies an artefact created earlier in the same tranche to accommodate a failure it caused | Fix-of-fix chains; test-added-then-modified; edits whose target is tranche-created |
| SCOPE-SHIFT | Work crosses the declared file-set/boundary | PreToolUse scope-guard events |
| TOOLING | Internal scaffolding with no external surface | Diff paths |

The core signal is the rolling **progressive ratio** P = (NEW-PREDICTION + CORROBORATION) / (those + PATCH), plus the **self-referential churn ratio**: edits to tranche-created files ÷ edits to pre-existing targets. A tranche drifting towards patching its own artefacts while its external surface stays flat is the degenerating signature — technically excellent, all tests green, strategically inert.

**Alarming**: avoid fixed thresholds. Feed P (or the anomaly-adjusted version, weighting PATCH events that also generated ledger entries) into Bayesian online change-point detection ([Adams & MacKay](https://arxiv.org/abs/0710.3742)); alarm on a detected downward regime change sustained across k windows. This turns "the ratio feels low" into "the process generating this trajectory has changed", which is the claim actually worth interrupting for.

### Validation
This is the mechanism most in need of empirical grounding before trust, and the most testable with data already in hand: label a corpus of known rabbit-hole and known deep-work trajectories from existing multi-repo agent logs; measure precision/recall of the diagnostic against those labels; compare against the overthinking score as baseline; tune the operating point to the org's asymmetric costs (wasted compute vs killed near-breakthrough). Report the trade-off honestly in the BAGEN style — savings on failed trajectories versus success-rate cost — rather than a single accuracy number.

### Failure modes
- **Novelty gaming** — trivial tests added to look progressive. NEW-PREDICTION requires the asserted behaviour to touch a claim-linked external surface; assertions on tranche-created internals score as TOOLING.
- **Legitimate consolidation misread as degeneration** — refactor and cleanup phases are patch-heavy by design. Declared consolidation windows are excluded from alarming (declared *before* the window, or the exclusion becomes the loophole).
- **LLM-as-judge classification bias** — prefer the mechanical proxies; use a judge only for the residual ambiguous events, and audit its labels against human labels quarterly.
- **The consistency-not-correctness ceiling** — internal-state and trajectory signals generally predict whether an agent is *committed*, not whether it is *right*. The diagnostic flags for review; it must never auto-kill above operational altitude.

---

## 6. Altitude-Diagnosis Routing

### Definition
When any detector fires — a fired invalidation condition, a ledger cluster, a Lakatos alarm, a failed gate — classify the failure's **altitude** and route the interrupt accordingly: *operational* (fix the task), *tactical* (wrong task), *strategic* (wrong intervention), *constitutional* (the organisation's own process produced this). The earlier research confirmed no published framework performs this diagnosis; existing work decides *when* to replan (the Goldilocks-frequency result, arXiv 2509.03581, unverified 2026 preprint) but not *at which level* the evidence bites. Mis-routing is the framework's signature pathology in both directions: strategic evidence handled operationally yields a polished wrong thing; operational noise escalated to strategy yields thrash.

### Nearest ancestors
- **Single/double/triple-loop learning** (Argyris; the organisational-learning tradition) supplies the level vocabulary but no decision procedure for classifying a given signal.
- **Aviation CRM**: pre-set decision points ("bottom lines") and cross-checks route in-flight anomalies to pre-agreed responses rather than in-the-moment judgement — the strongest human-factors precedent for *pre-committed* routing tables.
- **Incident severity triage** (SRE): classification-then-routing as operational practice, but keyed on blast radius, not on which hypothesis the evidence bears upon.
- The Bayesian question at the heart of routing — *which hypothesis does this evidence actually update?* — is standard hierarchical-inference hygiene with no agent-org application found.

### Recommended design
Routing is a function of three inputs, all supplied by the other mechanisms — which is the structural point: **altitude routing is the integration layer of the whole architecture.**

1. **Locus**: which claim arrow does the evidence bear upon? (From the causal-claim links, ch. 3. Evidence against task→capability is operational/tactical; against capability→behaviour or behaviour→outcome is strategic.)
2. **Persistence**: first occurrence, recurring within a tranche, recurring across tasks, or recurring across teams/repos? (From ledger clustering, ch. 2. Persistence promotes altitude: a one-off failing test is operational; the same assumption strained across three repos is constitutional.)
3. **Reversibility**: how expensive is it to keep going at the current level if the routing is wrong? (From the tranche's declared commitment profile. Low reversibility promotes altitude and lowers the interrupt threshold.)

The routing table then maps (locus, persistence, reversibility) → response: retry locally · fire/review an invalidation condition (ch. 1) · trigger the competition ritual (ch. 4) · escalate to human · open a constitutional change proposal. Two hard rules: automatic action only at operational altitude — everything above routes to review, honouring the consistency-not-correctness ceiling; and every escalation message must state its claimed altitude, the evidence locus, and the proposed response, so that mis-routings are themselves auditable and become ledger entries. Human attention is reserved for strategic and constitutional altitude, which is what protects the leverage of autonomous teams while restoring value-triggered (not merely blockage-triggered) escalation.

### Implementation
A single `route.py` invoked by hooks on detector events and by the periodic aggregation job for cross-repo clusters. It reads the claims registry and ledger, emits a routing record (itself appended to the ledger), and performs the response's mechanical part — opening the review item, blocking the Stop, or scheduling the ritual. Constitutional-altitude routings open a PR against the rules/skills/hooks themselves — the triple-loop made concrete as a reviewable diff.

### Validation
Route-quality audit: sample routings quarterly and have a human (or fresh-context reviewer) judge whether the altitude was right; track the two mis-routing directions separately, because their costs differ and the tuning that fixes one worsens the other. The router's confidence should gate automation: low-confidence classifications degrade to advisory flags.

### Failure modes
- **Everything-is-operational bias** — locus defaults to the nearest level, persistence data is young, and the router under-promotes. Expected in the first months; the mitigation is trusting ledger clustering as it accumulates rather than tuning promotion aggressiveness by hand early.
- **Constitutional churn** — over-eager promotion turns every bad week into a process rewrite. Constitutional routes should require cross-team persistence *and* human sign-off, matching the framework's principle that the most fundamental commitments change slowest.

---

## Synthesis: Build Order, Substrate, Interactions

**Shared substrate.** All six mechanisms reduce to plain files in the repo plus deterministic enforcement: a claims registry (YAML), an append-only ledger (JSONL), task frontmatter, hooks (PreToolUse guards, Stop-boundary demands, PostToolUse appenders), and CI gates. Nothing requires model-side changes; everything is versioned, reviewable, and cross-repo aggregatable — which is exactly the repo-as-constitution thesis made concrete.

**Dependency-driven build order:**
1. **Claims registry + invalidation conditions** (chs. 3, 1) — the foundation; everything else references claims. Smallest useful version: claims for active interventions only, tasks carrying a claim id and three conditions.
2. **Anomaly ledger** (ch. 2) — observe-only, near-zero risk, and it must start accumulating early because chs. 5 and 6 are data-hungry consumers.
3. **Lakatos diagnostic + altitude router** (chs. 5, 6) — built against a labelled corpus from existing logs; router ships advisory-only until route-quality audits pass.
4. **Competition ritual** (ch. 4) — most expensive per use, and it needs the claims registry and ledger to give the challenger its asymmetric information; premature adoption without them recreates the correlated-clone failure.

**Interaction effects worth designing for, not discovering:** the six mechanisms jointly implement the feedback-routing function R(e) → (level, scope, urgency, confidence, authority) that the framework identified as the missing capability of agent organisations — claims supply *level*, the ledger supplies *scope and urgency*, calibration on ledger/verdict history supplies *confidence*, and the routing table plus human sign-off rules supply *authority*. Conversely, the coupling is the main systemic risk: a corrupted claims registry mis-routes everything downstream, which is why claim statements are immutable, status changes are evidence-gated, and the registry sits behind the same deny-rules as the hooks.

**The discipline that keeps this honest:** every mechanism ships with its own invalidation conditions. The challenger dies if its overturn rate stays decorative; evidence-type task conditions die if they never fire; the diagnostic dies if it cannot beat the overthinking score on the labelled corpus. A framework about killing degenerating programmes should expect to eat its own cooking.

## Caveats
- Design proposals, not validated results; the validation sections are the point.
- Unverified inherited citations are marked (2508.01545 single-model; 2509.03581, 2404.18307 not independently re-verified). Nemeth, Adams & MacKay, Nagappan & Ball, Conklin/IBIS, Sutton-Precup-Singh, Charnov, and the Claude Code/Anthropic documentation links were verified in this session or in the prior reports.
- The strongest genuinely-greenfield claims remain: machine-checked invalidation conditions, the epistemic anomaly ledger, live causal-claim links as enforced artefact attributes, change-point methods on agent trajectories, and altitude diagnosis. The competition ritual and Lakatos diagnostic have rich adjacent ancestry that should be cited when these are eventually written up.
