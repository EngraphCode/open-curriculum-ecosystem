# Impact-Aligned Artificial Organisations

## A framework for constructing self-correcting, research-capable systems of human and artificial agency

**Project synthesis and construction manual**  
**Version:** 0.1 (provisional constitution, `F₀`)  
**Date:** 17 July 2026  
**Status:** Comprehensive synthesis of the project to date; suitable for research, prototyping, critique, and controlled trials—not yet an empirically validated final design.

---

## Document purpose

This document expresses what the **Impact and artificial organisations** project has learned so far and turns that learning into a framework that can be constructed, operated, studied, revised, and applied to impact.

It is intended to do five things at once:

1. state the project’s current theory of impact-aligned artificial organisations;
2. explain the pathologies the theory is designed to address;
3. provide a practical construction and operating manual;
4. define a self-hosting research programme through which the framework can improve itself;
5. preserve direct links to the original intellectual sources informing the work.

The framework is deliberately broader than a workflow for AI agents. It is a proposal for a **multi-scale artificial organisation**: a system of people, agents, tools, projects, evidence, memory, governance, inquiry, and feedback that can pursue impact without mistaking its current tasks, projects, products, methods, or metrics for the purpose itself.

---

## Progressive disclosure: how to read this document

The document is organised in layers so that its richness does not have to be compressed into one slogan.

### Five-minute reading

Read:

- [Executive synthesis](#part-i--executive-synthesis)
- [Constitutional principles](#12-constitutional-principles)
- [Minimum viable construction](#part-v--minimum-viable-construction)

### Twenty-minute design reading

Add:

- [The problem being solved](#part-ii--the-problem-being-solved)
- [The integrated architecture](#part-iii--the-integrated-architecture)
- [The operating cycle](#part-vi--the-operating-cycle)
- [Roles and authority](#part-viii--roles-authority-and-organisational-form)

### Full construction reading

Add:

- [Detailed construction manual](#part-iv--detailed-construction-manual)
- [Artefacts and schemas](#part-vii--artefacts-records-and-memory)
- [Evaluation and safeguards](#part-xi--evaluation-validation-and-safeguards)

### Research reading

Add:

- [Self-hosting research and meta-learning](#part-ix--self-hosting-research-and-meta-learning)
- [Impact, research, and higher-order effects](#part-x--impact-research-and-higher-order-effects)
- [Research agenda and open questions](#part-xiii--implementation-roadmap-and-research-agenda)

### Source reading

Use:

- [Direct links to original sources](#part-xv--direct-links-to-original-sources)
- [Source-to-framework map](#179-source-to-framework-map)

### Detailed table of contents

1. [Part I — Executive synthesis](#part-i--executive-synthesis)
2. [Part II — The problem being solved](#part-ii--the-problem-being-solved)
3. [Part III — The integrated architecture](#part-iii--the-integrated-architecture)
4. [Part IV — Detailed construction manual](#part-iv--detailed-construction-manual)
5. [Part V — Minimum viable construction](#part-v--minimum-viable-construction)
6. [Part VI — The operating cycle](#part-vi--the-operating-cycle)
7. [Part VII — Artefacts, records, and memory](#part-vii--artefacts-records-and-memory)
8. [Part VIII — Roles, authority, and organisational form](#part-viii--roles-authority-and-organisational-form)
9. [Part IX — Self-hosting research and meta-learning](#part-ix--self-hosting-research-and-meta-learning)
10. [Part X — Impact, research, and higher-order effects](#part-x--impact-research-and-higher-order-effects)
11. [Part XI — Evaluation, validation, and safeguards](#part-xi--evaluation-validation-and-safeguards)
12. [Part XII — Worked example](#part-xii--worked-example-an-impact-oriented-digital-programme)
13. [Part XIII — Implementation roadmap and research agenda](#part-xiii--implementation-roadmap-and-research-agenda)
14. [Part XIV — Reference checklists and glossary](#part-xiv--reference-checklists-and-glossary)
15. [Part XV — Direct links to original sources](#part-xv--direct-links-to-original-sources)

---

## Progress and evidence disclosure

The project combines established bodies of theory with original synthesis and untested design proposals. The following labels are used throughout:

- **[Foundation]** — an established idea or result from an external field.
- **[Project synthesis]** — an integration or distinction developed through this project by combining multiple foundations.
- **[Design hypothesis]** — a proposed organisational mechanism whose value remains to be tested.
- **[Operational recommendation]** — a practical implementation candidate derived from the current synthesis.
- **[Open question]** — an unresolved issue that should remain visible rather than being prematurely settled.

These labels are epistemic disclosures, not rankings of importance. A design hypothesis may be highly valuable; it simply should not be represented as already demonstrated.

### What this document does establish

It provides a coherent architecture connecting:

- rational metareasoning;
- hierarchical planning and temporally extended action;
- optimal stopping and switching;
- real-options reasoning;
- model-predictive and supervisory control;
- principal–agent theory and mechanism design;
- Goodhart effects and proxy optimisation;
- information theory and cybernetics;
- Bayesian inference and change detection;
- philosophy of science and causal inference;
- organisational learning, evolutionary search, resilience, distributed systems, and sensemaking;
- research, impact, meta-learning, and constitutional self-modification.

### What this document does not yet establish

It does **not** yet demonstrate that:

- the framework outperforms simpler agent workflows;
- every proposed role must be implemented as a separate agent;
- every project benefits from the same degree of metacontrol;
- the suggested data structures are minimal or optimal;
- higher-order impacts will materialise as intended;
- impact can be reduced to a complete or universally agreed objective function;
- the framework should govern normatively consequential decisions without human and affected-party authority.

The framework must therefore be treated as `F₀`: a versioned, falsifiable, revisable constitution that is itself one competitor in the research programme.

---

# Part I — Executive synthesis

## 1. The central problem

Long-lived AI teams can be highly competent at planning and execution while repeatedly producing the wrong kind of success.

They may:

- chase difficult but low-impact problems down rabbit holes;
- build the wrong product or capability well;
- complete proofs that do not change any consequential decision;
- preserve an implementation after its causal rationale has weakened;
- lose strategic information through repeated delegation;
- treat a task, ticket, project, or metric as the objective;
- escalate only when blocked, not when the work is proceeding smoothly in the wrong direction;
- create detailed local evidence without updating the level at which the underlying mistake exists;
- accumulate internal coherence while becoming less connected to external consequences.

This is not adequately described as a failure of intelligence, planning skill, prompt quality, or occasional reflection. It is a failure of **organisational architecture**.

The organisation makes local completion easier to perceive, reward, coordinate around, and justify than strategic contribution. Once that occurs, competent agents systematically optimise lower-level proxies.

The result can be stated as:

> **The organisation becomes effective at preserving work rather than stewarding impact.**

## 2. The purpose of the framework

The purpose is **not** to identify the one “right job,” project, product, or method.

The purpose is:

> **To steward an evolving relationship between values, inquiry, capability, action, consequences, and learning, so that valuable, legitimate, and durable change becomes more possible over time.**

This formulation preserves several distinctions that must not collapse:

- impact is not identical to work;
- work is not identical to a job;
- research is not merely preparation for “real” action;
- understanding, capability, coordination, institutional change, and reflexive learning are different kinds of contribution;
- direct effects and higher-order effects require different evidence;
- empirical confidence and normative authority are different things;
- a useful framework must be able to discover when it should not be applied.

## 3. Impact is an orientation, not a single target

**[Project synthesis]** Impact is the governing orientation of the organisation, but it should not ordinarily be represented as one scalar objective that subsumes every good.

Impact supplies:

- a reason inquiry and action matter;
- a horizon against which consequences are considered;
- a demand to compare and revise means;
- accountability to affected people and environments;
- a feedback signal for improving future inquiry and action.

It does not imply:

- that every activity needs an immediately attributable outcome;
- that one metric can represent all valuable change;
- that research is only justified by a near-term application;
- that speculative future effects can excuse present harms;
- that an agent with high confidence gains authority to decide what is valuable.

The organisation therefore treats impact as a **plural, causal, temporal, distributed, and normatively governed topology** rather than a single score.

## 4. Research is part of the impact, not outside it

Research has at least four relationships to impact.

### First-order epistemic impact

Research can directly create valuable changes in understanding, explanation, shared language, intellectual agency, and the range of questions or actions people can perceive.

### Enabling or generative impact

Research can create frameworks, capabilities, methods, and infrastructure that alter what other people and projects are able to do.

### Systemic impact

A framework can change how many future projects are selected, governed, stopped, reframed, and learned from. Its effects are distributed across a portfolio rather than located in one output.

### Reflexive impact

Projects influenced by the framework return evidence that changes the research, the framework, and the organisation conducting both.

The recurring structure is:

```text
research
  → framework
    → projects and decisions
      → external consequences and evidence
        → revised research
          → revised framework
```

Research is therefore simultaneously:

- an impact in itself;
- an intervention into the conditions of future impact;
- and a means through which the organisation learns how to become a better steward of impact.

## 5. Definition

> **An impact-aligned artificial organisation is a multi-scale adaptive epistemic-control system that preserves strategically relevant information through delegation, acts through provisional causal models, updates graded beliefs from discriminating evidence, maintains competing explanations and interventions, routes feedback to the level and authority capable of responding, and modifies its actions, strategies, methods, and constitutional structures at rates appropriate to their scope, reversibility, and normative significance.**

A shorter definition is:

> **A self-correcting scientific and productive institution whose tasks remain provisional means, whose evidence can change direction, and whose research and application recursively improve one another.**

## 6. The basic causal hierarchy

The organisation does not assume a direct equivalence between activity and impact. It represents a chain of contestable causal claims:

```text
values and affected parties
  ↓
desired change in the world
  ↓
impact opportunities and candidate pathways
  ↓
portfolio of means
  ↓
interventions and projects
  ↓
capabilities
  ↓
tasks and operations
  ↓
outputs
  ↓
changed behaviours, conditions, or institutions
  ↓
outcomes
  ↓
valuable and harmful effects
  ↓
learning and meta-learning
  ↺
```

Every arrow is a hypothesis. Success at a lower level does not validate all higher levels.

A task can succeed while the capability is unnecessary. A capability can succeed while behaviour does not change. Behaviour can change without producing a valuable outcome. A valuable local effect can still create unacceptable distributional or systemic harms.

## 7. The central decision

At any moment the organisation can exercise agency at several levels:

- continue the current operation;
- modify the task;
- replace the task while preserving the capability or project;
- revise the intervention while preserving the impact aim;
- change the portfolio of means;
- reframe the impact opportunity;
- conduct a bounded investigation;
- defer commitment;
- enable another actor instead;
- stop;
- or question the values, legitimacy, or authority underlying the effort.

The central metacontrol question is:

> **At what level should agency presently be exercised?**

## 8. The operating logic

The core cycle is:

```text
ORIENT → COMPETE → COMMIT → EXECUTE → OBSERVE → ROUTE
       → UPDATE → RE-AUTHORISE → RETAIN → ORIENT …
```

- **Orient:** identify purpose, affected parties, context, uncertainty, and authority.
- **Compete:** compare the incumbent with alternatives, including no action and non-work means.
- **Commit:** choose a bounded, reversible tranche with predictions and stop conditions.
- **Execute:** act without reopening every decision at every moment.
- **Observe:** capture external effects, internal behaviour, anomalies, costs, and harms.
- **Route:** move evidence to the right abstraction level, scope, and decision authority.
- **Update:** revise claims, causal models, confidence, and programme status.
- **Re-authorise:** explicitly continue, modify, switch, reframe, defer, or stop.
- **Retain:** preserve the decision, rationale, evidence, alternatives, anomalies, and transfer conditions.

## 9. A self-hosting framework

The current framework is frozen as `F₀`, not declared true.

It should help generate and test candidate successors:

\[
F_{n+1}
=
G\left(
F_n,
E_{\text{application}},
E_{\text{research process}},
A_{\text{anomalies}},
C_{\text{counterfactuals}}
\right)
\]

where `G` is a controlled constitutional gate.

The organisation must not silently rewrite itself in place. It should:

1. preserve the incumbent version;
2. state the proposed change as a hypothesis;
3. predict benefits, risks, and boundary conditions;
4. test the change in a sandbox or bounded application;
5. compare it with the incumbent and credible alternatives;
6. use holdout cases where possible;
7. promote, revise, reject, or roll back the change;
8. retain the evidence and decision.

## 10. The combined objective

The project previously expressed organisational value as:

\[
\text{value}
=
\text{impact created}
+
\text{decision-relevant learning}
-
\text{cost, harm, and lock-in}
\]

That remains a useful decision scaffold, but the components should normally be retained as a vector rather than prematurely collapsed into one number:

\[
\mathbf{V}(p)
=
\left\langle
I_{\text{realised}},
K_{\text{epistemic}},
C_{\text{capacity}},
S_{\text{systemic}},
L_{\text{legitimacy}},
-O_{\text{opportunity cost}},
-H_{\text{harm}},
-R_{\text{lock-in}}
\right\rangle
\]

Plural judgement is unavoidable. The framework makes that judgement more explicit, evidence-linked, and contestable; it does not pretend to eliminate it.

## 11. The theory in one sentence

> **Delegate hypotheses and intended effects rather than fixed work; preserve decision-relevant context; act in bounded tranches; make counterfactuals, reframing, and stopping legitimate; attach evidence to causal claims; route it to the correct level of authority; and version the organisation’s own learning process so that research, action, and impact recursively improve one another.**

## 12. Constitutional principles

These are the current proposed invariants of `F₀`.

1. **Impact is an orientation, not a proxy.** No task, project, product, job, method, or metric is the purpose.
2. **Purpose remains plural and governed.** Empirical optimisation does not silently settle normative questions.
3. **Every task is a provisional option.** It has initiation, continuation, invalidation, and termination conditions.
4. **Delegate causal responsibility, not merely activity.** Agents receive intended effects, hypotheses, constraints, and authority boundaries—not only task descriptions.
5. **The incumbent must compete.** Alternatives include modifying, switching, enabling another actor, delaying, and taking no action.
6. **Continuation is a positive decision.** Work does not continue merely because it already exists or is not blocked.
7. **Reframing is a legitimate local action.** Agents must be able to challenge the problem representation, not only execution details.
8. **Evidence attaches to claims.** An output becomes evidence only relative to a prediction, causal edge, or decision.
9. **Feedback is routed, not merely accumulated.** Information must reach the level and authority capable of responding.
10. **Context is compressed by decision loss.** Handoffs preserve what could change the recipient’s choice, not every detail and not merely a short summary.
11. **Confidence and authority remain separate.** Certainty does not grant legitimacy; authority does not substitute for evidence.
12. **Research is protected as contribution and infrastructure.** Foundational inquiry is not forced to masquerade as immediate implementation.
13. **Higher-order impact claims remain traceable and uncertain.** Increasing causal reach increases—not decreases—the burden of evidence.
14. **Learning occurs at multiple levels and rates.** Operations can adapt quickly; strategy more slowly; constitutional and normative change require stronger gates.
15. **Self-modification is versioned and reversible.** The organisation does not alter its own constitution by unnoticed drift.
16. **Diversity is retained long enough to test.** Independent alternatives and anomalies are not erased by premature consensus.
17. **External effects remain authoritative.** Internal coherence, task completion, confidence, and artefact quality cannot substitute for consequences in the world.
18. **The framework must compete with simpler alternatives.** It must be able to learn when not to apply itself.

---

# Part II — The problem being solved

## 13. Strategic entropy through delegation

**[Project synthesis]** Strategic intent loses information as it passes through successive representations:

```text
purpose
  → impact thesis
    → strategy
      → project
        → capability
          → task
            → check
```

Each layer compresses the one above it. Compression is necessary, but it can discard:

- why the work matters;
- which causal assumptions make it sensible;
- which alternatives were considered;
- what evidence would invalidate it;
- what trade-offs were accepted;
- who is affected;
- which uncertainties remain;
- and when the delegated agent may reopen a higher-level decision.

As lower-level representations become more concrete, they become easier to optimise and coordinate around. The system gradually substitutes the representation for the purpose.

We call this **strategic entropy**: the progressive loss, distortion, or inaccessibility of the information required to choose strategically rather than merely execute locally.

Strategic entropy is not solved by copying the entire conversation into every agent context. That may overwhelm limited attention and produce new failure modes. The solution is **decision-sufficient context**: preserve the information whose omission could change the recipient’s decision.

## 14. Proxy optimisation and Goodhart effects

**[Foundation]** When a measure or reward is an imperfect proxy for a true objective, increasing optimisation pressure can reduce performance on the true objective.

In artificial organisations, proxies include:

- finishing the assigned task;
- passing local tests;
- producing a complete proof;
- satisfying a ticket specification;
- reducing an error metric;
- generating a polished artefact;
- maintaining a plan;
- reporting confidence;
- or keeping activity moving.

The problem is not that these are useless. It is that they are conditionally useful indicators whose relationship to impact may change.

A robust organisation therefore does not ask only whether a proxy improved. It asks:

- which parent claim the proxy was meant to support;
- whether the proxy remains causally connected to that claim;
- whether optimisation has moved into a regime where the proxy becomes misleading;
- and whether a different observation would better discriminate among alternatives.

## 15. Principal–agent problems without malicious agents

**[Foundation + project synthesis]** A long-lived AI team operates in a delegated system. A principal supplies goals, constraints, information, permissions, review structures, and resources. Agents choose many operational actions inside an incomplete contract.

The agents need not be selfish, conscious, or adversarial for principal–agent dynamics to matter. It is enough that:

- the principal’s true objective is difficult to specify completely;
- agents have local information the principal does not;
- progress is easier to observe at some levels than others;
- different roles face different prompts, memories, and success criteria;
- and the organisation rewards or recognises some forms of behaviour more reliably than others.

The system creates a payoff landscape. Competent agents move through that landscape. If task completion is the clearest locally rewarded state, they will rationally preserve tasks even when strategic contribution is uncertain.

## 16. Nested organisational games

The project identified several recurring games.

### 16.1 The proxy game

The principal values impact; the agent can more easily observe and optimise task completion. The lower-level proxy wins unless the contract preserves the causal relationship.

### 16.2 The coordination game

Once several agents coordinate around a plan, the plan becomes a focal point. Departing from it imposes communication and recomposition costs even when the alternative is better.

### 16.3 The signalling game

Continuing work signals competence, momentum, and commitment. Reconsideration may be interpreted as failure or uncertainty, so agents rationally avoid it.

### 16.4 The escalation game

Agents escalate when blocked because blockage is legible. They do not escalate when unblocked but strategically misdirected, because the organisation has not defined that as a reportable condition.

### 16.5 The incumbent game

The incumbent approach accumulates context, code, tests, documentation, and advocates. Alternatives begin with less state and appear artificially costly. This creates endogenous lock-in.

### 16.6 The commitment game

Prior investment changes future incentives. Completing the next step may increase both useful capability and the political, technical, or psychological cost of reversal.

### 16.7 The constitutional game

Roles and rules determine which challenges are safe, who can change direction, what evidence counts, and whether the organisation can modify its own mechanisms. These rules are themselves strategic objects.

## 17. Wrong-level success

A central failure pattern is **correct execution at the wrong conceptual altitude**.

Examples:

- an implementation bug is fixed when the product hypothesis is false;
- a product is improved when a non-product intervention would work better;
- an intervention is scaled when the impact opportunity was misframed;
- a causal model is patched when the research programme has become degenerating;
- an operational agent is asked to solve a normative disagreement;
- a strategic review is triggered by local variance that should have been absorbed by execution.

The organisation therefore needs both:

1. a hierarchy of action;
2. a metacontroller that can decide which level currently deserves attention.

## 18. Rabbit holes as organisational attractors

A rabbit hole is not simply “too much detail.” It is an attractor with several reinforcing properties:

- the next local step is obvious;
- accumulated context makes continuation cheap;
- local progress is measurable;
- completion offers a salient stopping point;
- switching creates immediate coordination cost;
- the wider causal claim is less observable;
- and no role is explicitly responsible for comparing the path with alternatives.

Positive feedback deepens the attractor:

```text
work → context → local competence → apparent progress → more commitment → more work
```

A framework that merely tells agents to “remember the goal” does not change this dynamic. It must alter the decision boundaries, incentives, roles, memory, and evidence routes that make the attractor stable.

## 19. Feedback pathologies

Feedback can fail in several ways.

### Missing feedback

External outcomes are not measured, so local outputs become the only available evidence.

### Delayed feedback

Consequences arrive after many irreversible commitments, making learning expensive.

### Misrouted feedback

Evidence reaches an executor who cannot change strategy, or a strategist receives operational noise that should have been handled locally.

### Over-amplified feedback

Every anomaly causes replanning, creating thrashing and destroying the benefits of sustained execution.

### Under-amplified feedback

Repeated weak signals remain isolated in task histories and never accumulate into a strategic update.

### Level confusion

Evidence of task failure is treated as evidence against the mission, or evidence of strategic failure is treated as a request for another task.

### Normative suppression

Stakeholder harm is compressed into an operational metric and never reaches a protected normative authority.

## 20. Epistemic pathologies

An organisation can produce large quantities of information while learning little.

Common failures include:

- evidence stored as documents rather than linked to claims;
- investigations without a plausible observation that would change anything;
- explanations that accommodate every result retrospectively;
- confidence without calibration;
- local tests that do not discriminate among causal models;
- anomalies discarded as noise by each individual project;
- summaries that remove assumptions, alternatives, or invalidation conditions;
- consensus produced by shared context rather than independent convergence;
- narrative continuity mistaken for explanatory progress;
- and research output assessed by volume rather than the future decisions it improves.

## 21. The danger of reducing impact to “the right job”

A framework can avoid confusing tasks with outcomes yet repeat the same mistake one level higher by treating paid work, product building, or career selection as the default container for impact.

This collapses:

- normative orientation into occupational choice;
- a field of possible causal pathways into one intervention class;
- research into preparatory overhead;
- institutional and collective agency into individual action;
- indirect and recursive effects into immediate attribution.

The framework must therefore be **means-neutral**. Work is one possible intervention among:

- research;
- building products or institutions;
- employment and entrepreneurship;
- funding, investment, and procurement;
- teaching and capability development;
- convening and coordination;
- policy and civic participation;
- communication and culture;
- caregiving and relationship-based action;
- changing personal or organisational practice;
- enabling another actor;
- preserving options;
- restraint, refusal, delay, or no action.

## 22. Higher-order impact and attribution risk

Research and frameworks may have effects through multiple mediating transformations:

```text
research → framework → project → decision → intervention → outcome
```

Potential reach may increase with causal depth, but attribution confidence ordinarily decreases and the evidence burden increases.

The framework therefore distinguishes:

- **causal order of impact:** how many transformations mediate an external effect;
- **order of learning:** whether feedback changes an operation, strategy, constitution, or the process by which the constitution changes.

These dimensions interact but are not identical.

Higher-order impact should be represented as a chain of explicit contribution claims with uncertainty at every edge—not as a speculative multiplier that converts any research activity into unlimited expected value.

---
# Part III — The integrated architecture

## 23. The organisation as a multi-scale system

The framework combines several kinds of system that are often designed separately:

- a **normative system** that determines what kinds of change are valuable and legitimate;
- an **impact system** that identifies opportunities and causal pathways;
- a **portfolio system** that allocates scarce agency among possible means;
- a **planning and execution system** that turns interventions into bounded action;
- a **metacontrol system** that decides when to continue, investigate, switch, or step back;
- an **epistemic system** that represents claims, uncertainty, evidence, and anomalies;
- a **research system** that produces and tests generalisable understanding;
- an **organisational system** that distributes roles, information, incentives, and authority;
- a **constitutional system** that governs how those mechanisms may change;
- a **memory system** that allows learning to survive projects, agents, and versions;
- an **ecosystem interface** that remains accountable to people and environments beyond the organisation.

The framework fails if any one of these is treated as the whole.

## 24. Layered architecture

The proposed architecture contains ten connected layers.

| Layer | Governing question | Typical outputs | Typical authority |
|---|---|---|---|
| **1. Normative orientation** | What changes are valuable, for whom, and who has standing to judge? | values, affected-party map, constraints, legitimacy process | humans and affected-party governance |
| **2. Impact opportunity** | Which conditions or opportunities deserve attention? | impact thesis, problem framing, neglected uncertainties | impact steward with normative oversight |
| **3. Agency and means** | Through which forms of action can this organisation contribute? | means map, comparative advantage, enablement options | portfolio authority |
| **4. Portfolio** | How should time, capital, attention, reputation, and capability be allocated? | active, exploratory, deferred, and stopped programmes | portfolio authority |
| **5. Intervention strategy** | What causal mechanism could create the desired change? | theories of change, rival interventions, assumptions | strategy authority |
| **6. Programme and product** | Which coherent capabilities or projects implement the intervention? | programme hypotheses, roadmaps, product/service/research designs | programme authority |
| **7. Task and operation** | What bounded action should happen now? | task options, execution plans, local controls | operational agents within delegation |
| **8. Evidence and metacontrol** | What has changed, what does it imply, and at what level should agency be exercised? | evidence events, belief updates, review triggers, re-authorisations | distributed, with escalation by scope |
| **9. Research and meta-learning** | What generalisable knowledge and improved learning methods are being produced? | claims, experiments, transfer hypotheses, method findings | research authority with independent evaluation |
| **10. Constitutional and normative adaptation** | How may roles, rules, memory, objectives, or values change? | versioned constitutional proposals and normative decisions | protected constitutional and human authority |

These layers are not a strict command hierarchy. Evidence can travel upward, downward, and laterally. An operational agent may discover a strategic anomaly; a stakeholder may directly trigger normative review; a constitutional experiment may change how evidence is routed across all programmes.

## 25. The architecture as nested feedback loops

A useful model is a set of loops with different objects and adaptation rates.

### Operational loop

**Object:** immediate execution.  
**Question:** Are actions behaving as intended?  
**Typical cadence:** continuous or very frequent.  
**Permitted change:** parameters, local tactics, error correction.  
**Escalation condition:** evidence that the task or capability is invalid, unsafe, or outside delegation.

### Tactical loop

**Object:** task sequence and local approach.  
**Question:** Is this still the best way to deliver the capability?  
**Typical cadence:** at task boundaries or triggered by anomalies.  
**Permitted change:** reorder, replace, split, simplify, or abandon tasks.

### Programme or product loop

**Object:** the capability or coherent intervention implementation.  
**Question:** Is the programme producing the behaviour or condition change expected?  
**Typical cadence:** at bounded tranche boundaries and external evidence events.  
**Permitted change:** revise product, service, research programme, or delivery mechanism.

### Strategic loop

**Object:** theory of change and portfolio.  
**Question:** Is this intervention still a promising route to impact compared with alternatives?  
**Typical cadence:** slower, with event-triggered exceptions.  
**Permitted change:** switch interventions, reallocate resources, reframe opportunities.

### Research loop

**Object:** causal and explanatory knowledge.  
**Question:** Which hypotheses are supported, weakened, or newly possible, and what should be investigated next?  
**Typical cadence:** experiment and synthesis boundaries.  
**Permitted change:** revise claims, methods, programmes, and transfer hypotheses.

### Constitutional loop

**Object:** organisational rules, roles, permissions, memory, and feedback architecture.  
**Question:** Is the system’s way of deciding and learning producing better future decisions?  
**Typical cadence:** deliberately slower and evidence-gated.  
**Permitted change:** versioned mechanisms and organisational form.

### Normative loop

**Object:** values, legitimacy, distribution, standing, and acceptable harm.  
**Question:** Is the organisation pursuing the right kind of impact in a legitimate way?  
**Typical cadence:** protected periodic review plus immediate triggers for material harm or exclusion.  
**Permitted change:** mission constraints, affected-party representation, rights, red lines, and authorisation.

## 26. Feedback has multiple coordinates

Every evidence event should be classified along at least these dimensions:

| Dimension | Example values | Why it matters |
|---|---|---|
| **Abstraction level** | operation, task, capability, intervention, impact, constitution, norm | determines what may need to change |
| **Scope** | local component, project, programme, portfolio, organisation, ecosystem | determines who needs to know |
| **Time horizon** | immediate, near-term, delayed, generational | prevents short feedback from dominating long effects |
| **Confidence** | speculative, weak, moderate, strong, replicated | affects update magnitude, not authority by itself |
| **Novelty** | expected, anomaly, contradiction, change-point | affects review priority |
| **Decision relevance** | none known, monitoring, threshold-relevant, decision-changing | prevents evidence accumulation without use |
| **Reversibility** | easy, costly, irreversible | determines required scrutiny |
| **Value and risk** | benefit, harm, distribution, legitimacy, externality | connects empirical observation to normative review |
| **Provenance** | observed, inferred, reported, generated, simulated | supports verification and audit |
| **Urgency** | routine, time-sensitive, safety-critical | determines routing latency |

A feedback system that stores these attributes can route information more intelligently than one that merely writes a summary into a project log.

## 27. Downward and upward causation

Downward information includes:

- values and constraints;
- impact hypotheses;
- authority boundaries;
- priorities;
- budgets and effort ceilings;
- risk tolerances;
- predictions and stop conditions.

Upward information includes:

- outputs and external effects;
- anomalies and contradictions;
- unanticipated affordances;
- evidence of stakeholder harm;
- model misspecification;
- evidence that a lower-cost alternative exists;
- evidence that the current abstraction level is wrong;
- information about the organisation’s own behaviour.

The architecture should prevent either direction from dominating. Pure top-down control becomes brittle and suppresses discovery. Pure bottom-up adaptation loses coherence and can optimise whatever is locally salient.

## 28. Positive and negative feedback

Negative feedback stabilises:

- deviation correction;
- safety constraints;
- budget limits;
- error handling;
- calibration;
- quality control.

Positive feedback amplifies:

- promising discoveries;
- reusable capabilities;
- validated interventions;
- productive research programmes;
- network and learning effects.

Both can be pathological.

Unbounded positive feedback creates rabbit holes, lock-in, hype, and monoculture. Excessive negative feedback creates stagnation, risk aversion, and perpetual review.

**[Design hypothesis]** Positive feedback should be bounded by prospective predictions, tranche limits, diversity requirements, and explicit re-authorisation. Negative feedback should include hysteresis and severity thresholds so that ordinary variance does not trigger constant strategic change.

## 29. Attractors, metastability, and phase changes

The organisation should be stable enough to execute but able to leave a basin of attraction when evidence warrants it.

- **Attractor:** a self-reinforcing configuration such as “keep building the current product.”
- **Metastability:** a provisional commitment stable within a bounded tranche but open at a decision boundary.
- **Phase change:** a qualitative shift in framing, intervention, organisation, or mission.

A healthy organisation is not maximally fluid. It creates **temporary commitments with designed exits**.

A task, project, or strategy becomes metastable when it has:

- a clear purpose;
- enough autonomy for sustained execution;
- bounded commitment;
- observed indicators;
- predicted decision boundaries;
- and legitimate routes to modification or termination.

## 30. Information-theoretic architecture

### 30.1 Delegation is lossy compression

Every handoff compresses a larger context into a smaller message. The design objective is not maximum fidelity in the abstract; it is minimum **decision loss**.

Let `x` be the full strategic context and `c(x)` a compressed delegation message. A useful conceptual objective is:

\[
\min_c \; D_{\text{decision}}(x,c(x)) + \lambda\,\mathrm{Cost}(c(x))
\]

where `D_decision` measures how much the compression changes the recipient’s likely choice and `Cost` captures attention, latency, and context-window consumption.

### 30.2 Decision-sufficient context

A delegation packet normally needs:

- desired external effect;
- the task’s role in the causal chain;
- key assumptions and confidence;
- credible alternatives considered;
- constraints and protected values;
- expected observations;
- invalidation and stopping conditions;
- authority to modify or reframe;
- information that should be escalated;
- provenance and links to underlying claims.

It need not include every historical detail.

### 30.3 Requisite variety

**[Foundation]** A regulator needs enough response variety to handle the disturbances that matter. If the only legitimate response to difficulty is “try harder,” the organisation lacks requisite variety.

The response set should include:

```text
continue | simplify | split | change task | change method | investigate
switch intervention | enable another actor | defer | reframe | stop
escalate normative concern | propose constitutional change
```

### 30.4 Bottlenecks and observability

An organisational bottleneck exists when strategically important information cannot cross a role, memory, or authority boundary.

Observability requires more than logging. The system should make it possible to infer:

- which causal claim motivated an action;
- what agents believed at the time;
- which alternatives were available;
- what evidence changed the decision;
- which authority approved the commitment;
- and what external effects followed.

## 31. Bayesian and causal architecture

The organisation should represent graded beliefs rather than binary “known/unknown” states.

A claim record should distinguish:

- prior confidence;
- evidence likelihood under the claim;
- evidence likelihood under rivals;
- posterior confidence;
- model uncertainty;
- causal uncertainty;
- normative uncertainty;
- and the decision sensitivity to each.

A simple update is:

\[
P(H\mid E)
\propto
P(E\mid H)P(H)
\]

but practical organisational updating requires a set of rival hypotheses, not only one hypothesis and its negation.

### 31.1 Hierarchical beliefs

Evidence may update different levels:

- task reliability;
- capability usefulness;
- intervention mechanism;
- target population or context;
- strategic opportunity;
- constitutional mechanism;
- normative premise.

The organisation should avoid automatic upward promotion. A failed test may only show that one implementation is broken. Repeated failures across implementations may challenge the capability. Cross-context anomalies may challenge the causal model.

### 31.2 Change-points

Some evidence suggests ordinary variation; other evidence suggests the data-generating process has changed.

**[Operational recommendation]** Track possible change-points in:

- user behaviour;
- project environment;
- stakeholder needs;
- model capability;
- regulation or infrastructure;
- organisational behaviour;
- and the validity of the current impact thesis.

Change-point evidence should trigger model reconsideration rather than only parameter adjustment.

### 31.3 Causal claims

Every intervention claim should specify:

- treatment or action;
- target system and context;
- expected mechanism;
- affected outcomes;
- time horizon;
- counterfactual;
- mediators;
- confounders and selection effects;
- possible harms and spillovers;
- evidence that would distinguish the mechanism from alternatives.

The framework generally speaks of **contribution**, especially at higher causal orders, rather than claiming exclusive attribution.

## 32. Philosophy-of-science architecture

The artificial organisation is partly a distributed scientific institution. Its methods should embody several complementary traditions.

### Falsifiability and severe testing

A useful programme makes predictions that expose it to failure. A test is stronger when the observed result would have been unlikely if the claim were false and when plausible alternatives predict differently.

### Duhem–Quine caution

A failed prediction does not identify which assumption failed. The organisation must represent auxiliary assumptions rather than declaring the highest-level theory false after every local anomaly.

### Research programmes

A programme can protect a stable core while revising auxiliary hypotheses, but continued protection must produce new explanatory, predictive, or practical power.

A **progressive** programme:

- generates novel predictions;
- explains anomalies without arbitrary patches;
- transfers to new cases;
- improves decisions or understanding;
- opens productive new investigations.

A **degenerating** programme:

- explains failures only retrospectively;
- adds complexity without new discrimination;
- repeatedly misses prospective milestones;
- becomes dependent on favourable internal narratives;
- survives mainly through accumulated investment or identity.

### Paradigms and modes of inquiry

Normal problem-solving inside a framework and exceptional reframing of the framework require different organisational modes. The framework should not demand paradigm review after every error, but it must make paradigm challenge possible when anomalies accumulate.

### Explanatory pluralism

Different models can be useful at different scales. The organisation should preserve enough diversity to avoid treating one representation as complete merely because it is operationally convenient.

## 33. Active learning and experimental design

An action can create value through output, information, or both.

A candidate investigation should be evaluated by its expected ability to improve a future choice:

\[
\mathrm{EVI}(e)
=
\mathbb{E}[\text{decision value after }e]
-
\text{decision value now}
-
\text{cost and harm of }e
\]

This is not a requirement that every investigation produce an immediate operational decision. The refined principle is:

> **Every investigation requires an explicit contribution claim and a bounded learning contract.**

The contribution may be:

- changing an immediate decision;
- discriminating between explanations;
- creating a concept or synthesis;
- developing a research method;
- creating reusable capability;
- opening or closing a research trajectory;
- preserving strategic optionality;
- improving the organisation’s learning process;
- or legitimately increasing shared understanding.

A bounded learning contract states:

- the uncertainty being addressed;
- the intended contribution;
- the observations sought;
- the effort and risk ceiling;
- how progress or degeneration will be recognised;
- and when the investigation will be reviewed.

## 34. Organisational learning

The framework distinguishes several orders of learning.

| Level | Object changed | Example |
|---|---|---|
| **Application learning** | action in the external domain | change a product feature or intervention |
| **Epistemic learning** | beliefs and causal models | reduce confidence in a mechanism |
| **Methodological meta-learning** | research method | replace retrospective review with prospective predictions |
| **Organisational meta-learning** | roles, incentives, memory, feedback | add an independent counterfactual role |
| **Constitutional learning** | process of self-modification | require holdouts before promoting rules |
| **Normative learning** | purpose, legitimacy, affected parties | revise who has standing or what harms are unacceptable |

This overlaps with single-, double-, and triple-loop learning but makes the object of each loop explicit.

A governing rule is:

> **Each level may modify the level below within delegated authority, propose changes to itself, and submit changes to the level above; it may not silently redefine its own ultimate authority.**

## 35. Evolution, diversity, and resilience

The organisation needs **variation, selection, and retention**.

- **Variation:** independent framings, alternative causal models, different intervention classes, and dissenting forecasts.
- **Selection:** discriminating evidence, external outcomes, constraints, and legitimate judgement.
- **Retention:** memory of what worked, what failed, scope conditions, abandoned alternatives, and unresolved anomalies.

Premature convergence reduces adaptive capacity. Endless variation prevents action. The organisation should maintain a portfolio:

- an incumbent programme;
- credible challengers;
- exploratory probes;
- dormant options;
- and a no-action baseline.

Resilience is not merely resisting disturbance. It includes the capacity to:

- absorb ordinary variation;
- detect model failure;
- adapt before catastrophic evidence arrives;
- degrade gracefully;
- contain local failure;
- recover prior versions;
- and transform when the current regime is no longer viable.

## 36. Distributed-systems analogy

Long-lived AI teams resemble distributed systems in several useful respects.

### Partial observability

No single agent possesses all relevant context. The organisation must make uncertainty and information ownership visible.

### Consistency versus availability

Immediate global agreement may be costly or impossible. Some local work can proceed with eventual consistency; high-impact irreversible decisions may require stronger consensus.

### Fault containment

A low-level mistake should not automatically corrupt strategic memory or constitutional rules. Sandboxes, bounded permissions, and blast-radius limits contain failure.

### Provenance and replay

Decisions should be reconstructable from claims, evidence, versions, and authority. This supports audit and learning without requiring unrestricted access to every internal trace.

### Consensus failure

Agreement among agents that share the same context, prompt, data, and assumptions is correlated evidence—not independent confirmation.

## 37. Sensemaking

Before the organisation can solve a problem, it must construct a workable representation of what is happening.

Sensemaking involves:

- noticing cues;
- framing situations;
- linking cues into a causal story;
- acting to test that story;
- revising the frame when action produces surprise.

A key risk is that execution stabilises a frame simply by creating artefacts around it. The framework therefore separates:

- confidence in an execution plan;
- confidence in the intervention;
- confidence in the problem frame;
- and legitimacy of the intended impact.

---

# Part IV — Detailed construction manual

## 38. Construction overview

Construct the framework from the outside in and from the slowest-changing commitments toward the fastest-changing operations.

```text
constitutional purpose and boundaries
  → impact topology and affected parties
    → causal models and competing pathways
      → authority, roles, and adaptation rates
        → delegation and decision contracts
          → evidence, memory, and routing
            → metacontrol and re-authorisation
              → research and self-modification
                → pilot, comparison, and scaling
```

Do not begin by creating a large collection of agents. Begin by creating the **decision and evidence architecture** the agents will inhabit.

## 39. Step 0 — Define scope, substrate, and boundaries

### Questions

- What human, artificial, organisational, and technical components are inside the system?
- Which external actors and environments can the system affect?
- What resources can it allocate?
- What decisions can it make autonomously?
- Which decisions require human or affected-party authority?
- What harms, rights, regulations, and irreversible actions constrain the design?
- What is the intended duration of the organisation?
- What data and memory may be retained?

### Required output: system boundary record

Document:

- organisational boundary;
- stakeholder and affected-party boundary;
- decision boundary;
- data boundary;
- resource boundary;
- temporal boundary;
- legal and safety boundary;
- explicit unknowns.

### Minimum viable implementation

A one-page boundary record approved by the human principal and reviewed by someone not responsible for delivery.

### Failure signs

- the system can take consequential actions that are not represented in its authority model;
- “user” is treated as the only affected party;
- agent autonomy is described informally rather than by decision class;
- external dependencies are treated as background rather than part of the causal system.

## 40. Step 1 — Write the impact constitution

The impact constitution is not a detailed plan. It is the slow-changing orientation that governs the search for means.

### It should state

- the kinds of valuable change the organisation seeks to contribute to;
- the people, communities, institutions, or environments affected;
- who has standing in interpretation and revision;
- protected values, rights, and red lines;
- unacceptable means and harms;
- how uncertainty and disagreement will be represented;
- how direct, epistemic, enabling, institutional, and reflexive contributions are recognised;
- how normative changes can be proposed and authorised.

### Avoid

- a single unqualified metric;
- equating impact with growth, adoption, revenue, task volume, or employment;
- vague aspirations that cannot constrain choices;
- claims that the organisation itself determines what is valuable without external standing.

### Minimum viable implementation

A constitution with:

1. purpose statement;
2. affected-party map;
3. protected constraints;
4. decision-rights statement;
5. review and amendment process.

## 41. Step 2 — Build an impact topology

Represent impact as a network of contribution types, causal depths, time horizons, and affected groups.

### Impact profile dimensions

\[
\mathcal{I}(p)
=
\left\langle
\text{value type},
\text{causal depth},
\text{time horizon},
\text{scope},
\text{confidence},
\text{reversibility},
\text{distribution},
\text{externalities}
\right\rangle
\]

### Value types

- **Epistemic:** understanding, explanation, discovery, shared language.
- **Practical:** direct change in behaviour or condition.
- **Enabling:** capability, infrastructure, option creation, removal of constraints.
- **Coordinative:** alignment, shared representation, collective agency.
- **Institutional:** rules, incentives, decision systems, durable organisational change.
- **Normative:** inclusion, legitimacy, rights, improved value deliberation.
- **Reflexive:** improvement of the system’s own capacity to learn and act.

### Epistemic status of an impact claim

- possible;
- intended;
- hypothesised;
- prospectively predicted;
- observed;
- causally supported;
- replicated;
- transferred across contexts.

### Operational recommendation

Do not sum all impact claims. Store them as a graph with confidence, evidence, and possible harms at each edge.

## 42. Step 3 — Map agency and compare means

Before selecting a project, identify the forms of agency available.

### Means map

For each possible means, record:

- causal plausibility;
- expected magnitude, duration, and distribution;
- additionality and counterfactual;
- comparative advantage and replaceability;
- neglectedness and opportunity cost;
- reversibility and option value;
- risks, externalities, and legitimacy;
- effects on future capability and agency;
- sustainability for the people and organisation involved;
- evidence that would change the allocation.

### Means to compare

At minimum:

- build or improve a product;
- provide a service;
- conduct foundational, empirical, or applied research;
- translate or disseminate existing knowledge;
- create infrastructure or standards;
- coordinate actors;
- fund, invest, procure, or redistribute resources;
- influence policy or institutions;
- teach or develop capability;
- enable a better-positioned actor;
- change internal practice;
- delay, refuse, or take no action.

### Minimum viable implementation

For each proposed project, include at least:

- the incumbent means;
- one materially different means;
- an enable-another-actor alternative;
- a no-action baseline.

## 43. Step 4 — Construct competing causal models

Do not delegate a project until the organisation can state why it might work.

### Required elements

- desired external outcome;
- target population or system;
- causal mechanism;
- mediating behaviours or conditions;
- assumptions;
- contextual dependencies;
- predicted observations;
- counterfactual;
- alternative mechanisms;
- harms and spillovers;
- confidence by edge;
- what evidence would change the strategy.

### Claim graph

Represent the intervention as linked claims:

```text
C1: If capability X exists in context Y,
    actor A can perform behaviour B.

C2: If A performs B with sufficient quality and adoption,
    condition C changes.

C3: If C changes under constraints D,
    outcome O is likely.

C4: Outcome O constitutes or contributes to valuable impact I
    for affected parties P.
```

Each claim has separate evidence. A passed capability test supports `C1`; it does not by itself establish `C2–C4`.

### Rival models

Require at least one rival explanation or intervention that predicts different observations. Where meaningful, assign separate agents or contexts to develop rivals before deliberation begins.

## 44. Step 5 — Define levels and decision rights

Create an explicit mapping from decision classes to roles and escalation paths.

### Decision classes

- operational parameter changes;
- task selection and replacement;
- capability or product change;
- intervention and portfolio change;
- research-method change;
- constitutional mechanism change;
- normative purpose or constraint change;
- irreversible, high-harm, or rights-affecting action.

### Authority properties

For each class, define:

- who may decide;
- who must be consulted;
- who can veto;
- what evidence threshold applies;
- what budget or blast radius is allowed;
- whether the change is reversible;
- how the decision is logged;
- when re-authorisation is required.

### Rule

High confidence can affect the urgency or strength of a recommendation. It does not change the authority class.

## 45. Step 6 — Design roles as functions

Roles are functions, not necessarily separate agents. A small system may combine them; a consequential system should preserve functional independence where correlated error or conflict of interest matters.

Essential functions include:

- impact and normative stewardship;
- portfolio and strategic choice;
- causal modelling;
- planning;
- execution;
- counterfactual challenge;
- evidence collection and verification;
- evidence routing;
- stakeholder representation;
- research design;
- memory and provenance;
- constitutional review;
- independent evaluation.

Detailed role definitions appear in [Part VIII](#part-viii--roles-authority-and-organisational-form).

## 46. Step 7 — Replace task specifications with delegation contracts

A task instruction says what to do. A delegation contract says why the action is being tried, what authority the recipient has, and what would change the decision.

### Required fields

- parent impact, outcome, and intervention claims;
- intended effect of the delegated work;
- current hypothesis and rivals;
- expected output and expected information;
- constraints and protected values;
- available resources and effort ceiling;
- initiation conditions;
- success, invalidation, and termination conditions;
- authority to modify, simplify, reframe, or stop;
- mandatory escalation triggers;
- decision boundary and re-authorisation owner;
- provenance links.

### Task as an option

A delegated task is treated as a temporally extended option with:

- **initiation set:** when it may begin;
- **internal policy:** how the agent may act;
- **termination rule:** when it ends normally;
- **invalidation rule:** when its causal rationale no longer holds;
- **review rule:** when continuation needs positive authorisation;
- **residual assets:** what may remain useful if the task stops.

## 47. Step 8 — Bound commitment into tranches

Commitment should be sufficient for focused execution but limited enough to preserve learning and reversibility.

### Every tranche should specify

- objective and contribution claim;
- causal hypothesis;
- scope and duration boundary;
- resource ceiling;
- irreversible commitments;
- blast radius;
- predictions and expected evidence;
- stop, switch, and escalation conditions;
- next decision to be made;
- who will evaluate the result.

### Tranche design principles

- spend least where uncertainty is highest and reversibility is low;
- buy information before lock-in where possible;
- increase commitment only after evidence crosses a prospective threshold;
- do not force every tranche to end in a deliverable if its purpose is discriminating learning;
- make sunk effort irrelevant to re-authorisation except where it creates real reusable assets or switching costs.

## 48. Step 9 — Install metacontrol

Metacontrol decides how much attention to allocate to execution, investigation, comparison, reframing, and stopping.

### Meta-actions

\[
a \in \{
\text{continue},
\text{modify task},
\text{switch task},
\text{replan},
\text{investigate},
\text{reframe},
\text{defer},
\text{enable another},
\text{stop}
\}
\]

A useful scaffold is:

\[
V(a)
=
\text{expected contribution}
+
\text{information gained}
+
\text{option value preserved}
-
\text{execution cost}
-
\text{switching cost}
-
\text{harm}
-
\text{lock-in created}
\]

The calculation may be qualitative. Its value is to expose dimensions that local task logic omits.

### Review triggers

Install event-triggered review for:

- evidence contradicting a key causal edge;
- repeated local failure across different implementations;
- diminishing returns or escalating complexity;
- a material context change;
- an approaching irreversible commitment;
- a credible lower-cost alternative;
- stakeholder harm or exclusion;
- an unresolved anomaly threshold;
- failure to produce the prospective prediction of a programme;
- research that no longer produces explanatory, predictive, practical, or option value;
- evidence that agents are operating at the wrong level;
- excessive review overhead or thrashing.

### Hysteresis

To avoid oscillation, require a meaningful threshold to switch away from an incumbent and a separate threshold to switch back. Preserve the reason for the last decision so the organisation does not repeatedly rediscover the same debate.

## 49. Step 10 — Build the evidence-routing system

Evidence should enter a structured event pipeline.

### Pipeline

```text
observation
  → provenance and verification
    → claim linkage
      → classification by level/scope/urgency
        → belief update proposal
          → decision-route selection
            → review or automatic local adaptation
              → retained outcome
```

### Routing rules

- local operational evidence stays local unless it crosses a defined threshold;
- evidence against a parent causal claim travels upward even if the local task succeeded;
- evidence of harm can bypass programme management and reach protected normative review;
- repeated weak anomalies are aggregated across projects;
- constitutional evidence is separated from ordinary product metrics;
- a decision-maker receives the smallest packet that preserves decision quality, with links to deeper evidence.

### Evidence is not self-interpreting

Every evidence event should state:

- which hypotheses it is more or less expected under;
- whether it is confirmatory, disconfirmatory, ambiguous, or a change-point signal;
- what decision it could affect;
- what additional evidence would discriminate further;
- and who is authorised to act on it.

## 50. Step 11 — Construct organisational memory

The organisation needs linked memory, not a warehouse of documents.

Core stores:

1. **Claim–evidence graph** — claims, rivals, support, contradiction, confidence, and provenance.
2. **Causal graph** — intended mechanisms from action to impact.
3. **Decision register** — choices, alternatives, predictions, authority, and reconsideration conditions.
4. **Anomaly ledger** — weak signals that can accumulate across teams and time.
5. **Programme memory** — hypotheses, tranches, assets, results, and scope conditions.
6. **Meta-learning ledger** — findings about methods, roles, incentives, and information flows.
7. **Constitution repository** — versions, proposals, trials, approvals, rollbacks.
8. **Application atlas** — where mechanisms have been tried, with transfer evidence and counterexamples.
9. **Source and provenance registry** — original evidence and intellectual sources.
10. **Normative issue register** — affected parties, harms, disagreements, and resolutions.

Memory should preserve not only the winning narrative but:

- rejected alternatives;
- unresolved anomalies;
- negative results;
- conditions under which an old decision should be reopened;
- and the context that made a finding valid.

## 51. Step 12 — Install research as a first-class organisational function

Research is not a retrospective report attached to execution. It has protected capacity, methods, roles, and outputs.

Each research programme should state:

- contribution claim;
- object hypothesis;
- method hypothesis;
- organisational or constitutional hypothesis where relevant;
- rival programmes;
- prospective predictions;
- bounded learning contract;
- application opportunities;
- epistemic, practical, enabling, and reflexive outputs;
- review and stopping rules;
- transfer and boundary-condition questions.

Detailed design appears in [Part IX](#part-ix--self-hosting-research-and-meta-learning).

## 52. Step 13 — Create a constitutional change process

A constitutional change alters roles, rules, permissions, memory, feedback, incentives, or the process of self-modification.

### Required sequence

1. identify a recurring organisational pathology or opportunity;
2. link it to evidence across cases;
3. propose a mechanism and causal explanation;
4. identify risks, affected parties, and authority;
5. predict observable benefits and side effects;
6. define the scope and rollback plan;
7. test in a sandbox or bounded branch;
8. compare against the incumbent and alternative mechanisms;
9. evaluate on holdout work where possible;
10. approve, revise, reject, or defer;
11. version the constitution and retain the decision.

### Prohibited pattern

Do not allow an agent to alter a constitutional prompt, memory schema, role, reward rule, or authority boundary merely because the local change appears useful. Local evidence may initiate a proposal; it does not confer constitutional authority.

## 53. Step 14 — Instrument the organisation

Instrumentation should make both application performance and organisational behaviour observable.

Capture:

- actions, outputs, and external outcomes;
- time and resources by causal claim;
- task changes and reasons;
- review triggers;
- alternative proposals;
- predictions made before results;
- evidence-routing paths and latency;
- belief updates;
- re-authorisation decisions;
- anomalies;
- stakeholder feedback and harms;
- constitutional version;
- agent, prompt, skill, tool, model, and memory versions where relevant;
- research-method choices;
- transfer and holdout performance.

Avoid unlimited surveillance or retention. Instrumentation must respect data boundaries, privacy, security, and the difference between evidence needed for learning and traces collected merely because they are available.

## 54. Step 15 — Pilot through comparison, not adoption by declaration

The framework should begin as one experimental condition.

### Initial comparative conditions

- **A. Conventional task-based organisation:** ordinary goals, plans, tasks, and reviews.
- **B. Reflection-enhanced organisation:** conventional workflow plus periodic strategic reflection.
- **C. Full `F₀` organisation:** causal delegation, bounded tranches, counterfactual competition, structured evidence routing, re-authorisation, and research memory.

### Initial portfolio

Use:

- three live cases with meaningfully different uncertainty, feedback delay, reversibility, and domain;
- at least one holdout case not used to design a proposed constitutional revision.

### Capture two traces

1. **Application trace:** what happened in the external problem.
2. **Organisational trace:** how information, authority, beliefs, alternatives, and effort moved through the organisation.

### Independent review

The team that designed and executed a mechanism should not be the sole evaluator of whether it worked.

## 55. Step 16 — Scale by demonstrated necessity

Do not instantiate every layer, role, or record at maximum depth for every task.

Scale the framework according to:

- impact and harm magnitude;
- uncertainty;
- irreversibility;
- duration;
- number of agents and handoffs;
- causal distance;
- stakeholder diversity;
- feedback delay;
- regulatory and legitimacy requirements;
- recurrence and transfer value.

A low-risk, reversible task may need a lightweight contract and local review. A long-lived programme affecting many people may need the full architecture.

The framework should reduce decision loss and avoid wrong-direction persistence. If its overhead exceeds those benefits, that is evidence against the current implementation.

---
# Part V — Minimum viable construction

## 56. The minimum viable artificial organisation

A useful first implementation should be small enough to operate and rich enough to test the central theory.

It requires only:

1. one impact constitution;
2. one explicit causal graph for each live programme;
3. one incumbent, one challenger, and a no-action baseline;
4. three functional roles: steward, executor, and challenger/evaluator;
5. delegation contracts rather than bare task lists;
6. bounded tranches with predictions and re-authorisation;
7. a claim–evidence register, decision register, and anomaly ledger;
8. an explicit route for operational, strategic, constitutional, and normative evidence;
9. one protected research allocation;
10. versioning and rollback for framework changes.

## 57. Minimum viable workflow

For every programme:

### Before work

- state the intended contribution and affected parties;
- define the causal chain;
- identify the current intervention, an alternative, and no action;
- state assumptions and confidence;
- define the next bounded tranche;
- record predictions, stop conditions, and authority.

### During work

- execute without constant strategic reopening;
- record material anomalies and external evidence;
- allow local simplification or modification within delegation;
- trigger review when a defined boundary is crossed.

### At the boundary

- compare observations with prospective predictions;
- update claims and rivals;
- examine harms, costs, lock-in, and option value;
- explicitly choose continue, modify, switch, reframe, defer, or stop;
- retain the rationale and conditions for reopening.

### Across programmes

- aggregate anomalies;
- compare transfer conditions;
- evaluate which organisational mechanisms improved decisions;
- propose—but do not silently install—constitutional changes.

## 58. Minimum viable records

A lightweight implementation can begin with seven tables or linked files:

| Record | Minimum fields |
|---|---|
| **Impact constitution** | purpose, affected parties, constraints, authority, amendment process |
| **Claim graph** | claim, parent, rivals, confidence, evidence links, decision relevance |
| **Delegation contract** | intended effect, hypothesis, scope, resources, stop conditions, authority |
| **Evidence log** | observation, provenance, linked claims, level, confidence, route |
| **Decision register** | alternatives, prediction, decision, authority, rationale, reopen condition |
| **Anomaly ledger** | anomaly, recurrence, affected claims, severity, owner, status |
| **Constitution history** | version, mechanism change, prediction, trial, result, rollback |

## 59. First three research questions

The most foundational initial tests are:

1. **Does attaching every task to a live causal claim and credible counterfactual reduce low-impact persistence?**
2. **Which signals best detect that work is being pursued at the wrong conceptual altitude?**
3. **Which elements of strategic context are necessary and sufficient to preserve decision quality through long-lived delegation?**

These test whether purpose survives operationalisation, whether the system knows when to step back, and whether learning persists across agents and time.

---

# Part VI — The operating cycle

## 60. Overview

The operating cycle is deliberately both productive and scientific.

| Stage | Primary question | Required output | Main failure prevented |
|---|---|---|---|
| **Orient** | What change matters, for whom, in what context, and under whose authority? | frame, affected parties, impact profile | solving an unexamined problem |
| **Compete** | What other pathways, explanations, or non-actions are credible? | rival set and counterfactual | incumbent lock-in |
| **Commit** | What bounded action or investigation should be authorised now? | tranche contract | premature irreversible commitment |
| **Execute** | How can the tranche be completed safely and competently? | outputs, local adaptations | paralysis through constant reflection |
| **Observe** | What happened externally and internally? | evidence events and anomalies | proxy-only monitoring |
| **Route** | At which level, scope, and authority does the evidence matter? | routed decision packet | feedback trapped at wrong level |
| **Update** | Which claims and confidence levels should change? | revised claim graph | narrative without learning |
| **Re-authorise** | Continue, modify, switch, reframe, defer, enable another, or stop? | explicit decision | continuation by inertia |
| **Retain** | What should future agents and projects be able to recover? | decision and learning record | repeated forgetting |

## 61. Orient

### Questions

- What change in the world is being considered?
- For whom could it be valuable or harmful?
- Who has standing to interpret those effects?
- What context and history matter?
- What is uncertain: values, facts, causality, implementation, or authority?
- Is the apparent problem an observed condition, a proposed explanation, or an inherited project frame?
- What would happen without action?
- Is this organisation well positioned to contribute?

### Outputs

- impact thesis;
- affected-party map;
- impact profile;
- initial causal frame;
- uncertainty register;
- authority and constraint statement.

### Meta-orientation

When applying the framework to its own research, ask:

- Why was the research problem framed this way?
- What distinctions might the framework itself make invisible?
- Which people or systems are absent from the frame?
- Is the organisation trying to prove its own usefulness or genuinely discriminate among alternatives?

## 62. Compete

### Candidate set

At minimum consider:

- the incumbent intervention;
- a materially different intervention;
- a simpler or lower-cost alternative;
- an enabling intervention directed through another actor;
- research or information acquisition;
- delay or preservation of option value;
- no action;
- a different impact framing where warranted.

### Counterfactual challenger

A challenger should be authorised and resourced to:

- propose rival causal models;
- argue for stopping or reframing;
- identify what the incumbent would need to predict prospectively;
- expose sunk-context advantages;
- search for non-product and non-work pathways;
- identify harms or excluded stakeholders;
- and state when the framework itself is unnecessary.

The challenger is not rewarded for contrarian volume. Its contribution is measured by discriminating alternatives, avoided error, information gained, and improved decisions.

## 63. Commit

Commitment turns an open possibility into a temporary organisational fact.

A commitment should answer:

- what is being authorised;
- which contribution and causal claim justify it;
- what resources and permissions are granted;
- what remains explicitly uncommitted;
- what evidence is expected;
- what lock-in may be created;
- what conditions end or reopen the commitment;
- who owns the next decision.

The default unit of commitment is a **bounded tranche**, not the whole programme.

## 64. Execute

Execution requires local autonomy. The framework should not create an organisation that pauses for strategic deliberation after every atomic action.

Within a tranche, agents may:

- choose methods and tools;
- reorder local steps;
- correct ordinary errors;
- simplify the approach;
- run low-risk tests;
- preserve useful by-products;
- raise anomalies;
- and stop locally when explicit safety or invalidation conditions are met.

Agents should not silently:

- redefine the intended external effect;
- broaden irreversible scope;
- remove protected constraints;
- reinterpret a failure as success by changing the metric;
- alter constitutional authority;
- or suppress evidence that threatens the programme.

## 65. Observe

Observation covers the external domain and the organisation itself.

### External observations

- user or stakeholder behaviour;
- changes in conditions or outcomes;
- adoption and non-adoption;
- harms and distributional effects;
- environmental or institutional response;
- comparator and counterfactual evidence;
- delayed effects.

### Internal observations

- time and resources consumed;
- handoff losses;
- agents’ alternatives and confidence;
- review frequency;
- escalation patterns;
- decision latency;
- evidence-routing failures;
- repeated rabbit holes;
- correlated consensus;
- constitutional overhead.

### Observation discipline

Record raw observations separately from interpretation. Preserve provenance, uncertainty, and missingness. Do not convert absence of evidence into evidence of absence without a sampling model.

## 66. Route

Routing is a control decision.

A route can be:

- local automatic adaptation;
- tactical review;
- programme review;
- strategy and portfolio review;
- research synthesis;
- constitutional proposal;
- protected normative or safety escalation;
- archival retention without current action.

The route should depend on scope, causal relevance, confidence, urgency, reversibility, and authority—not merely severity.

A subtle strategic anomaly may deserve higher routing than a dramatic local error.

## 67. Update

Update the claim graph before updating the plan.

Ask:

- Under which hypotheses was this observation expected?
- Does it discriminate among rivals?
- Which auxiliary assumptions could explain it?
- Is this ordinary variation, model misspecification, or a change-point?
- Does it update an operational, strategic, constitutional, or normative claim?
- Is confidence calibrated to the evidence quality?
- What new predictions follow?
- What remains unresolved?

The update should be explicit enough that another reviewer can disagree with it.

## 68. Re-authorise

Continuation should be one candidate, not the default state.

Possible decisions:

- continue unchanged for another bounded tranche;
- continue with modified predictions or controls;
- change task while preserving the capability;
- redesign the capability while preserving the intervention;
- switch intervention;
- conduct a targeted investigation;
- reduce scope;
- transfer responsibility to another actor;
- defer and preserve options;
- reframe the impact opportunity;
- stop and retain residual assets;
- trigger constitutional or normative review.

### Re-authorisation questions

- What has changed since the last commitment?
- Which prospective prediction was met or missed?
- Is the programme more progressive, less progressive, or merely more elaborate?
- What is the best current alternative?
- What would be lost by stopping, and is that loss real or sunk?
- What additional lock-in does continuation create?
- Who benefits and who bears risk?
- What is the least costly next step that could change the decision?

## 69. Retain

Retention closes the loop.

Preserve:

- the decision and authority;
- beliefs before and after;
- evidence and provenance;
- alternatives considered;
- predicted and actual observations;
- causal interpretation;
- harms and stakeholder input;
- residual assets;
- anomalies and unanswered questions;
- conditions for revisiting;
- transfer hypotheses;
- implications for the framework.

Do not retain only the polished final narrative. The path not taken may be essential to future counterfactual reasoning.

## 70. The recursive research cycle

The same cycle applies to the research process itself.

| Stage | Research-level question |
|---|---|
| **Orient** | Why this research frame, for whose benefit, and what might it omit? |
| **Compete** | What rival theories, methods, or constitutions could explain or investigate the problem? |
| **Commit** | What bounded study could make a meaningful contribution? |
| **Execute** | Run the study while observing method and organisational behaviour. |
| **Observe** | What happened in the domain and in the research organisation? |
| **Route** | Does the evidence update an object claim, method, role, constitution, or norm? |
| **Update** | Which beliefs at each level changed? |
| **Re-authorise** | Continue, revise, switch programme, or propose constitutional change? |
| **Retain** | What generalises, under which conditions, and with what uncertainty? |

---

# Part VII — Artefacts, records, and memory

## 71. Design principle for artefacts

Artefacts should make consequential reasoning recoverable without converting the organisation into a documentation bureaucracy.

A record belongs in the system when it helps at least one of these:

- preserve strategic intent;
- distinguish claims from evidence;
- support a future decision;
- route feedback;
- protect authority or affected parties;
- compare alternatives;
- learn across projects;
- reproduce or audit a result;
- roll back a constitutional change.

The schemas below are reference models. Implement only the fields justified by risk and complexity.

## 72. Impact constitution template

```yaml
impact_constitution:
  version: "0.1"
  purpose: >
    The valuable and legitimate changes the organisation seeks to
    contribute to, expressed without naming a permanent project or metric.
  contribution_types:
    - epistemic
    - practical
    - enabling
    - coordinative
    - institutional
    - normative
    - reflexive
  affected_parties:
    direct: []
    indirect: []
    potentially_excluded: []
    future_or_nonhuman: []
  standing_and_representation:
    who_interprets_value: []
    who_must_be_consulted: []
    protected_escalation_routes: []
  constraints:
    rights: []
    prohibited_means: []
    unacceptable_harms: []
    legal_or_regulatory: []
  authority:
    operational: "..."
    strategic: "..."
    constitutional: "..."
    normative: "..."
  uncertainty:
    value_disagreements: []
    unresolved_facts: []
  amendment_process:
    proposer: "..."
    evidence_requirement: "..."
    approval: "..."
    review_cadence: "..."
  provenance: []
```

## 73. Impact profile template

```yaml
impact_profile:
  id: "I-..."
  contribution_claim: "..."
  value_type: [epistemic, practical, enabling]
  affected_parties: []
  causal_depth: "direct | mediated | distributed | systemic | recursive"
  time_horizon: "..."
  scope: "individual | group | institution | ecosystem"
  epistemic_status: "possible | intended | predicted | observed | supported | transferred"
  confidence: 0.0
  distribution:
    expected_benefits: []
    expected_costs: []
    uncertainty: []
  reversibility: "..."
  externalities: []
  counterfactual: "..."
  evidence_links: []
  next_validation_step: "..."
```

## 74. Contribution claim and bounded learning contract

```yaml
learning_contract:
  id: "LC-..."
  contribution_type: "decision | explanation | concept | method | capability | option | shared_understanding"
  contribution_claim: "This investigation is intended to contribute by ..."
  object_hypothesis: "..."
  rival_hypotheses: []
  method_hypothesis: "This method can discriminate because ..."
  organisational_hypothesis: "Optional: this organisational mechanism will improve learning by ..."
  target_uncertainty: "..."
  prospective_observations:
    supportive: []
    weakening: []
    discriminating: []
  scope_conditions: []
  effort_ceiling: "..."
  risk_and_harm_ceiling: "..."
  review_boundary: "..."
  progressive_signs: []
  degenerating_signs: []
  next_decisions_or_uses: []
  owner: "..."
  evaluator: "..."
```

## 75. Claim record

```yaml
claim:
  id: "C-..."
  text: "..."
  type: "descriptive | causal | predictive | normative | methodological | constitutional"
  level: "task | capability | intervention | impact | organisation | constitution"
  context_and_scope: "..."
  parent_claims: []
  dependent_claims: []
  rivals: []
  assumptions: []
  prior_confidence: 0.0
  current_confidence: 0.0
  confidence_basis: "..."
  supportive_evidence: []
  weakening_evidence: []
  contradictory_evidence: []
  unresolved_anomalies: []
  prospective_predictions: []
  decision_relevance: []
  owner: "..."
  authority_to_act: "..."
  status: "active | weakened | rejected | dormant | superseded"
  provenance: []
```

## 76. Causal edge record

```yaml
causal_edge:
  id: "CE-..."
  from: "action_or_condition"
  to: "behaviour_condition_or_outcome"
  mechanism: "..."
  target_context: "..."
  counterfactual: "..."
  mediators: []
  confounders: []
  moderators: []
  time_delay: "..."
  expected_effect: "..."
  harmful_spillovers: []
  evidence: []
  confidence: 0.0
  falsification_or_weakening_conditions: []
```

## 77. Delegation contract

```yaml
delegation_contract:
  id: "D-..."
  delegate: "agent_or_team"
  parent_claims: []
  intended_effect: "..."
  task_or_option: "..."
  causal_role: "..."
  current_hypothesis: "..."
  credible_alternatives: []
  expected_output: "..."
  expected_information: "..."
  constraints: []
  resources:
    time_or_compute: "..."
    tools: []
    data: []
  authority:
    may_modify: true
    may_simplify: true
    may_reframe_within: "..."
    may_stop_when: []
    must_escalate_when: []
  initiation_conditions: []
  success_conditions: []
  invalidation_conditions: []
  termination_conditions: []
  review_boundary: "..."
  reauthorisation_owner: "..."
  provenance: []
```

## 78. Bounded tranche record

```yaml
tranche:
  id: "T-..."
  programme: "..."
  contribution_claim: "..."
  hypotheses_tested: []
  authorised_actions: []
  explicitly_out_of_scope: []
  resource_ceiling: "..."
  irreversible_commitments: []
  blast_radius: "..."
  predictions_before_execution: []
  expected_information: []
  stop_conditions: []
  switch_conditions: []
  safety_or_normative_triggers: []
  decision_at_boundary: "..."
  owner: "..."
  independent_evaluator: "..."
```

## 79. Evidence event

```yaml
evidence_event:
  id: "E-..."
  timestamp: "..."
  observation: "raw description separated from interpretation"
  source: "..."
  provenance_type: "observed | reported | inferred | simulated | generated"
  verification_status: "unverified | checked | independently_verified"
  linked_claims: []
  expected_under:
    hypothesis_A: 0.0
    hypothesis_B: 0.0
  interpretation: "..."
  level: "..."
  scope: "..."
  confidence: 0.0
  novelty: "expected | anomaly | contradiction | change_point"
  urgency: "routine | time_sensitive | critical"
  value_and_harm_implications: []
  possible_decisions_affected: []
  route: "local | tactical | strategic | research | constitutional | normative"
  recipient: "..."
  follow_up_needed: "..."
```

## 80. Decision register record

```yaml
decision:
  id: "DEC-..."
  question: "..."
  level: "..."
  authority: "..."
  decision_date: "..."
  alternatives:
    - option: "..."
      expected_contribution: "..."
      expected_information: "..."
      costs_harms_lock_in: "..."
  evidence_considered: []
  beliefs_before: []
  decision: "..."
  rationale: "..."
  predictions: []
  dissent_or_uncertainty: []
  commitments_created: []
  next_review: "..."
  conditions_for_reopening: []
  outcome_links: []
  beliefs_after_outcome: []
```

## 81. Anomaly ledger record

```yaml
anomaly:
  id: "A-..."
  observation: "..."
  first_seen: "..."
  recurrence_count: 1
  contexts_seen: []
  linked_claims: []
  possible_levels: []
  severity: "..."
  novelty: "..."
  competing_explanations: []
  aggregation_rule: "..."
  review_threshold: "..."
  owner: "..."
  status: "open | monitoring | explained | incorporated | unresolved"
  implications: []
```

## 82. Re-authorisation record

```yaml
reauthorisation:
  id: "RA-..."
  programme_or_task: "..."
  prior_commitment: "..."
  boundary_reached: "..."
  predicted_vs_observed: []
  claim_updates: []
  incumbent_case: "..."
  challenger_case: "..."
  no_action_case: "..."
  residual_assets: []
  additional_lock_in_if_continued: []
  harms_and_distribution: []
  decision: "continue | modify | switch | investigate | defer | reframe | stop"
  new_tranche: "..."
  authority: "..."
  dissent: []
  conditions_for_next_review: []
```

## 83. Meta-learning record

```yaml
meta_learning:
  id: "ML-..."
  cases: []
  organisational_mechanism: "..."
  intended_effect_on_learning: "..."
  observed_effects:
    decision_quality: "..."
    calibration: "..."
    routing: "..."
    stopping_or_switching: "..."
    overhead: "..."
    harms: "..."
  rival_explanations: []
  scope_conditions: []
  confidence: 0.0
  transfer_hypothesis: "..."
  holdout_test: "..."
  constitutional_implication: "retain | revise | trial | reject | unresolved"
```

## 84. Constitutional change proposal

```yaml
constitutional_change:
  id: "CC-..."
  from_version: "F0.x"
  proposed_version: "F0.y"
  mechanism_changed: "role | rule | permission | memory | feedback | incentive | amendment_process"
  recurring_problem_or_opportunity: "..."
  supporting_cases: []
  causal_explanation: "..."
  proposed_change: "..."
  alternatives: []
  prospective_benefits: []
  prospective_side_effects: []
  affected_parties: []
  authority_required: "..."
  sandbox_scope: "..."
  holdout_plan: "..."
  promotion_criteria: []
  rollback_criteria: []
  evaluator: "..."
  decision_and_evidence: "..."
```

## 85. Normative issue record

```yaml
normative_issue:
  id: "N-..."
  issue: "..."
  affected_parties: []
  who_has_standing: []
  rights_or_values_in_tension: []
  empirical_claims_relevant: []
  value_disagreements: []
  distribution_of_benefit_and_harm: []
  urgency: "..."
  protected_route_used: "..."
  deliberative_process: "..."
  decision_authority: "..."
  resolution: "..."
  unresolved_dissent: []
  review_conditions: []
```

## 86. Source and provenance record

```yaml
source:
  id: "S-..."
  title: "..."
  authors_or_origin: "..."
  publication_date: "..."
  direct_url_or_doi: "..."
  source_type: "primary | review | reference | project_synthesis"
  claims_supported: []
  excerpts_or_locations: []
  limitations: []
  accessed_or_verified: "..."
```

## 87. Application atlas record

```yaml
application:
  id: "APP-..."
  domain: "..."
  context: "..."
  framework_version: "..."
  mechanisms_applied: []
  baseline_or_comparator: "..."
  external_outcomes: []
  epistemic_outcomes: []
  organisational_outcomes: []
  normative_outcomes: []
  unexpected_effects: []
  boundary_conditions: []
  transfer_hypothesis: "..."
  framework_implications: []
  evidence_links: []
```

## 88. Memory views

The same underlying records should support different decision views.

### Executor view

- current intent;
- authorised scope;
- constraints;
- local evidence;
- stop and escalation conditions.

### Strategic view

- causal graph;
- alternatives;
- confidence and anomalies;
- resource allocation;
- external outcomes;
- re-authorisation boundaries.

### Research view

- claims and rivals;
- evidence discrimination;
- programme progress;
- methods;
- transfer and holdouts.

### Normative view

- affected parties;
- distribution;
- rights and constraints;
- disagreements;
- externalities;
- authority.

### Constitutional view

- recurring organisational patterns;
- mechanism trials;
- overhead;
- version differences;
- promotion and rollback evidence.

---

# Part VIII — Roles, authority, and organisational form

## 89. Roles are separable functions

The framework does not require one agent per role. It requires that the functions remain visible and that incompatible functions are separated when stakes justify it.

For example, the same agent may plan and execute a low-risk task. It is less desirable for the same context to originate a strategic theory, implement it, choose the evidence, suppress alternatives, and grant itself constitutional success.

## 90. Impact and normative steward

### Responsibilities

- preserve the impact constitution;
- maintain affected-party and legitimacy processes;
- distinguish empirical confidence from normative authority;
- protect constraints and escalation routes;
- ensure higher-order impact claims remain explicit and contestable.

### Should not

- dictate every operational choice;
- treat stakeholder consultation as another metric to optimise;
- convert value disagreement into a technical confidence score.

## 91. Portfolio steward

### Responsibilities

- compare uses of time, capital, attention, reputation, and capability;
- maintain incumbents, challengers, exploratory options, deferred options, and no-action baselines;
- account for opportunity cost and lock-in;
- reallocate resources at programme boundaries.

### Key output

A reasoned portfolio, not a ranked list produced by a single speculative expected-impact number.

## 92. Strategy and causal-model steward

### Responsibilities

- maintain the theory of change;
- expose assumptions and causal edges;
- connect programmes to external effects;
- propose prospective predictions;
- respond to strategic evidence.

### Key risk

Becoming an advocate for the incumbent rather than a steward of the causal question.

## 93. Programme or intervention lead

### Responsibilities

- translate strategy into coherent bounded programmes;
- manage dependencies and capability development;
- authorise tactical change;
- prepare re-authorisation evidence.

### Key risk

Protecting the programme because accumulated context and identity are concentrated in the role.

## 94. Planner

### Responsibilities

- design tasks as options;
- sequence reversible and informative steps;
- identify dependencies and decision boundaries;
- preserve parent claims in delegation.

### Key risk

Producing plans whose internal completeness obscures uncertainty in the intervention.

## 95. Executor

### Responsibilities

- perform authorised work competently;
- adapt locally within scope;
- record material evidence and anomalies;
- stop or escalate at explicit boundaries;
- preserve residual assets.

### Authority

Execution autonomy should be broad inside the tranche and narrow outside its causal, normative, resource, and blast-radius boundaries.

## 96. Counterfactual challenger

### Responsibilities

- develop independent alternatives;
- challenge the problem frame and incumbent mechanism;
- represent no action, lower-cost action, and enablement pathways;
- demand prospective predictions;
- identify sunk-context and coordination advantages;
- propose discriminating tests.

### Protections

- independent context before exposure to incumbent reasoning where feasible;
- protected budget;
- no penalty merely for challenging;
- evaluation by decision value, not frequency of disagreement.

## 97. Evidence collector and verifier

### Responsibilities

- distinguish observation from interpretation;
- preserve provenance;
- verify material evidence;
- expose missingness and measurement limitations;
- prevent outputs from being promoted into unsupported impact claims.

### Key risk

Optimising measurement availability rather than evidential relevance.

## 98. Evidence router

### Responsibilities

- classify evidence by level, scope, urgency, confidence, reversibility, and value implications;
- aggregate anomalies;
- send decision-sufficient packets to authorised recipients;
- monitor routing failure and latency.

### Key risk

Becoming a gatekeeper that suppresses inconvenient evidence. Protected routes should bypass it where necessary.

## 99. Research steward

### Responsibilities

- maintain contribution claims and learning contracts;
- compare research programmes;
- protect foundational and exploratory inquiry;
- design severe and decision-relevant tests;
- distinguish object findings from method and organisational findings;
- synthesise transfer and boundary conditions.

## 100. Independent evaluator

### Responsibilities

- evaluate predictions against results;
- compare conditions and holdouts;
- inspect selective evidence and post-hoc explanations;
- assess external outcomes and organisational overhead;
- report dissent.

Independence is a matter of information, incentives, authority, and context—not merely a different agent name.

## 101. Memory and provenance curator

### Responsibilities

- maintain linked records and version history;
- preserve rejected alternatives, anomalies, and negative findings;
- support replay and audit;
- prevent summaries from becoming detached from sources;
- manage retention, privacy, and access.

## 102. Constitutional steward

### Responsibilities

- distinguish local improvements from constitutional changes;
- manage proposals, sandboxes, holdouts, versioning, promotion, and rollback;
- monitor constitutional drift and capture;
- protect the amendment process.

The constitutional steward should not have unilateral normative authority.

## 103. Stakeholder or affected-party interface

### Responsibilities

- enable people affected by the organisation to contribute evidence and concerns;
- translate without erasing disagreement;
- protect routes for harm and exclusion evidence;
- make participation and representation limitations explicit.

This role is not a substitute for real participation or governance.

## 104. Decision-rights matrix

| Decision | May propose | May decide | Must review or be informed |
|---|---|---|---|
| Local task method | executor, planner | executor within contract | programme lead if threshold crossed |
| Task replacement | executor, planner, challenger | tactical/programme authority | strategy if parent claim affected |
| Capability or product redesign | programme lead, strategist, challenger | programme/strategy authority | evidence and stakeholder functions |
| Intervention switch | strategist, portfolio steward, challenger | portfolio authority | impact/normative steward |
| Resource reallocation | programme and portfolio roles | portfolio authority | affected programme and constitutional record |
| Research method change | researcher, evaluator | research authority within protocol | constitutional steward if persistent rule changes |
| Constitutional mechanism | any role may propose | constitutional authority | independent evaluator and affected roles |
| Normative purpose or constraint | humans and legitimate affected-party process | protected normative authority | all relevant functions; cannot be delegated silently |
| High-harm irreversible action | authorised humans/institution only | designated authority under law and constitution | independent safety/normative review |

## 105. Organisational patterns

### Small team

A human impact steward may combine portfolio and constitutional authority. One AI team plans and executes; a separately contextualised AI role challenges and evaluates. Records remain lightweight.

### Medium programme

Separate programme leads, evidence routing, research, and counterfactual functions. Use shared claim and decision graphs. Review across projects.

### Large artificial organisation

Use federated programmes with local autonomy, shared constitutional standards, protected normative routes, independent evaluation, cross-programme anomaly aggregation, and explicit consistency policies.

### Ecosystem-level organisation

No single organisation controls all causal pathways. The framework becomes an inter-organisational protocol for claims, evidence, contribution, accountability, and learning rather than a central command system.

---
# Part IX — Self-hosting research and meta-learning

## 106. The framework as subject, method, and constitution

The next stage of the project is not merely to publish the framework. It is to construct a research organisation in which the framework is simultaneously:

- the **subject** being investigated;
- the **method** used to conduct investigations;
- the **constitution** governing the research organisation;
- and one hypothesis competing with alternative organisational designs.

This is a self-hosting arrangement. The framework helps produce evidence about the framework, but it is not permitted to declare its own success merely because the evidence can be narrated in its terms.

## 107. Versioned recursion

Freeze the current synthesis as `F₀`.

For each proposed successor:

\[
F_{n+1}
=
G(F_n, E_a, E_r, A, C)
\]

where:

- `E_a` is evidence from application;
- `E_r` is evidence about the research and organisational process;
- `A` is accumulated anomaly evidence;
- `C` is evidence from counterfactual constitutions or mechanisms;
- `G` is the constitutional gate.

### Rules of versioned recursion

- no in-place silent rewriting;
- all changes have a causal hypothesis;
- predictions precede results;
- evidence is compared with an incumbent and alternatives;
- a bounded trial precedes broad promotion;
- high-impact changes use holdout cases where feasible;
- rollback remains possible;
- the source version and decision remain recoverable;
- normative authority is not acquired through recursive capability.

## 108. Double-entry research

Every research programme keeps two linked accounts.

### Account A: learning about the object

- what was learned about the external domain;
- which causal hypotheses changed;
- what intervention implications follow;
- what remains uncertain.

### Account B: learning about the process of learning

- which framings were fruitful or misleading;
- which methods discriminated effectively;
- where context was lost;
- how roles and incentives affected inquiry;
- whether anomalies were noticed and routed;
- whether the organisation stopped, switched, or persisted appropriately;
- what should transfer to future research.

A programme that creates a domain result but cannot explain how its process affected reliability is incomplete. A programme that creates elaborate meta-learning without a legitimate contribution claim is also incomplete.

## 109. Three linked hypotheses

A mature study should normally state:

### Object hypothesis `H_O`

A claim about the external phenomenon.

> Example: delegating intended effects and causal hypotheses rather than bare tasks reduces low-impact implementation work.

### Method hypothesis `H_M`

A claim about how to learn about the object.

> Example: comparison of causal delegation with conventional task specifications on matched projects will discriminate the mechanism.

### Organisational or constitutional hypothesis `H_C`

A claim about how the research organisation enables reliable learning.

> Example: a separately contextualised counterfactual role and positive re-authorisation gate make abandonment locally legitimate and reduce incumbent bias.

These hypotheses may fail independently. A negative result on `H_O` does not necessarily invalidate `H_M`. A useful object result does not prove `H_C` caused the research quality.

## 110. Four outputs of every programme

Each programme should produce:

1. **Domain finding** — what appeared to work or fail in the application.
2. **Epistemic finding** — which beliefs changed and which evidence caused the change.
3. **Organisational finding** — which mechanisms helped or impeded decision quality and learning.
4. **Transfer hypothesis** — under what conditions the finding may apply elsewhere and where it may fail.

A retained lesson should look like:

> Mechanism `M` improved decision quality under conditions `C`, was inconclusive under `D`, and may fail when `E` is present.

It should not be stored as:

> Always use `M`.

## 111. Research modes and portfolio

A healthy research organisation protects several modes.

| Mode | Primary contribution | Appropriate evidence |
|---|---|---|
| **Foundational inquiry** | concepts, explanations, questions, distinctions | explanatory power, coherence, novelty, fruitfulness |
| **Empirical research** | better-supported beliefs | discrimination, calibration, replication, anomaly resolution |
| **Applied research** | improved current choices | decisions changed, alternatives ruled in/out, bounded trial results |
| **Translational research** | usable movement from knowledge to practice | adoption, usability, transfer, fidelity |
| **Enabling infrastructure** | capability across many projects | reuse, reduced failure, improved future decisions |
| **Constitutional research** | better organisational learning and governance | holdout performance, routing, stopping, reduced recurring pathology |
| **Direct intervention** | external outcomes | counterfactual outcome evidence, harms, distribution |

The portfolio must balance exploration and exploitation. Immediate application alone creates intellectual lock-in. Unbounded inquiry can become detached from consequences. The balance should be governed through explicit contribution claims and programme review, not an assumption that one mode is intrinsically superior.

## 112. Initial research programmes

### 112.1 Causal delegation

**Question:** Does delegating effects and hypotheses rather than tasks preserve strategic alignment and improve stopping or switching?

**Comparisons:** conventional task brief; task brief plus reflection; causal delegation contract.

**Measures:** strategic-context retention, low-impact persistence, external outcome quality, overhead, decision quality.

### 112.2 Metacontrol and stopping

**Question:** Which signals and review policies detect wrong-direction persistence without causing continual replanning?

**Comparisons:** fixed cadence; event-triggered; hybrid; no formal review.

**Measures:** time to detect invalidation, false-positive review rate, lock-in, thrashing, missed opportunities.

### 112.3 Strategic memory

**Question:** What is the minimum context needed to preserve decision quality through long-lived handoffs?

**Method:** ablate purpose, alternatives, assumptions, confidence, invalidation criteria, provenance, and affected-party context.

**Measures:** decision agreement with fully informed reference, error type, attention cost, transfer.

### 112.4 Evidence routing

**Question:** Can observations be reliably routed to the correct abstraction level, scope, and authority?

**Comparisons:** local-only reporting; undifferentiated global escalation; structured routing.

**Measures:** routing accuracy, latency, decision impact, overload, suppressed evidence, harm detection.

### 112.5 Constitutional evolution

**Question:** Can organisational rules and roles improve through controlled self-modification without self-confirmation or drift?

**Comparisons:** frozen constitution; reflection-based in-place change; versioned trials with holdouts and rollback.

**Measures:** future decision quality, recurring pathologies, overhead, rollback frequency, unintended effects.

### 112.6 Transfer and boundary conditions

**Question:** Which mechanisms generalise across domains, uncertainty regimes, and human–AI arrangements?

**Domains:** digital products, scientific research, service design, operations, strategy, grant allocation, institutional change.

**Measures:** effect heterogeneity, scope conditions, negative transfer, adaptation cost.

## 113. Research lattice for innovation

Innovative applications can be generated systematically by crossing mechanisms with contexts.

\[
\text{mechanism}
\times
\text{domain}
\times
\text{organisational level}
\times
\text{timescale}
\times
\text{feedback delay}
\times
\text{reversibility}
\times
\text{human–AI arrangement}
\]

### Mechanisms

- causal delegation;
- decision-sufficient compression;
- counterfactual competition;
- bounded commitment;
- evidence routing;
- anomaly accumulation;
- calibrated belief update;
- independent variation;
- positive re-authorisation;
- versioned constitutional trials;
- protected normative feedback;
- research/application recursion.

### Example generated hypotheses

- A memory system that retains assumptions, rivals, and invalidation evidence will outperform one focused on task history.
- A portfolio process with an independent no-action advocate will avoid more low-value investment than ordinary review.
- Independent initial agent framings will produce more robust strategic alternatives than deliberation from a shared first plan.
- Positive feedback can accelerate productive research without rabbit holes when investment increases are tied to novel prospective predictions.
- Stakeholder harm evidence routed through a protected normative channel will alter consequential decisions more reliably than evidence compressed through programme reporting.
- Constitutional rules tested on holdout tasks will transfer more reliably than rules extracted from retrospective success narratives.

Novelty is not sufficient for priority. Candidate cells should be assessed for potential contribution, information value, transfer, option value, cost, harm, and lock-in.

## 114. Research memory

The research system uses the shared organisational memory but needs additional views:

- claim and rival graph;
- programme genealogy;
- prediction registry;
- method registry;
- negative-result store;
- anomaly clusters;
- transfer matrix;
- application atlas;
- constitutional mechanism history;
- source and provenance map.

A synthesis should be generated from these linked records, not substitute for them.

## 115. Meta-learning definition

The strongest test of meta-learning is prospective:

\[
\text{meta-learning}
=
\text{improvement in future decision quality caused by retained learning}
\]

A lesson that is elegantly documented but does not improve a later choice has not yet demonstrated meta-learning.

Evidence can include:

- improved holdout decisions;
- better calibration;
- faster detection of wrong-level work;
- more appropriate stopping and switching;
- lower information loss in delegation;
- better evidence routing;
- reduced harm or constitutional drift;
- useful transfer to a new domain.

## 116. Safeguards against recursive self-confirmation

### The framework competes

Compare with simpler task-based systems, ordinary reflection, human-led processes, and alternative constitutions.

### Predictions precede results

Record expected benefits, failures, and side effects before trials.

### Creation and evaluation are separated

No single context should originate a mechanism, implement it, select its evidence, and declare it successful.

### External effects remain authoritative

Internal coherence and self-reported agent satisfaction are not sufficient.

### Holdouts are used

Evaluate proposed generalisations on cases not used to invent them.

### Versions and rollback are preserved

The current constitution remains recoverable.

### Adaptation rates remain distinct

Operational learning does not silently become constitutional or normative change.

### The framework may fail the relevance test

Some problems are simple, reversible, well specified, and adequately served by ordinary execution. The framework should identify those cases and stay lightweight.

## 117. Minimum self-hosting cycle

1. Freeze and publish `F₀` with maturity labels.
2. Select three live applications and one holdout.
3. Run conventional, reflection-enhanced, and full-framework conditions where feasible.
4. Capture external and organisational traces.
5. Conduct an independent programme review.
6. Extract object, epistemic, organisational, normative, and transfer findings.
7. Propose `F₁` changes as hypotheses.
8. Sandbox changes and define rollback.
9. Test on the holdout.
10. Promote only changes that improve future decisions or produce another explicit legitimate contribution.

---

# Part X — Impact, research, and higher-order effects

## 118. Impact as a topology

The framework does not ask only, “Did this project achieve impact?” It asks:

- what kind of contribution occurred;
- for whom;
- through which causal path;
- at what depth and time horizon;
- with what confidence;
- with what distribution and externalities;
- and how the evidence changes future agency.

This produces an impact topology: a network of effects and contribution claims rather than a scalar score.

## 119. Orders of causal impact

### Direct impact

The activity itself changes a condition or behaviour.

```text
action → external effect
```

### First mediated impact

The activity enables another actor or project.

```text
research or capability → project decision → external effect
```

### Distributed portfolio impact

The framework changes many projects or allocations.

```text
framework → {P1, P2, …, Pn} → {O1, O2, …, On}
```

### Institutional impact

The framework changes durable rules, incentives, information flows, or authority.

### Recursive or reflexive impact

The effects generate evidence that changes the framework and subsequent projects.

```text
research → framework → projects → effects/evidence
       ↑                              ↓
       └──────── revised research ────┘
```

These categories are descriptive, not automatically additive. The same effect may participate in several paths.

## 120. Orders of learning

Causal depth should not be confused with learning depth.

- **Operational learning:** changes immediate action.
- **Strategic learning:** changes intervention or portfolio.
- **Methodological learning:** changes how evidence is generated.
- **Organisational learning:** changes roles or information flows.
- **Constitutional learning:** changes how organisational mechanisms may change.
- **Normative learning:** changes purpose, legitimacy, or protected constraints.

A direct intervention can generate constitutional learning. A constitutional insight can produce third-order external effects. Record both dimensions.

## 121. Contribution rather than exclusive attribution

At higher causal orders, the organisation should ordinarily claim contribution rather than exclusive attribution.

A contribution claim states:

- the originating input;
- the mediating mechanisms and actors;
- the expected counterfactual;
- the evidence for each edge;
- alternative causes;
- uncertainties and possible negative effects;
- the share of the effect that remains unidentifiable.

This prevents two opposite errors:

- ignoring valuable enabling and systemic effects because they are indirect;
- claiming enormous speculative impact because a framework might influence an unknown future chain.

## 122. Research as first-order impact

Research can itself create valued epistemic states:

- a clearer concept;
- a better explanation;
- a reliable negative result;
- a newly visible problem;
- a shared language that enables coordination;
- a method that makes inquiry more severe or inclusive;
- an archive that preserves knowledge;
- increased capacity for judgement.

These are not necessarily reducible to later product outcomes. They require their own standards:

- truth-conduciveness;
- explanatory and predictive power;
- accessibility;
- novelty and fruitfulness;
- relation to prior work;
- reproducibility and provenance;
- effects on who can know and act;
- opportunity cost and harm.

## 123. Research as generative infrastructure

A framework can alter the production function of future impact by changing:

- what questions are selected;
- how purposes survive delegation;
- which alternatives are considered;
- when projects are stopped;
- how uncertainty is represented;
- who receives evidence;
- what knowledge is retained;
- how institutions learn.

This impact is often spread across projects and time. The appropriate evidence may include:

- adoption and faithful use;
- changed decisions attributable in part to the framework;
- avoided low-value or harmful work;
- improved holdout performance;
- transfer across contexts;
- institutionalisation of useful mechanisms;
- downstream outcomes, with uncertainty retained.

## 124. Means-neutral impact realisation

The framework inserts an explicit impact-realisation layer between purpose and work.

| Stage | Question | Output |
|---|---|---|
| **Normative orientation** | What is valuable and legitimate? | impact constitution |
| **Impact opportunity selection** | Which conditions deserve attention? | opportunity portfolio |
| **Agency and means mapping** | How could this actor contribute? | means map |
| **Portfolio selection** | Which mix of means is currently promising? | allocation |
| **Intervention design** | Through what mechanism? | causal model |
| **Bounded action or inquiry** | What is the next reversible step? | tranche |
| **Impact observation** | What changed relative to alternatives? | evidence |
| **Learning and meta-learning** | What changed in beliefs and capacity? | updates |
| **Constitutional adaptation** | What should change in the framework? | version proposal |

This preserves work, research, care, capital, coordination, restraint, and other forms of action as comparable but non-identical means.

## 125. Standard impact-application output

Every retained research finding should be accompanied, where meaningful, by an impact-application record.

### 1. Learning

What was established, weakened, or left unresolved?

### 2. Impact relevance

What valuable external changes could the learning plausibly support?

### 3. Actor and context

For whom is it actionable, under what conditions, and with what authority or resources?

### 4. Means comparison

How might it be applied through research, work, products, services, capital, communication, policy, community, teaching, enablement, restraint, or other channels?

### 5. Causal pathway

How is the proposed action expected to produce a contribution?

### 6. Bounded application experiment

What reversible action could test usefulness and impact?

### 7. Evidence and counterfactual

What would happen otherwise, and what observation would distinguish success from coincidence or proxy success?

### 8. Harms and legitimacy

Who may benefit or bear costs? Who should participate in the decision?

### 9. Meta-learning

What does the application reveal about how this actor or organisation creates impact?

### 10. Framework implication

Should a method, role, memory structure, evidence standard, or constitutional rule change?

## 126. Validation chain

The framework’s external validation chain is:

```text
framework mechanism
  → different information or authority
    → different decision
      → different action or allocation
        → different external outcome
          → valuable, legitimate impact
```

Each arrow can fail.

- The mechanism may produce no meaningful organisational difference.
- The organisational difference may not change a decision.
- The decision may not be implemented.
- The action may not alter the external system.
- The external effect may be harmful, unfairly distributed, or illegitimate.

Evaluation should identify the earliest unsupported edge rather than narrating the entire chain as achieved.

## 127. Impact and research portfolio

The organisation should not require every programme to have the same impact profile.

A balanced portfolio may include:

- long-horizon foundational inquiry;
- discriminating empirical studies;
- immediate applied research;
- translational work;
- reusable infrastructure;
- constitutional experiments;
- direct interventions;
- dormant options awaiting a change in context.

Portfolio decisions should consider complementarities. Foundational research may create later applied options. Direct intervention may generate anomalies that reshape theory. Infrastructure may lower the cost of many future experiments.

## 128. Evidence discipline for higher-order claims

For every higher-order claim:

1. draw the causal chain;
2. mark observed, inferred, and speculative edges;
3. identify alternative causes;
4. state the counterfactual;
5. record time delay and possible decay;
6. identify harms and displacement;
7. assign confidence per edge, not only to the final story;
8. update as downstream evidence arrives;
9. avoid multiplying uncertain point estimates without sensitivity analysis;
10. preserve the possibility that the research is valuable epistemically even if a downstream application fails.

## 129. Constitutional statement on impact

> **The organisation exists to cultivate, apply, and share understanding that increases the capacity of people, projects, and institutions to contribute to valuable, legitimate, and durable change. It recognises direct outcomes, epistemic advances, enabling capabilities, improved coordination, institutional change, and reflexive learning as distinct forms of contribution. No job, project, product, method, or metric is treated as the objective. Each is a provisional node in an evolving causal and learning network. Research is protected both as a valuable contribution to understanding and as infrastructure for future action. Claims of higher-order impact remain explicit, uncertain, traceable, counterfactually contestable, and accountable to affected people.**

---
# Part XI — Evaluation, validation, and safeguards

## 130. Evaluation must occur at several levels

The framework should not be evaluated by one dashboard. It must be possible for an implementation to perform well at one level and poorly at another.

### Application performance

- Did the intervention create the expected external effect?
- Did it reach the intended people or systems?
- What happened relative to the most credible counterfactual?
- What harms, externalities, and distributional effects occurred?
- Did a simpler means perform as well or better?

### Epistemic performance

- Did the work produce evidence that discriminated among credible rivals?
- Were predictions recorded before results?
- Were confidence estimates calibrated?
- Did the organisation distinguish local failure from model failure?
- How much decision-relevant information was gained per unit of cost and harm?
- Were anomalies preserved and resolved rather than narrated away?

### Decision performance

- Did the organisation select the appropriate abstraction level?
- Did it consider materially different alternatives?
- Did it stop or switch before avoidable lock-in?
- Did it preserve valuable options?
- Did re-authorisation decisions improve when evaluated prospectively or on holdouts?

### Organisational performance

- How much strategic intent survived delegation?
- Were agents able to raise reframing and stopping as legitimate actions?
- Was evidence routed to the correct level and authority?
- Did independent roles provide genuinely different information?
- Did the system avoid both lock-in and thrashing?
- How much coordination and documentation overhead did the framework create?

### Research performance

- Did programmes produce explanatory, predictive, practical, methodological, or option value?
- Did they remain progressive?
- Were negative results retained?
- Did findings transfer with explicit boundary conditions?
- Did the research portfolio preserve both exploration and application?

### Meta-learning performance

- Did retained organisational learning improve future decisions?
- Did a constitutional mechanism outperform the incumbent on holdout work?
- Were recurring pathologies reduced across cases?
- Did the organisation learn where the framework added no value?

### Normative performance

- Were affected parties identified and represented appropriately?
- Did protected concerns reach legitimate authority?
- Were benefits and harms distributed acceptably?
- Did empirical confidence overrun normative uncertainty?
- Were rights and constraints respected even where optimisation pressure was high?

## 131. Suggested measures

Measures should be selected for a specific causal purpose, not adopted wholesale.

### Strategic alignment and intent retention

- agreement between delegated choices and fully contextualised reference decisions;
- frequency and quality of causal-role explanations in task decisions;
- proportion of tasks linked to active parent claims;
- rate at which agents identify invalid parent assumptions;
- decision loss under context ablation.

### Stopping, switching, and lock-in

- time or resources consumed after invalidating evidence first became available;
- rate of positive re-authorisation versus passive continuation;
- switching regret;
- proportion of commitments that remain reversible at review boundaries;
- residual asset value after stopping;
- false-positive and false-negative strategic review rates.

### Evidence quality

- proportion of material claims with linked evidence and rivals;
- prospective prediction coverage;
- calibration score where probabilistic forecasts are feasible;
- discrimination ratio between rival hypotheses;
- time from observation to appropriate decision authority;
- anomaly recurrence before aggregation;
- provenance completeness.

### Diversity and challenge

- number of materially distinct intervention classes considered;
- independence of initial framing contexts;
- rate at which challengers change a decision or improve a test;
- correlated-error indicators;
- diversity retained at key commitment points;
- cost of challenge relative to avoided error and information gained.

### External outcomes and contribution

- observed changes by affected group;
- counterfactual comparison quality;
- causal-chain edge support;
- adoption, fidelity, and decay;
- direct and indirect harms;
- distribution of benefit and burden;
- contribution confidence by causal depth.

### Overhead and usability

- decision latency;
- context and documentation cost;
- agent compute and human review cost;
- proportion of records actually used in later decisions;
- user comprehension and operational burden;
- cases where the framework was correctly simplified or not applied.

## 132. Anti-metrics

The following may be useful local observations but should not be treated as sufficient indicators of impact or framework quality:

- task completion rate;
- tickets closed;
- artefact count;
- lines of code;
- token volume;
- proof length;
- time spent;
- plan adherence;
- agent consensus;
- confidence without calibration;
- local test pass rate;
- adoption without outcome evidence;
- number of reflections or reviews;
- number of constitutional changes;
- narrative coherence;
- research citations without demonstrated relevance.

## 133. Validation designs

### Matched-case comparison

Apply different organisational conditions to tasks or projects matched on complexity and stakes.

### Cross-over design

Use the same team or domain with different mechanisms in alternating periods, while accounting for learning and carryover.

### Ablation

Remove one element—such as alternatives, invalidation criteria, or provenance—to estimate its contribution.

### Holdout evaluation

Develop a mechanism on one set of projects and evaluate on unseen projects.

### Interrupted time series

Observe organisational behaviour before and after adoption, while tracking external changes.

### Simulation and synthetic stress tests

Create controlled scenarios with hidden invalidating evidence, misleading proxies, delayed feedback, or authority conflicts. Use these to test routing and stopping before real-world deployment.

### Qualitative process tracing

Reconstruct how a decision changed, which evidence mattered, and whether the proposed mechanism was actually active.

### Adversarial and red-team review

Attempt to produce proxy success, suppress anomalies, exploit authority ambiguity, or create speculative higher-order impact narratives.

No single design establishes the framework. Triangulate across controlled and naturalistic evidence.

## 134. Calibration and confidence

Where probabilistic forecasts are feasible, track calibration over time.

A simple Brier score for binary events is:

\[
\mathrm{BS}=\frac{1}{N}\sum_{i=1}^{N}(p_i-o_i)^2
\]

But calibration is not only a number. Review:

- whether the event was defined clearly;
- whether predictions were registered prospectively;
- whether base rates were considered;
- whether forecasts are comparable across contexts;
- whether confidence changed appropriately after evidence;
- whether agents use confidence to claim authority.

## 135. Decision quality and regret

Outcome quality alone can mislead because good decisions sometimes produce bad outcomes under uncertainty and poor decisions can succeed by chance.

Evaluate decision quality using:

- information available at the time;
- alternatives considered;
- causal reasoning;
- treatment of uncertainty and harms;
- appropriateness of commitment size;
- prospective predictions;
- process independence;
- and subsequent calibration.

Where a credible best alternative can be estimated, track regret, but retain uncertainty in that estimate.

## 136. Framework overhead as a first-class cost

The framework can itself create rabbit holes through excessive meta-work.

Track:

- review time;
- record creation and maintenance;
- duplicated analysis;
- agent context burden;
- delayed execution;
- escalations that do not change decisions;
- constitutional proposals with no cross-case evidence;
- research whose main effect is to justify more research.

A mechanism should be simplified or removed when its prospective contribution no longer justifies its overhead.

## 137. Core failure modes and safeguards

| Failure mode | Mechanism | Safeguard |
|---|---|---|
| **Task becomes objective** | concrete local proxy dominates distant purpose | causal delegation; parent-claim linkage; re-authorisation |
| **Rabbit hole** | positive feedback from context and local progress | tranche ceilings; alternative comparison; diminishing-return trigger |
| **Wrong product built well** | intervention assumption is not revisited | external outcome evidence; strategy loop; no-action and non-product alternatives |
| **Low-impact proof** | epistemic work lacks contribution claim | bounded learning contract; programme review; application atlas |
| **Strategic entropy** | lossy delegation removes purpose and invalidation | decision-sufficient context; claim graph; provenance links |
| **Passive continuation** | incumbent remains active by default | continuation as positive decision; explicit boundary |
| **Escalation only when blocked** | strategic doubt is not a legitimate event | wrong-level and causal-invalidation triggers |
| **Sunk-context advantage** | incumbent owns artefacts and familiarity | challenger budget; residual-asset accounting; independent framing |
| **Performative certainty** | confidence signals competence | calibration; reward useful uncertainty; separate authority |
| **Misrouted evidence** | observation reaches wrong scope or role | structured evidence classification; protected routes |
| **Anomalies disappear** | weak signals remain in local histories | cross-programme anomaly ledger and thresholds |
| **Retrospective immunisation** | programme explains every failure after the fact | prospective predictions; severe tests; rival models |
| **Degenerating research** | complexity increases without new power | programme review; stop or reframe; transfer tests |
| **Premature consensus** | agents share context and assumptions | independent initial framings; diversity retention |
| **Thrashing** | every anomaly triggers high-level change | hysteresis; adaptation rates; local absorption thresholds |
| **Constitutional drift** | repeated local changes alter the organisation | versioned proposals; authority separation; rollback |
| **Constitutional capture** | incumbent roles control amendment | independent evaluation; affected-role review; protected process |
| **Normative drift** | empirical optimisation redefines values | protected normative loop; human and affected-party authority |
| **Speculative impact inflation** | indirect chains are counted as realised | edge-level evidence; contribution language; confidence decay |
| **Research instrumentalism** | inquiry is valued only by immediate use | recognise first-order epistemic contribution; research portfolio |
| **Self-confirmation** | framework generates its own evidence and criteria | comparators, holdouts, independent evaluation, external outcomes |
| **Meta-rabbit hole** | reflection becomes the new task proxy | contribution claim; metareasoning cost; lightweight mode |
| **Framework overreach** | complexity imposed on simple work | proportionality rule; explicit non-application decision |
| **Stakeholder tokenism** | representation becomes a check-box | standing, protected routes, decision authority, disagreement record |
| **Memory bureaucracy** | documents accumulate without use | linked records; usage measures; retention limits; pruning |

## 138. Safety, legitimacy, and rights

The framework is not a substitute for legal, professional, ethical, or democratic authority.

High-stakes implementations should include:

- explicit rights and prohibited actions;
- human review for consequential irreversible decisions;
- domain-specific safety standards;
- data minimisation, privacy, and security;
- avenues for appeal and correction;
- transparency proportional to impact and risk;
- redress for affected parties;
- clear responsibility rather than diffusion across agents;
- testing for unequal error and burden;
- monitoring of environmental and systemic externalities.

The system should never infer that a high expected benefit automatically authorises rights violations or the imposition of uncompensated risk.

## 139. When not to use the full framework

Use a lightweight workflow when work is:

- low impact and low harm;
- reversible;
- short-lived;
- well specified;
- directly observable;
- performed by few actors;
- not dependent on contested causal or normative claims;
- and inexpensive to correct.

The full framework is more justified when work is:

- long-lived;
- delegated across many agents;
- causally distant from impact;
- hard to reverse;
- affected by delayed feedback;
- strategically uncertain;
- capable of material harm;
- normatively contested;
- intended to transfer across projects;
- or able to modify the organisation itself.

## 140. Audit questions

A periodic audit should ask:

### Purpose and impact

- Can the organisation state its purpose without naming its current project?
- Are impact claims plural, traceable, and stakeholder-accountable?
- Does work remain comparable with non-work and no-action alternatives?

### Causality

- Can every major programme identify the causal edges it depends on?
- Which edges have external evidence?
- Which lower-level successes are being over-promoted?

### Delegation

- Could the recipient explain why the task matters and when it should stop?
- What strategically relevant information was compressed out?
- Are authority and escalation boundaries explicit?

### Alternatives

- Is the incumbent competing against materially different options?
- Were alternatives independently framed?
- Is no action represented honestly?

### Evidence

- Are observations linked to claims and rivals?
- Are predictions prospective?
- Do anomalies accumulate across projects?
- Is harm evidence protected from ordinary compression?

### Learning

- What changed in beliefs, methods, organisation, and constitution?
- Did retained learning improve a later decision?
- What has the organisation learned not to do?

### Governance

- Who can change what?
- Did any local agent acquire de facto constitutional or normative authority?
- Can the last change be rolled back?

### Overhead

- Which framework mechanisms changed a decision?
- Which records were never used?
- Where should the organisation simplify itself?

---

# Part XII — Worked example: an impact-oriented digital programme

## 141. Scenario

A long-lived human–AI organisation wants to improve how small community organisations allocate scarce support capacity.

A conventional product framing quickly becomes:

> Build a predictive dashboard that ranks cases and recommends allocation.

The AI team decomposes the work into data ingestion, feature engineering, model selection, interface design, tests, and deployment. It makes rapid progress. It also discovers data-quality problems and spends increasing effort on a technically sophisticated proof that a ranking model can be made stable.

The project appears healthy by task metrics. The framework asks whether the work remains connected to the intended impact.

## 142. Orient

### Impact thesis

Community organisations should be better able to allocate support in ways that improve access, fairness, and service outcomes without creating unacceptable surveillance or exclusion.

### Affected parties

- service users;
- frontline workers;
- community organisations;
- groups underrepresented in historical data;
- funders and public institutions;
- people indirectly displaced by allocation choices.

### Normative constraints

- do not automate final allocation authority without legitimate governance;
- protect privacy and avoid unsupported sensitive inference;
- monitor unequal error and access;
- provide contestability and human review.

## 143. Compete

Candidate means include:

1. predictive dashboard;
2. simpler decision checklist and workflow redesign;
3. data-quality and shared-definition standard;
4. training and facilitation for allocation meetings;
5. research into where allocation errors actually arise;
6. funding another organisation already providing appropriate infrastructure;
7. no product until governance and data conditions improve.

The product is no longer the assumed container for impact.

## 144. Construct causal models

### Incumbent model

```text
better prediction
  → better ranking recommendations
    → different allocation decisions
      → improved access and outcomes
```

Key assumptions:

- historical data represent relevant need;
- prediction errors are acceptable and equitably distributed;
- staff use recommendations appropriately;
- ranking quality is the main allocation bottleneck;
- governance can support the tool.

### Rival model

```text
shared definitions + structured deliberation
  → more consistent evidence and explicit trade-offs
    → better allocation decisions
      → improved access and legitimacy
```

Key assumption: the main bottleneck is inconsistent process and missing information, not predictive accuracy.

## 145. Bounded research tranche

Instead of completing the model, the organisation authorises a two-part tranche:

- observe allocation decisions and identify where disagreements and errors arise;
- prototype a minimal structured decision protocol alongside a simple baseline model.

Prospective prediction:

> If predictive accuracy is the binding constraint, controlled access to the baseline model should improve decision consistency and outcome-relevant choices more than the protocol alone. If process ambiguity is the binding constraint, the protocol should generate greater improvement and better explanations even without sophisticated prediction.

Stop condition:

> Do not invest in production-grade model infrastructure if data validity, governance, or causal relevance remains below the agreed threshold.

## 146. Observe and route

The tranche finds:

- major differences in staff definitions of urgency;
- missing contextual information not present in the dataset;
- historical under-service of one group;
- limited change from the model’s rankings;
- substantial improvement in consistency when teams use the protocol;
- stakeholder concern about opaque ranking.

Routing:

- missing context updates the intervention model;
- historical under-service and opacity route to normative review;
- model stability work is classified as technically valid but currently low decision relevance;
- the process protocol becomes a candidate enabling intervention;
- the data-standard insight becomes a research and infrastructure contribution.

## 147. Re-authorise

The organisation chooses:

- stop the sophisticated ranking-model tranche;
- preserve reusable data tooling;
- develop and test the structured protocol;
- conduct research on missing information and distributional effects;
- help organisations improve data definitions;
- retain predictive modelling as a dormant option contingent on governance and evidence.

This is not a failure to complete the product. It is success at a higher level: the organisation avoids lock-in, produces epistemic and enabling contributions, and chooses a more plausible route to impact.

## 148. Meta-learning

The application produces organisational findings:

- task completion metrics concealed intervention uncertainty;
- a no-product alternative was necessary to reveal the bottleneck;
- stakeholder evidence needed a protected route;
- the early technical proof created useful residual assets but should not have governed continuation;
- a bounded comparison reduced both product risk and research ambiguity;
- the framework’s records were useful, but one review form added overhead without changing a decision and should be simplified.

A candidate constitutional change is proposed—not automatically installed—to require explicit “binding constraint” hypotheses before large product commitments.

## 149. Higher-order impact profile

The programme’s contributions are represented separately:

- **Practical:** improved allocation process in pilot organisations; observed but not yet causally established at long-term outcome level.
- **Epistemic:** evidence that process ambiguity and missing context are central constraints in this setting.
- **Enabling:** reusable decision protocol and data definitions.
- **Normative:** increased visibility of under-service and stakeholder concern.
- **Institutional:** possible change in how allocation decisions are governed.
- **Reflexive:** evidence for a framework rule about binding-constraint hypotheses.

No speculative total impact number is required.

---

# Part XIII — Implementation roadmap and research agenda

## 150. Stage 0 — Baseline the current organisation

Before changing the workflow, observe existing behaviour.

Capture:

- how goals become tasks;
- where context is lost;
- how agents decide to continue;
- what triggers escalation;
- how often projects switch or stop;
- which outputs are treated as evidence;
- where external outcomes enter decisions;
- what research is protected or squeezed out;
- how stakeholders and harms are represented;
- the current cost of coordination and review.

Without a baseline, the framework may take credit for patterns that already existed or fail to detect added overhead.

## 151. Stage 1 — Install the minimum viable constitution

Add:

- impact constitution;
- explicit levels and authority;
- causal claim graph;
- delegation contract;
- bounded tranches;
- positive re-authorisation;
- challenger and no-action alternative;
- decision and anomaly registers.

Do not yet build elaborate automation.

## 152. Stage 2 — Instrument evidence and memory

Add:

- structured evidence events;
- claim linkage;
- routing rules;
- strategic-context packets;
- prediction registry;
- application and meta-learning records;
- privacy and retention controls.

Test whether these records are used in real decisions. Remove unused fields.

## 153. Stage 3 — Run comparative research

Use multiple organisational conditions, pre-register predictions, and capture external and organisational traces.

Prioritise:

- causal delegation;
- strategic context ablations;
- review-trigger policies;
- independent alternatives;
- evidence-routing accuracy;
- research programme review.

## 154. Stage 4 — Introduce versioned constitutional evolution

Only after sufficient observation:

- create a constitution repository;
- define amendment authority;
- sandbox proposed mechanisms;
- use holdouts;
- retain rollback;
- publish change rationales and unresolved evidence.

## 155. Stage 5 — Scale and federate

For multiple programmes:

- give local teams bounded autonomy;
- aggregate anomalies across contexts;
- maintain shared source, claim, and constitutional standards;
- allow domain-specific adaptations;
- define consistency requirements;
- protect cross-programme challenge and normative routes;
- compare transfer rather than assuming universality.

## 156. A first three-cycle plan

### Cycle 1: delegation and memory

- baseline existing task briefs;
- introduce causal delegation contracts;
- test strategic-context ablations;
- evaluate decision loss and overhead.

### Cycle 2: metacontrol and evidence routing

- introduce event-triggered review and positive re-authorisation;
- compare routing conditions;
- measure lock-in, thrashing, and decision latency.

### Cycle 3: constitutional self-hosting

- extract cross-case organisational findings;
- propose one bounded constitutional revision;
- test it on a holdout;
- promote or roll back based on prospective criteria.

## 157. Open research questions

### Purpose and impact

- How can plural values be represented without paralysing action or collapsing into a scalar proxy?
- Which processes give affected parties meaningful standing in artificial organisations?
- How should epistemic, enabling, and systemic contributions be compared without false commensurability?
- How rapidly should confidence decay along higher-order causal chains?

### Delegation and information

- What is the minimum decision-sufficient strategic context for different task classes?
- Can decision loss be estimated automatically?
- Which summaries preserve alternatives and invalidation conditions most reliably?
- When does additional context reduce rather than improve strategic judgement?

### Metacontrol

- Which combinations of fixed and event-triggered review best balance lock-in and thrashing?
- How should switching costs and option value be represented for long-lived agent teams?
- Can agents reliably identify wrong conceptual altitude?
- What signals reveal a rabbit hole before resource consumption becomes large?

### Mechanism design

- Which incentives or role structures make reframing locally legitimate?
- How independent must challenger contexts be to produce useful diversity?
- When does adversarial challenge become performative or wasteful?
- How should residual assets be credited without strengthening sunk-cost bias?

### Epistemics and research

- How can claim–evidence graphs remain usable at scale?
- What constitutes a severe test for organisational mechanisms?
- How can negative results and dormant alternatives be retained without overwhelming memory?
- Which indicators distinguish progressive from degenerating research programmes early?

### Feedback and complexity

- How should feedback be routed across level, scope, time, confidence, and normative significance?
- Which anomaly aggregation rules detect systemic problems without amplifying noise?
- How can the system recognise a genuine change-point in strategy or context?
- What adaptation-rate separation is appropriate across operations, strategy, constitution, and norms?

### Constitutional self-modification

- What evidence is sufficient to promote a local organisational lesson into a general rule?
- Which holdout designs are practical for long-lived organisations?
- How can constitutional capture and self-confirmation be detected?
- When should a successful mechanism remain local rather than become constitutional?

### Human–AI organisation

- Which decisions benefit from artificial autonomy and which require human deliberation?
- How do model changes, context windows, and tool ecosystems affect organisational memory?
- How should responsibility be assigned when decisions emerge from distributed human–AI processes?
- What forms of transparency are useful to operators, stakeholders, auditors, and affected people?

### Evaluation

- What is an appropriate reference for decision quality under deep uncertainty?
- How can avoided low-impact work be measured without claiming unknowable counterfactuals?
- Which measures are robust to Goodharting by the framework itself?
- When does framework overhead outweigh its value?

## 158. Maturity map

| Component | Current status | Evidence needed next |
|---|---|---|
| Multi-level continuation and reconsideration | strong theoretical synthesis | operational trials across task classes |
| Causal delegation contracts | design hypothesis with strong rationale | matched comparison and ablation |
| Positive re-authorisation | design hypothesis | stopping/switching outcomes and overhead |
| Counterfactual challenger | established analogues, untested implementation | independence and value studies |
| Decision-sufficient compression | theoretical construct | context ablation and transfer tests |
| Evidence routing | architecture proposal | routing accuracy and decision-impact trials |
| Anomaly ledger | operational recommendation | detection benefit versus noise/overhead |
| Research programme review | grounded in philosophy of science | reliable organisational indicators |
| Impact topology | project synthesis | usability and stakeholder interpretation |
| Research as first-order and generative impact | conceptual synthesis | case studies and causal contribution evidence |
| Versioned constitutional self-modification | early design hypothesis | sandbox, holdout, and rollback trials |
| Full self-hosting organisation | research programme | comparative longitudinal evidence |

## 159. Publication and transparency strategy

The project should publish progressively:

1. `F₀` constitution and construction manual;
2. source map and provenance;
3. research protocols and prospective predictions;
4. anonymised application and organisational traces where lawful and ethical;
5. negative results and failed mechanisms;
6. version changes with evidence and dissent;
7. application atlas with scope conditions;
8. periodic synthesis distinguishing established findings, design hypotheses, and open questions.

Transparency should be constrained by privacy, security, participant consent, and the risk of exposing sensitive organisational or stakeholder information.

---
# Part XIV — Reference checklists and glossary

## 160. One-page construction checklist

### Constitution

- [ ] Purpose is expressed without naming a permanent project, product, job, or metric.
- [ ] Affected parties and legitimate authority are explicit.
- [ ] Rights, constraints, prohibited means, and amendment rules are explicit.
- [ ] Direct, epistemic, enabling, institutional, normative, and reflexive contributions are distinguished.

### Causal and strategic architecture

- [ ] Major programmes have claim-linked causal models.
- [ ] Each causal edge has assumptions, confidence, evidence, and counterfactuals.
- [ ] Incumbents compete with materially different alternatives and no action.
- [ ] Means beyond product work are considered.

### Delegation and operation

- [ ] Tasks are represented as provisional options.
- [ ] Delegation includes intended effect, causal role, authority, and invalidation.
- [ ] Commitment is bounded by resources, risk, irreversibility, and time.
- [ ] Local autonomy is broad enough for execution and bounded enough for safety and strategy.

### Metacontrol

- [ ] Review triggers include wrong-direction progress, not only blockage.
- [ ] Continuation requires positive re-authorisation.
- [ ] Hysteresis prevents repeated oscillation.
- [ ] Stopping, reframing, enabling others, delay, and no action are legitimate actions.

### Evidence and memory

- [ ] Evidence is linked to claims and rivals.
- [ ] Predictions are prospective.
- [ ] Feedback is classified and routed by level, scope, urgency, and authority.
- [ ] Anomalies accumulate across projects.
- [ ] Decisions, alternatives, evidence, dissent, and reopen conditions are retained.

### Research and self-modification

- [ ] Research has contribution claims and bounded learning contracts.
- [ ] Object, method, and organisational hypotheses are separated where relevant.
- [ ] Framework mechanisms have comparators and independent evaluation.
- [ ] Constitutional changes are versioned, sandboxed, holdout-tested where possible, and reversible.
- [ ] The organisation records cases where the framework should be simplified or not used.

### Impact and legitimacy

- [ ] Higher-order claims show every causal edge and its uncertainty.
- [ ] Contribution is not overstated as exclusive attribution.
- [ ] Harms and distribution are not netted away in one score.
- [ ] Stakeholder evidence has a protected route.
- [ ] Empirical confidence does not confer normative authority.

## 161. Programme-start checklist

Before authorising a programme, answer:

1. What valuable change is intended, and for whom?
2. What kind of contribution is this programme expected to make?
3. Why is this organisation a plausible contributor?
4. What would probably happen without it?
5. What are the current causal model and credible rivals?
6. What non-product, enablement, delay, and no-action alternatives exist?
7. Which assumptions carry the most decision sensitivity?
8. What evidence could change the programme choice?
9. What is the smallest bounded tranche that can create value or discriminating information?
10. What commitment and lock-in will the tranche create?
11. Who can modify, stop, or reframe it?
12. Which affected parties and constraints require protected authority?
13. What will be retained regardless of outcome?
14. How will the programme produce application and meta-learning?

## 162. Task-start checklist

Before an agent begins a task:

- What parent claim does this task serve?
- What effect, not merely output, is intended?
- What is the current hypothesis?
- What alternatives remain live?
- What is expected to be learned?
- What is in and out of scope?
- What resources and irreversible actions are authorised?
- When may the agent simplify, change, or stop?
- What observations require escalation?
- Who owns the next re-authorisation?

## 163. Re-authorisation checklist

At a tranche boundary:

- Compare prediction with observation.
- Update claims before plans.
- Examine alternatives independently of sunk effort.
- Identify residual assets and new lock-in.
- Review stakeholder effects, harms, and distribution.
- Decide the correct level of response.
- State continue, modify, switch, investigate, reframe, defer, enable another, or stop.
- Define the next bounded commitment.
- Retain dissent and reopen conditions.

## 164. Research-review checklist

- Did the programme make a legitimate contribution?
- Did evidence discriminate among rivals?
- Were prospective predictions met?
- Did explanatory, predictive, practical, methodological, or option value increase?
- Is complexity buying power or defending the incumbent?
- What negative results and anomalies should be retained?
- Which findings transfer, under what conditions?
- What did the research process teach about itself?
- Does any finding justify a constitutional proposal rather than a local practice?
- What would falsify the proposed meta-learning on a holdout?

## 165. Glossary

### Abstraction level

The conceptual level at which a claim, action, or error exists: operation, task, capability, intervention, impact, organisation, constitution, or norm.

### Affected party

A person, community, institution, environment, or future interest that may benefit from, bear costs from, or have legitimate standing in a decision.

### Anomaly ledger

A cross-project memory of observations that do not fit current expectations, allowing weak signals to accumulate rather than disappear in local histories.

### Application atlas

A structured map of where framework mechanisms or research findings have been applied, with outcomes, boundary conditions, counterexamples, and transfer evidence.

### Bounded learning contract

A research commitment specifying the intended contribution, uncertainty, prospective observations, effort and risk ceiling, programme review conditions, and possible uses.

### Bounded tranche

A temporary commitment with explicit scope, resources, predictions, risk, irreversibility, stop conditions, and a decision boundary.

### Causal delegation

Delegation that communicates intended effects, causal role, hypotheses, alternatives, constraints, authority, and invalidation—not only an activity specification.

### Causal depth

The number and kind of mediating transformations between an originating activity and a claimed external effect.

### Claim–evidence graph

A linked representation of claims, rivals, assumptions, predictions, evidence, anomalies, confidence, and decision relevance.

### Constitutional change

A change to roles, rules, permissions, memory, feedback, incentives, or the process by which the organisation changes itself.

### Constitutional gate

The process that evaluates, tests, authorises, versions, and potentially rolls back constitutional changes.

### Contribution claim

An explicit statement of how an activity is expected to add epistemic, practical, enabling, coordinative, institutional, normative, or reflexive value.

### Counterfactual challenger

A protected function that develops alternative explanations and interventions, including no action and enablement pathways, and proposes discriminating tests.

### Decision loss

The degradation in choice quality caused by omitting or distorting information during compression or delegation.

### Decision-sufficient context

The smallest practical context that preserves information capable of changing the recipient’s decision.

### Degenerating research programme

A programme that accumulates post-hoc complexity or defensive explanation without producing new explanatory, predictive, practical, or option value.

### Evidence routing

Classifying and sending evidence to the abstraction level, organisational scope, and authority capable of responding appropriately.

### Generative impact

Impact produced by changing the capabilities, decisions, or production function of other projects, people, or institutions.

### Higher-order impact

An effect mediated through one or more other actors, projects, institutions, or learning loops.

### Impact orientation

The use of valuable and legitimate change as the governing horizon for inquiry and action without pretending it is fully represented by one metric.

### Impact profile

A multidimensional representation of a contribution by value type, causal depth, time horizon, scope, confidence, reversibility, distribution, and externalities.

### Impact topology

The network of direct, mediated, distributed, institutional, and reflexive contribution paths associated with a body of work.

### Incumbent

The currently active task, project, intervention, model, method, or constitutional mechanism, which may possess accumulated context and coordination advantages.

### Invalidation condition

Evidence or context that removes or materially weakens the causal rationale for continuing a task, programme, or strategy.

### Lock-in

A change that increases the technical, financial, organisational, reputational, cognitive, or normative cost of future switching.

### Meta-learning

Retained learning about how to learn, evidenced most strongly by improved future decisions.

### Metacontrol

The allocation of attention and agency among execution, planning, investigation, comparison, reframing, switching, delay, and stopping.

### Metastable commitment

A commitment stable enough to support execution but deliberately open to change at designed decision boundaries.

### Normative loop

The protected process through which purpose, legitimacy, values, rights, distribution, and affected-party standing are examined and changed.

### Option value

The value of preserving the ability to take, expand, switch, defer, or abandon a future action after more information arrives.

### Positive re-authorisation

The requirement that continuation be explicitly chosen at a boundary rather than occur by inertia.

### Progressive research programme

A programme that generates novel explanatory, predictive, practical, methodological, or option value and succeeds beyond retrospective accommodation.

### Proxy

An observable measure or local objective used as an imperfect indicator of a more distant or complex purpose.

### Reflexive impact

Impact produced when research or action changes the system’s own capacity to understand, decide, organise, and create future impact.

### Residual asset

A capability, dataset, method, relationship, or learning that remains useful after the originating task or programme stops.

### Requisite variety

The diversity of legitimate responses a regulator needs to handle the disturbances that matter.

### Research self-hosting

Using a version of the framework to research and construct its successor while preserving comparison, external evaluation, versioning, and rollback.

### Strategic entropy

The progressive loss or distortion of strategically relevant information through delegation, compression, execution, and organisational drift.

### Strategic context packet

A decision-sufficient handoff containing purpose, causal role, assumptions, alternatives, uncertainty, constraints, predictions, authority, and invalidation conditions.

### Transfer hypothesis

A prospective claim about where and why a finding should generalise, including conditions under which it may fail.

### Wrong conceptual altitude

A situation in which effort is directed at an operational or tactical problem while the material error exists at a higher—or occasionally lower—level.

---

# Part XV — Direct links to original sources

## 166. Source policy

The project is a synthesis. No single source contains the full framework.

The list below separates:

- **original or primary sources** that introduced or directly developed important underlying ideas;
- **recent AI and agent papers** explicitly considered during the project;
- **reference and interpretive sources** used to clarify philosophical or historical context.

A link in this bibliography does not imply that the source endorses the project’s synthesis or every design recommendation. Several concepts are transferred across fields by analogy and remain design hypotheses until empirically tested in artificial organisations.

Where possible, links point to a DOI, publisher page, author-hosted paper, free book, or canonical arXiv record rather than a search result.

## 167. Rational metareasoning, value of computation, and information value

1. Stuart J. Russell and Eric Wefald, **“Principles of Metareasoning”** (1991). [DOI: 10.1016/0004-3702(91)90015-C](https://doi.org/10.1016/0004-3702%2891%2990015-C)
2. Stuart J. Russell, **“Metareasoning”** (1997). [Author-hosted PDF](https://people.eecs.berkeley.edu/~russell/papers/mitecs-metareasoning.pdf)
3. Can Eren Sezener, **“Computing the Value of Computation for Planning”** (2018). [arXiv:1811.03035](https://arxiv.org/abs/1811.03035)
4. C. Nicolò De Sabbata, Theodore R. Sumers, Badr AlKhamissi, Antoine Bosselut, and Thomas L. Griffiths, **“Rational Metareasoning for Large Language Models”** (2024; revised 2025). [arXiv:2410.05563](https://arxiv.org/abs/2410.05563)
5. Ronald A. Howard, **“Information Value Theory”** (1966). [DOI: 10.1109/TSSC.1966.300074](https://doi.org/10.1109/TSSC.1966.300074)
6. Dennis V. Lindley, **“On a Measure of the Information Provided by an Experiment”** (1956). [DOI: 10.1214/aoms/1177728069](https://doi.org/10.1214/aoms/1177728069)

## 168. Hierarchical planning and temporally extended action

7. Richard S. Sutton, Doina Precup, and Satinder Singh, **“Between MDPs and Semi-MDPs: A Framework for Temporal Abstraction in Reinforcement Learning”** (1999). [DOI: 10.1016/S0004-3702(99)00052-1](https://doi.org/10.1016/S0004-3702%2899%2900052-1)
8. George Konidaris and Andrew G. Barto, **“Building Portable Options: Skill Transfer in Reinforcement Learning.”** [Author-hosted PDF](https://people.csail.mit.edu/gdk/pubs/agentopt.pdf)
9. Arun Ahuja, Kavya Kopparapu, Rob Fergus, and Ishita Dasgupta, **“Hierarchical Reinforcement Learning with Natural Language Subgoals”** (2023). [arXiv:2309.11564](https://arxiv.org/abs/2309.11564)

## 169. Control, switching, and real options

10. David Q. Mayne, James B. Rawlings, Christopher V. Rao, and Pierre O. M. Scokaert, **“Constrained Model Predictive Control: Stability and Optimality”** (2000). [DOI: 10.1016/S0005-1098(99)00214-9](https://doi.org/10.1016/S0005-1098%2899%2900214-9)
11. Lenos Trigeorgis, **_Real Options: Managerial Flexibility and Strategy in Resource Allocation_** (1996). [MIT Press](https://mitpress.mit.edu/9780262201025/real-options/)
12. Avinash K. Dixit and Robert S. Pindyck, **_Investment Under Uncertainty_** (1994). [Princeton University Press](https://press.princeton.edu/books/hardcover/9780691034102/investment-under-uncertainty)

## 170. Principal–agent theory, incomplete contracts, and proxy optimisation

13. Michael C. Jensen and William H. Meckling, **“Theory of the Firm: Managerial Behavior, Agency Costs and Ownership Structure”** (1976). [DOI: 10.1016/0304-405X(76)90026-X](https://doi.org/10.1016/0304-405X%2876%2990026-X)
14. Bengt Holmström, **“Moral Hazard and Observability”** (1979). [DOI: 10.2307/3003320](https://doi.org/10.2307/3003320)
15. Paulius Rauba, Simonas Cepenas, and Mihaela van der Schaar, **“Multi-Agent Systems Should be Treated as Principal-Agent Problems”** (2026). [arXiv:2601.23211](https://arxiv.org/abs/2601.23211)
16. Jacek Karwowski, Oliver Hayman, Xingjian Bai, Klaus Kiendlhofer, Charlie Griffin, and Joar Skalse, **“Goodhart’s Law in Reinforcement Learning”** (2023). [arXiv:2310.09144](https://arxiv.org/abs/2310.09144)

## 171. Information theory, compression, cybernetics, and regulation

17. Claude E. Shannon, **“A Mathematical Theory of Communication,” Part I** (1948). [DOI: 10.1002/j.1538-7305.1948.tb01338.x](https://doi.org/10.1002/j.1538-7305.1948.tb01338.x)
18. Claude E. Shannon, **“A Mathematical Theory of Communication,” Part II** (1948). [DOI: 10.1002/j.1538-7305.1948.tb00917.x](https://doi.org/10.1002/j.1538-7305.1948.tb00917.x)
19. Naftali Tishby, Fernando C. Pereira, and William Bialek, **“The Information Bottleneck Method”** (1999/2000). [arXiv:physics/0004057](https://arxiv.org/abs/physics/0004057)
20. W. Ross Ashby, **_An Introduction to Cybernetics_** (1956). [Author archive PDF](https://ashby.info/Ashby-Introduction-to-Cybernetics.pdf)
21. Roger C. Conant and W. Ross Ashby, **“Every Good Regulator of a System Must Be a Model of That System”** (1970). [DOI: 10.1080/00207727008920220](https://doi.org/10.1080/00207727008920220)

## 172. Bayesian inference, change-points, and active learning

22. Ryan Prescott Adams and David J. C. MacKay, **“Bayesian Online Changepoint Detection”** (2007). [arXiv:0710.3742](https://arxiv.org/abs/0710.3742)
23. Yingke Li, Anjali Parashar, Enlu Zhou, and Chuchu Fan, **“Pragmatic Curiosity: A Unified Framework for Hybrid Learning and Optimization via Active Inference”** (2026). [arXiv:2602.06104](https://arxiv.org/abs/2602.06104)

## 173. Philosophy of science, severe testing, and research programmes

24. Karl Popper, **_The Logic of Scientific Discovery_**. [Routledge edition](https://www.routledge.com/The-Logic-of-Scientific-Discovery/Popper-Popper/p/book/9780415278447)
25. Imre Lakatos, **“Falsification and the Methodology of Scientific Research Programmes”** (1970). [DOI: 10.1017/CBO9781139171434.009](https://doi.org/10.1017/CBO9781139171434.009)
26. Thomas S. Kuhn, **_The Structure of Scientific Revolutions_**. [DOI: 10.7208/chicago/9780226458144.001.0001](https://doi.org/10.7208/chicago/9780226458144.001.0001)
27. Deborah G. Mayo, **_Statistical Inference as Severe Testing_** (2018). [DOI: 10.1017/9781107286184](https://doi.org/10.1017/9781107286184)

## 174. Causal inference and counterfactual reasoning

28. Donald B. Rubin, **“Estimating Causal Effects of Treatments in Randomized and Nonrandomized Studies”** (1974). [DOI: 10.1037/h0037350](https://doi.org/10.1037/h0037350)
29. Miguel A. Hernán and James M. Robins, **_Causal Inference: What If_** (2020). [Free author-hosted book](https://miguelhernan.org/whatifbook)

## 175. Organisational learning, exploration, and evolutionary search

30. Chris Argyris, **“Single-Loop and Double-Loop Models in Research on Decision Making”** (1976). [DOI: 10.2307/2391848](https://doi.org/10.2307/2391848)
31. Paul Tosey, Max Visser, and Mark N. K. Saunders, **“The Origins and Conceptualizations of ‘Triple-Loop’ Learning: A Critical Review”** (2012). [DOI: 10.1177/1350507611426239](https://doi.org/10.1177/1350507611426239)
32. James G. March, **“Exploration and Exploitation in Organizational Learning”** (1991). [DOI: 10.1287/orsc.2.1.71](https://doi.org/10.1287/orsc.2.1.71)
33. Donald T. Campbell, **“Blind Variation and Selective Retention in Creative Thought as in Other Knowledge Processes”** (1960). [DOI: 10.1037/h0040373](https://doi.org/10.1037/h0040373)

## 176. Resilience engineering

34. Erik Hollnagel, David D. Woods, and Nancy Leveson (eds.), **_Resilience Engineering: Concepts and Precepts_** (2006). [Routledge](https://www.routledge.com/Resilience-Engineering-Concepts-and-Precepts/Hollnagel-Woods-Leveson/p/book/9780754649045)
35. David D. Woods, **“Four Concepts for Resilience and the Implications for the Future of Resilience Engineering”** (2015). [DOI: 10.1016/j.ress.2015.03.018](https://doi.org/10.1016/j.ress.2015.03.018)

## 177. Distributed systems and sensemaking

36. Leslie Lamport, **“Time, Clocks, and the Ordering of Events in a Distributed System”** (1978). [DOI: 10.1145/359545.359563](https://doi.org/10.1145/359545.359563)
37. Gary Klein, Brian Moon, and Robert R. Hoffman, **“Making Sense of Sensemaking 1: Alternative Perspectives”** (2006). [DOI: 10.1109/MIS.2006.75](https://doi.org/10.1109/MIS.2006.75)
38. Gary Klein, Brian Moon, and Robert R. Hoffman, **“Making Sense of Sensemaking 2: A Macrocognitive Model”** (2006). [DOI: 10.1109/MIS.2006.100](https://doi.org/10.1109/MIS.2006.100)

## 178. Reference and interpretive sources used during the project

These are useful high-quality reference works or interpretive sources rather than the originating primary source for every concept.

39. Stanford Encyclopedia of Philosophy, **“Bayesian Epistemology.”** [Direct entry](https://plato.stanford.edu/entries/epistemology-bayesian/)
40. Stanford Encyclopedia of Philosophy, **“Scientific Method.”** [Direct entry](https://plato.stanford.edu/entries/scientific-method/)
41. Stanford Encyclopedia of Philosophy, **“Evidence.”** [Archived 2025 entry](https://plato.stanford.edu/archives/fall2025/entries/evidence/)
42. Stanford Encyclopedia of Philosophy, **“Philosophy of Statistics.”** [Direct entry](https://plato.stanford.edu/entries/statistics/)
43. Stanford Encyclopedia of Philosophy, **“Historicist Theories of Scientific Rationality.”** [Archived 2023 entry](https://plato.stanford.edu/archives/spr2023/entries/rationality-historicist/)
44. Cambridge Core, **“Kuhn and Feyerabend”** in _Theories of Scientific Method_. [Direct chapter page](https://www.cambridge.org/core/books/theories-of-scientific-method/kuhn-and-feyerabend/E19A9BB15283B7D5F6AA03C6E7A4C7D0)
45. Cambridge Core, **“Normal Science and Dogmatism: Paradigms and Progress—Kuhn versus Popper and Lakatos”** in _Thomas Kuhn_. [Direct chapter page](https://www.cambridge.org/core/books/thomas-kuhn/normal-science-and-dogmatism-paradigms-and-progress-kuhn-versus-popper-and-lakatos/1A017903AE9CF405B74D0ADCED4987FC)

## 179. Source-to-framework map

| Framework element | Principal source traditions |
|---|---|
| Continue, stop, think, or switch | Russell & Wefald; Russell; Sezener; Howard; real options |
| Tasks as temporally extended options | Sutton, Precup & Singh; Konidaris & Barto; Ahuja et al. |
| Bounded execution and replanning | model-predictive control; real-options theory |
| Delegation under incomplete specification | Jensen & Meckling; Holmström; Rauba et al. |
| Proxy failure and early stopping | Karwowski et al.; Goodhart tradition |
| Decision-sufficient context | Shannon; information bottleneck; project synthesis |
| Requisite response variety and internal models | Ashby; Conant & Ashby |
| Graded belief and change-point detection | Bayesian epistemology; Adams & MacKay |
| Joint information and pragmatic value | Howard; Lindley; Li et al. |
| Falsification and programme progress | Popper; Lakatos; Mayo; Kuhn |
| Causal chains and counterfactuals | Rubin; Hernán & Robins |
| Single-, double-, and constitutional learning | Argyris; triple-loop literature; project refinement |
| Exploration, diversity, and retention | March; Campbell |
| Adaptation, containment, and graceful transformation | resilience engineering |
| Partial observability, consistency, and provenance | distributed systems |
| Framing and reframing | sensemaking literature |
| Impact topology and research as recursive impact | project synthesis |
| Versioned self-hosting constitution | project synthesis drawing on all above |

## 180. Project provenance

This document was synthesised from the project conversation and its exported transcript, followed by additional project development on:

- self-hosting research;
- application of the framework to impact through work and other means;
- research as first-order, generative, systemic, and reflexive impact;
- higher-order causal contribution;
- and the need to preserve richness rather than reduce impact to “do the right job.”

The companion transcript is named:

`impact-aligned-artificial-organisations-transcript.md`

---

# Closing synthesis

The project began with a practical question:

> When an organisation is deep in execution, how should it decide whether to continue, change the task, change the implementation, or step back and reconsider direction?

It developed into a broader insight:

> **The recurring failure is not only bad planning. It is an organisation whose representations, incentives, memory, feedback, authority, and research practices make lower-level completion more stable than higher-level contribution.**

The answer is not constant reflection, a longer prompt, or a single impact metric. It is an organisational constitution that:

- preserves strategically relevant information;
- represents work as provisional causal hypotheses;
- maintains alternatives and no-action baselines;
- commits in bounded and reversible tranches;
- makes continuation explicit;
- routes evidence to the level where it matters;
- distinguishes confidence from authority;
- protects research as both contribution and infrastructure;
- recognises direct and higher-order impact without inflating attribution;
- retains anomalies, dissent, and negative results;
- learns at operational, strategic, methodological, organisational, constitutional, and normative levels;
- versions and tests its own changes;
- and remains accountable to external consequences and affected people.

The framework is therefore not a machine for finding the right task or the right job.

It is:

> **an evolving ecology of inquiry, agency, action, evidence, governance, and memory through which people and artificial systems can become better able to contribute to valuable, legitimate, and durable change.**

Its strongest test will not be whether it can explain itself beautifully. It will be whether using it changes future decisions, actions, understanding, capabilities, institutions, and impacts for the better—and whether it can recognise, with equal seriousness, where it does not.
