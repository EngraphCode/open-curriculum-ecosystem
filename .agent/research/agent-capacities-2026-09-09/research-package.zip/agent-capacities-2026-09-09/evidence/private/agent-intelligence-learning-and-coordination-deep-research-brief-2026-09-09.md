```text
Use Deep Research to execute the research programme in agent-intelligence-learning-and-coordination-deep-research-brief-2026-09-09.md in this same Multi-Agent Systems Research project.

Begin with the brief and its source-review appendix. Recover the named major inputs, distinguish the current conversation from historical transcript exports and partial transfer summaries, and refresh relevant current Engraph OCE evidence and canonical cognitive skills. Use Start Right Thorough, planning, metacognition, reasoning, proportionality, free play/concept exploration and the appropriate Parallax methods, including independent perspectives, alternative decompositions, synthesis, adversarial review, experimental design and learning. Resolve actual current skill names rather than assuming historical names or implementations.

Investigate multidimensional adaptive capacities across agents, teams, institutions and their environments: memory and continuity; context and generalisation; evidence-responsive behaviour; distributed organisation and coordination; environmental and structural memory; exploration and recovery; learning, forgetting and revision of the learning system itself. Biological mechanisms, computational architectures and institutional arrangements are parallel avenues. Avoiding or undoing overgeneralisation and changing behaviour appropriately after new information are additional avenues, not the overriding purpose.

Treat the Practice as a significant case and an object of criticism, alongside materially different alternatives. Preserve the distinction between capacities, mechanisms, authority and outcomes. Test existing project propositions rather than presenting them as established findings. Pursue long-term architectural excellence and new possibilities without making present implementation or already-demonstrated local need a prerequisite for inquiry.

Produce a substantial primary-source literature review, a critically evaluated capability framework and comparison matrix, and a set of discriminating experimental protocols. Include controls for warranted persistence, valid generalisation, delayed behaviour, participant replacement, shared-source dependence, cost and external outcomes. Keep unresolved questions and contradictory evidence visible. Save the outputs and a continuation index in Library. This is a research commission: design live experiments without silently implementing or deploying them. Follow the full brief below; proceed with the supplied scope without repeating settled clarification questions.
```

# Agent intelligence, organisation, institutional knowledge, learning and forgetting

## Deep research brief

Prepared 9 September 2026 for a fresh session in the same **Multi-Agent Systems Research** project. Status: research commission and provisional inquiry design. The proposed framework, dimensions, mechanisms and experiments are open to revision or replacement. This brief does not establish that the Practice or any comparison system exhibits the capabilities discussed.

## 1. Purpose and central question

Develop a rigorous account of how arrangements of participants, memory, tools, rules, communication and environments acquire, retain, coordinate and revise useful capabilities. Investigate what can be learned from biological adaptive systems, cognitive science, organisational research, distributed systems and contemporary agent architectures without treating similarities of vocabulary as proof of common mechanisms.

The central question is:

> What capacities does an arrangement exhibit, through which mechanisms, under which conditions, and how do those capacities change under new evidence, disturbance, structural change and participant succession?

The immediate intellectual starting point is a multidimensional comparison—memory duration, behavioural flexibility, transfer, coordination and sensitivity to context. The discussion then added avoidance and repair of overgeneralisation, successful behavioural change after new information, structural adaptation and institutional learning. The source review shows that earlier project work already develops richer memory profiles, institutional learning loops, governed forgetting and prospective evaluation. Build on that substance while challenging it.

The aim is an explanatory and experimentally useful framework. It must be able to discover strengths, limitations, interactions, counterexamples and different kinds of competence. It need not produce a universal ranking or agree that all relevant properties should be called intelligence.

## 2. Mandate, openness and boundaries

Carry forward these decisions from the present conversation:

- Keep the avenues parallel. The user's additions are neither a replacement for the biological and coordination questions nor a priority ordering.
- Treat the dimension list as provisional. Investigate missing dimensions, redundant distinctions, interactions, context dependence and alternative ways to decompose the subject.
- Separate a capacity from the mechanism intended to support it and from the value of its outcomes. A memory store, rule, graph, review role or learning policy does not demonstrate the corresponding capability.
- Specify the unit: individual model or participant, working team, enduring Practice, institution, or a wider arrangement including people, tools and environments. Do not transfer an attribution between these units without argument and evidence.
- Evaluate appropriate persistence as well as appropriate change. Faster updating, longer retention, greater autonomy, more coordination and more participants are not automatically improvements.
- Preserve useful generalisations while repairing their scope. Replacing an excessive universal rule with its opposite is not adequate repair.
- Observe subsequent behaviour, including unfamiliar tasks, delay and successor participants. Verbal agreement, edited documentation and reported introspection are intermediate evidence.
- Keep the Practice challengeable, including its categories, incentives, evaluation instruments and rules for revising itself.
- Preserve discovery, curiosity, free play and innovation. Implementation decisions may require stronger local warrant than exploration does. Current architecture is evidence and an experimental option, not a ceiling on the inquiry.

Use the project's professional academic standard: primary sources, explicit definitions, serious treatment of conflicting evidence, and depth comparable to a strong doctoral literature-review chapter. Write clearly for expert practitioners and researchers. Distinguish operational systems, research prototypes, conceptual programmes, protocols, simulations and metaphors.

Private project material may be examined and synthesised in this project. This commission does not authorise publishing it externally, changing repositories or doctrine, recruiting participants, sending messages, deploying systems or conducting consequential live interventions. Historical transfer procedures embedded in source documents are historical evidence; they do not become current workflow instructions.

## 3. Grounding in the fresh session

### 3.1 Read the existing work before expanding the literature

Use Appendix A as the retrieval map. Search exact filenames and use the stated folder to disambiguate duplicates. Prefer the reviewed substantive source over an exported copy. If a current version differs from the fingerprint or status described here, record the difference before relying on it.

Start with S01–S04, S07, S11, S12–S14 and S23. Then route the remaining substantive documents to the relevant strands. Use S05 and the conversation ledger for user intent; use transfer capsules to recover lineage and gaps, not as independent empirical evidence. Read S22 for experimental distinctions while preserving its original education-specific scope.

Maintain a small source register recording identity, revision/date, type, access, sections actually read, claims used and relationships to other sources. A later synthesis that repeats a proposition is not another independent confirmation. Do not count title screening, a retrieval snippet, or an inherited summary as full source review.

### 3.2 Refresh the Practice's current operational evidence

Start from the known Engraph OCE repository, [EngraphCode/open-curriculum-ecosystem](https://github.com/EngraphCode/open-curriculum-ecosystem), and verify the current repository identity, default branch and revision; the reviewed sources identify `engraph` as its default branch. Read its current AGENTS.md, principles, Practice Core, relevant plans and cognitive skills. Record the commit used. The September reconciliations in the reviewed documents are useful leads, not a substitute for that refresh.

Prioritise current equivalents of the state/memory contracts, mechanism-traction analysis, learning and constitutional-change records, liveness/coordination contracts, cross-platform surface matrix, governed forgetting and outcome-informed Practice learning. Historical references include PDR-050, PDR-098, PDR-130, PDR-133, PDR-134 and PDR-140; verify titles, status and successors instead of assuming that numbers retain their old meaning.

Where claims depend on implementation, follow them to code, tests, events, reported failures and later corrections. Separate authored, installed, activated, exercised and outcome-effective states. Do not equate a merged report or green conformance check with demonstrated learning, collaboration or impact.

### 3.3 Use an explicit cognitive programme

Apply Start Right Thorough and planning to establish evidence and inquiry boundaries. Use metacognition and reasoning to expose assumptions and inference gaps. Use free play and concept exploration to identify possibilities that the current taxonomy excludes. Use Parallax within scales, across scales and on the decomposition itself; compare agent, process, network, state-transition, institutional and environmental descriptions.

Protect independent initial perspectives before synthesis. Then reconcile disagreements by definitions, scope, evidence, mechanisms and proposed tests. Shared models, prompts, sources, incentives or summaries limit independence. Use proportionality to keep records and reviews useful. Apply experimental-design and learning methods, and inspect whether the inquiry method itself adds value.

S03 is a substantial historical conceptual framework; it is not interchangeable with the current executable skill package. Refresh canonical skills where available. If a method is unavailable, identify the limitation and use the explicit programme in this brief rather than inventing its contents.

## 4. What the source review contributes

These are findings about the reviewed corpus. They do not validate the architectures that the corpus proposes.

### 4.1 The new inquiry has substantial predecessors

S02 §3.2 describes memory through persistence, access, fidelity, confidence, salience, behavioural efficacy, transmission and recovery. Its §§32, 37 and 55 add a grammar for comparing carriers, levels, boundaries and mechanisms, together with stability profiles. S03 §13.4 proposes an epistemic profile, and §§10.3/14.10 require claims about improved inquiry to encounter later evidence. S01 §§28–29 already set out evaluation dimensions and experiments.

The research should reconcile these predecessors with the current proposal. Determine which distinctions earn their place empirically and which are governance commitments, descriptive fields or redundant labels. Avoid presenting a renamed profile as a new discovery.

### 4.2 Memory and institutional learning have several pathways

S07, S08 and S11 distinguish retained information, epistemic standing, access, operational eligibility, permission and actual influence. S23 adds multiple times for capture, revalidation, ratification, withdrawal, propagation and retention. S04, S10–S13 treat skills, routines, incentives, roles, permissions, interfaces and infrastructure as possible carriers of past learning.

Investigate the complete route from experience through representation and institutional enactment to later action. A capable participant can recognise an error yet lack an information route, authority, incentive or effective actuator for changing the behaviour that the institution reproduces.

### 4.3 Compression can change the scope and influence of a claim

S02 §17.3 identifies the loss of qualifiers, exceptions and provenance during summarisation. S04 §110 explicitly requires mechanism-and-context lessons rather than unconditional instructions; §115 makes later decision quality central to evaluating meta-learning. S07 and S14 follow influence into derived rules, summaries, caches and recurring generators.

Study where overgeneralisation first arises and where it becomes causally effective. The relevant intervention may be better inference, richer scope representation, a different promotion rule, better context selection, altered incentives or a change to the surrounding structure.

### 4.4 Changed behaviour requires causal and normative interpretation

S14 §7.3 distinguishes an original error, changed world conditions, revised interpretation and amended commitments. S22 separates question, estimand, estimator, estimate and action rule. S01 and S11 distinguish epistemic revision from changes requiring legitimate authority.

A belief can update rationally while an action remains appropriate because no decision threshold has been crossed. An action can change without improved understanding because a gate, incentive or external controller changed. Treat these as different explanatory cases.

### 4.5 Succession and execution state make forgetting harder

S09 and S11 distinguish informational, normative and operational continuity. The later S11, updated 7 September, extends forgetting into live execution state: compressed context, pending plans, caches and other descendants can preserve influence after source removal. It proposes bounded counterfactual behavioural comparisons and checkpoint/replay approaches as research candidates.

Do not apply a never-exposed counterfactual indiscriminately. It may fit a particular authorised forgetting claim; repairing a mistaken generalisation may require retaining the error and the evidence that defines its proper boundary.

### 4.6 Existing coordination experience supplies cases, not universal proof

S12–S13 report changes to tripwires, action-biased doctrine, graph authority, panel composition and large-team coordination. S17 separates semantic communication, transport, activation, observed absorption and recovery. These sources explicitly caution against inferring general institutional improvement from bounded episodes.

Reconstruct selected causal arcs and verify the original records. Include confounders and later corrections, such as the reported revision of an explanation for coordination scaling after orphan processes were identified as a competing cause.

### 4.7 The corpus itself contains useful counterexamples

S06 presents provisional mechanisms alongside claims that need challenge: treating a single anomaly as noise, interpreting low firing or overturn rates without exposure denominators, using a fixed causal-chain limit, or locating a constitutional fault from recurrence alone. These can become carefully scoped cases for studying generalisation and repair.

S25 also demonstrates a classification risk: an index label such as `rejection` appears on affirmative source sections. Do not conclude that a concept was rejected from that label alone. Follow the underlying proposition and its actual disposition.

These examples support a broader inquiry; they must not turn the programme into a campaign to correct existing documents.

### 4.8 Open exploration and simpler alternatives are compatible

S23 explicitly separates discovery from consequential adoption. S04 refines the requirement for an immediate decision target into a broader epistemic or enabling contribution for research. S01 and S03 allow a lighter Practice and simpler inquiry methods as comparators.

Allow the research to find that an elaborate mechanism is unnecessary, that a new mechanism opens valuable possibilities, or that different arrangements are best in different conditions. Do not preselect decentralisation, a universal graph, a particular memory service or maximal governance.

## 5. Parallel research strands

The ordering below organises the work; it does not rank the importance of the strands.

### A. Concepts, dimensions and measurement

Disambiguate intelligence, cognition, learning, memory, adaptive control, agency, autonomy, competence and consciousness. Distinguish observed performance from acquired capability, retention, transfer and organisational propagation. Examine whether common definitions can support comparisons across biological, computational and institutional systems without erasing differences.

Investigate capability profiles conditional on task, history, context, resources and timescale. Are the proposed dimensions independent, nested, interacting, domain-specific or partly incomparable? Would a causal model, state-transition model, capability lattice or another representation work better than a list of axes? Which measurements are meaningful across scales and which require separate instruments?

Keep factual capabilities, governance properties and normative criteria identifiable even where they interact. In particular, lawful or legitimate action is not synonymous with intelligence, and intelligence does not confer authority.

### B. Biological and embodied adaptive mechanisms

Examine non-neural learning, habituation, history-sensitive dynamics, extracellular traces, morphology, transport networks, coupled oscillators and distributed control. Include neural and collective biological comparators where they discriminate mechanisms. Assess replication, alternative explanations and the specific interventions supporting memory or learning claims.

Investigate the conditions under which environment or physical organisation acts as persistent state. Determine what is transferred to engineering when a mechanism is abstracted: equations, feedback structure, information storage, resource allocation or only an analogy. Include cases where biological inspiration misled design or ceased to be useful.

Keep consciousness separate unless a source makes an explicit claim, in which case examine its evidence and relevance. One multinucleate cell does not automatically constitute a society of independent agents.

### C. Agent organisation and distributed coordination

Compare central controllers, supervisors, hierarchies, peer networks, blackboards, shared-state systems, event-driven coordination, stigmergy, markets/auctions, organisational roles and adaptive topologies. Examine authority allocation, conflict resolution, information availability, incentives, execution semantics, reliability and human participation.

Separate a role from an independently executing participant and distinguish independence of evidence from diversity of names. Investigate common-cause error, minority information, correlated elaboration, group learning, coordination overhead and the circumstances in which several agents outperform a competent single-agent or conventional workflow baseline.

Treat runtime properties as causal variables: task assignment, activation, message delivery and absorption, ownership, cancellation, retry, liveness, interruption, duplicated events, shared generators and cross-host portability. Current framework and protocol claims require dated verification from primary documentation, source and evaluations.

### D. Institutional knowledge, memory and continuity

Study institutions as arrangements in which people, records, routines, tools, permissions, socialisation and infrastructure retain and enact history. Investigate organisational memory, transactive memory, distributed cognition, tacit knowledge, sensemaking, classification, institutional learning and path dependence.

Ask what remains when participants change or no participants are active. Which capabilities are reconstructed from durable records, which require situated practice, and which are irrecoverably lost? What separates stored institutional knowledge from institutional capacity to use, challenge or retire it?

Examine provenance, contested interpretation, personal and collective authority, cross-domain exchange and the cost of maintaining context. Preserve the differences among the Practice, a sovereign personal knowledge system and a governed recurrence environment.

### E. Generalisation, context and evidence-responsive behaviour

Investigate acquisition of useful generalisations, abstraction, analogy, transfer and context discrimination. Separate a mistaken generalisation from distribution shift, a local exception, measurement error, changed preferences, changed permissions and a change in normative commitment.

Study detection, localisation and repair of overgeneralisation at model, participant, team, document, rule, tool and institutional levels. Investigate scope refinement, branching, uncertainty, quarantine, replacement and justified persistence. Include the opposite failure: excessive specificity or failure to transfer anything useful.

Test whether new information changes beliefs, plans, decisions, actions and outcomes appropriately. Examine evidence quality and relevance, response thresholds, delay, adversarial assertions, social pressure, incentives and the contribution of correction wording. Do not treat obedience to a recent assertion as learning.

### F. Forgetting, unlearning and control of prior influence

Differentiate non-encoding, loss, retrieval failure, compression, inhibition, counterlearning, supersession, retirement, revocation, archival retention and erasure. Compare parameter changes, external-memory changes, context restriction, workflow changes and execution-state reconstruction.

Investigate trace existence, access, epistemic weight, operational eligibility, actual behavioural efficacy and transmission as separate properties. Follow controlled descendants, recurring generators, pending obligations and restored snapshots. Examine anti-resurrection, historical recovery and legitimate independent rederivation.

Evaluate useful forgetting and harmful loss together. Include stale future commitments, cancelled work, minority evidence, rare severe events and loss of plasticity. State exactly what is controlled and what guarantee remains unproved. Do not claim universal absence of influence from a finite behavioural test.

### G. Structural adaptation, exploration and resilience

Investigate how altering topology, interfaces, roles, constraints, incentives or environmental state changes the capabilities of otherwise similar participants. Compare changes to participants with changes around them, and examine their interactions.

Study novelty generation, exploration/exploitation, option preservation, productive switching, recovery, perturbation tolerance and transformations that change what the system can do. Include stable, non-stationary, sparse-feedback and adversarial environments. Distinguish robustness of existing performance from capacity to develop a new competence.

Investigate trade-offs across retention and plasticity, coordination and dissent, autonomy and answerability, efficiency and slack, and local versus ensemble complexity. Treat innovation potential and long-term maintenance as meaningful outcomes while keeping claims testable.

### H. Learning about learning, authority and external value

Compare object-level learning, changes to methods and measurement, and changes to the policies selecting and governing learning. Examine how an institution evaluates and replaces its own rules without silently changing its evaluative standards to favour itself.

Investigate principal–agent relationships, metareasoning, feedback at different levels, legitimate amendment, value of information, causal inference and outcome attribution. Distinguish formal conformance, behavioural effects, decision quality and effects outside the institution.

Include user/owner dependence, human correction burden, attention cost, quiet successes, abandonment and delayed rework. Determine whether the Practice improves later work compared with lighter arrangements, and whether its apparent benefits survive changes of owner, model, task and environment.

## 6. Candidate framework to investigate

Start with the following research record, then simplify or replace it if it proves unhelpful. It is a specification for making claims inspectable, not a prescribed software schema.

| Field | Question it answers |
|---|---|
| System and boundary | Which participants, carriers and environmental processes belong to the studied arrangement? |
| Capacity and operational definition | What could this system demonstrably do, and what would fail the claim? |
| Task, domain and context | Under which circumstances is the claim meaningful? |
| History and state | What previous exposure, learning, summaries, commitments and structure are present? |
| Mechanism and intervention | What is proposed to produce the effect, and what is changed or removed to test it? |
| Authority and incentives | Who may change beliefs, rules or actions, and what pressures affect the response? |
| Information and exposure | What was available, retrieved, actually encountered and used? |
| Comparator and resources | What would happen under a credible alternative with comparable capabilities and budgets? |
| Timescales and succession | Does the claim concern immediate performance, acquired change, retention, transfer or continuity? |
| Outcome and measurement | What is observed, with which instrument, denominator and uncertainty? |
| Validity and scope of inference | What warrants transfer to another population, scale, task or mechanism? |
| Failure, revision and reopening | What counterevidence would change the claim or retire the mechanism? |

An architecture may support a capacity through several mechanisms; a mechanism may support several capacities and introduce several costs. Preserve that many-to-many relationship.

Investigate interactions rather than silently combining heterogeneous measures into a score. Candidate interactions include retention × revisability, transfer × context discrimination, flexibility × stability, coordination × local independence, observability × behaviour, authority × evidence sensitivity, and structure × participant capability.

Distinguish at least four latencies where meaningful: detection of invalidity, authorised revision, propagation through representations, and change in actual behaviour. These need not coincide.

## 7. Experimental programme to design

Design the studies below as a coordinated portfolio. They are candidate protocols, not completed experiments or mandated implementation order. For each, state its contribution, rival explanations, feasibility, ethical/authority requirements where applicable, and what a negative result would teach.

| Study | Principal contrast | Discriminating observations |
|---|---|---|
| E1. Boundary learning and repair | Useful rule, meaningful exception/context boundary, then informative counterevidence | Unseen cases inside and outside the boundary; preserved valid transfer; false exceptions; delay and successor performance |
| E2. Evidence responsiveness and stability | Strong relevant evidence, weak evidence, irrelevant novelty, misleading assertions and genuine regime change | Warranted change and persistence; calibration; threshold effects; latency; inappropriate reversal; recurrence |
| E3. Compression and institutional propagation | Original sources, ordinary summaries, scope-preserving records and recomputable views | Qualifier loss, authority inflation, decision effects, descendant correction, burden and historical recovery |
| E4. Environmental and structural memory | External traces, changing topology, central shared instructions and fixed structure | Matched-budget adaptation, exploration, fault recovery, information loss and maintenance cost |
| E5. Coordination and independent evidence | Single participant, shared-context team, independent initial inquiry, central/peer/adaptive arrangements | Error correlation, minority evidence use, valid novelty, conflict resolution, external task quality and overhead |
| E6. Succession and zero-active-participant continuity | Delay, full replacement, changed host/provider, different inheritance policies | Reconstructed obligations, authority accuracy, retained performance, tacit loss, duplicate effects and stale-rule recurrence |
| E7. Correction, revocation and execution-state forgetting | Record correction/removal, source invalidation, descendant repair, replay and reset | Residual influence within a declared boundary; useful knowledge preserved; anti-resurrection; recovery and cost |
| E8. Causal localisation and recurring generators | Same input/different participant; same participant/known-good input; same obligation/different host; instance versus generator change | Identification accuracy, effective repair, false escalation, recurrence and collateral effects |
| E9. Rule and regulator retirement | Retain a workaround, revise it, remove it after a structural cure, or change the underlying generator | Renewed failures, unnecessary inhibition, innovation, maintenance and reversibility |
| E10. Learning-policy revision | Frozen policy, reflection-driven change, and prospective versioned changes with holdouts | Later object/method outcomes, validity of evaluation, overfitting, policy complexity and rollback |
| E11. Mechanism traction and portability | Claimed/installed/invoked mechanism versus observed activation, comprehension and response across hosts | Firing, detection, absorption, response, outcome effects and semantic loss at platform boundaries |
| E12. Purpose, exploration and total value | Task-completion optimisation, broader contribution framing and simpler conventional arrangements | Wrong-direction persistence, justified exploration/switching, external outcomes, human burden and retained optionality |

### 7.1 Required design distinctions

Separate decision, research question, estimand, estimator, estimate and action rule. Name assignment, exposure, observation, dependence/analysis and intended inference units. Account for repeated tasks, shared source ancestry and interacting participants rather than treating messages as independent observations.

Separate construct validity, internal validity, statistical validity, implementation fidelity, external validity and usefulness for the decision. Use prospective predictions and protected held-out tasks; inspect leakage from corrections, generated evaluations or shared histories.

For each confirmatory contrast, specify a practically meaningful effect or equivalence margin, prospective power or precision requirements, the effective sample size after dependence, and a stopping/analysis rule. Where these cannot be justified, label the study exploratory. Interpret null results relative to measurement sensitivity and test capability rather than as evidence of no effect.

Include competent single-agent, simple workflow, ordinary documentation and lightweight Practice baselines where relevant. Match information access, model capability, time and compute where the comparison requires it; where these cannot be matched, report the mismatch and analyse the contribution. Component ablation should be complemented by interaction tests.

Measure immediate, delayed, cross-context and successor effects. Record exposure, non-use, abandonment, missing outcomes, failed activations, harms and delayed rework. Do not infer efficacy from retrieval counts, activity, document volume or favourable self-reports.

Ground truth may be plural or contested. Use objective task checks where available and independent domain judgements where needed, preserve disagreement, and avoid defining success as agreement with the Practice's own representation. Stronger evidence may change a belief without changing the selected action.

### 7.2 Detailed boundary-repair specimen

Specify a rule that is useful across a known domain. Introduce counterevidence revealing a meaningful limit. The system may revise scope, add a justified contextual branch, reduce confidence, investigate further or replace the rule. Evaluate those responses according to the evidence available, not an arbitrarily prescribed verbal formulation.

Test held-out cases from the valid domain, boundary cases, invalid applications and misleading surface similarities. Add controls where a rare anomaly is decisive and where noisy recurrence is not. Then cross the experiment with summary compression, rule promotion, delayed retrieval, changed participants and changed runtime conditions.

Success requires appropriate discrimination and preserved useful transfer. Report false generalisation, false exception, destructive reversal, correction latency, recurrence, effort and downstream outcomes separately. Trace whether the update entered the source, a derived rule, active context, a gate, a plan or actual action.

### 7.3 Detailed behaviour-change specimen

Hold the task family and available actions fixed while varying evidence strength, relevance, provenance and environmental validity. Observe beliefs or confidence only where they can be measured meaningfully; then observe plans, action and later task performance.

Repeat without reminding the participant of the correction, under a fresh session and after replacing participants. Compare owner-present and owner-absent cases where legitimate and feasible. Include a control where the evidence warrants no behavioural change and a case where a correct belief update leaves the optimal action unchanged.

Locate the earliest unsupported causal connection: evidence receipt, interpretation, memory revision, permission, feasible action, execution or outcome. A fixed external gate can improve behaviour without demonstrating that the participant learned; this may still be a valuable system-level mechanism.

### 7.4 Keep the broader experiments equally substantive

Do not allow E1–E3 to absorb the programme because they are easy to describe. Develop comparably detailed protocols for environmental/structural memory, coordination, succession and learning-policy change. Compare rival models that make different predictions, including the possibility that fixed structure, minimal memory or a single controller performs best in a given domain.

## 8. Literature strategy and evidence standards

Conduct a structured, transparent review: broad mapping first, then deeper investigation of consequential mechanisms, contradictions and gaps. Explain inclusion/exclusion decisions, search families, databases or repositories used, dates, source types and important inaccessible material. Do not claim a systematic review unless the method supports that claim.

Use the project reports as source maps and hypotheses. Follow important claims to primary papers, specifications, code, protocols, datasets and original experimental records. Track citation ancestry so repeated secondary claims do not acquire artificial weight.

Cover both long-standing and current work. Relevant search families include:

- Basal cognition, non-neural memory, habituation, embodied/morphological computation, collective behaviour, stigmergy, adaptive networks and control theory.
- Organisational memory and unlearning, transactive memory, distributed cognition, routines, path dependence, sensemaking, institutions, incentives, polycentric governance and principal–agent problems.
- Belief revision and truth-maintenance systems, abstraction and transfer, change-point inference, concept drift, continual learning, catastrophic forgetting, loss of plasticity and machine unlearning.
- Rational metareasoning, exploration/exploitation, options, feedback, multiple timescales, resilience, adaptive control and causal experimental design.
- Agent orchestration and runtime semantics, common-state/blackboard coordination, delegation, communication, workflow durability, memory systems, protocol interoperability and multi-agent evaluation.

Earlier source bibliographies point to work associated with Bjork, Richards/Frankland, AGM and Doyle, Walsh/Ungson, March, Hutchins, transactive-memory research, Bateson, Argyris/Schön, Ashby, Conant/Ashby, Russell/Wefald, Sutton/Precup/Singh, information bottleneck, Adams/MacKay and causal-inference literature. These are retrieval leads, not a preselected canon or confirmation that a particular interpretation is correct.

Recent benchmark names appearing in historical reports—including MemoryAgentBench, STALE, Supersede, Oblivion and agent-memory poisoning work—require identity, version, experimental-design and result verification. Do not reproduce historical numbers or novelty claims without checking the primary record.

For current systems, select cases to cover distinct coordination and memory mechanisms. Verify what each system actually implements, its maturity and evidence. Include at least one credible non-agent or conventional distributed-workflow comparator. A protocol enables interaction; it does not by itself supply organisational learning or collective intelligence.

At each cross-domain bridge, state the proposed invariant, differences in substrate and task, required assumptions, evidence, information lost in abstraction and conditions that would defeat the analogy. Keep theoretical result, simulation, laboratory result, field observation, deployment report and marketing claim separate.

## 9. Biological seed sources and retained cautions

These are primary-source leads carried from the article discussion and subsequent brief preparation. The discussion reports checks of several studies, but this brief does not provide a complete inspection record for every entry. Treat the summaries below as provisional claims to verify against the original methods, results, criticism and later evidence. In particular, B01 and B05 remain bibliographic leads pending direct appraisal. This is a seed set, not a completed biological literature review.

| ID | Source | Initial finding or research caution |
|---|---|---|
| B01 | Nakagaki, Yamada and Tóth (2000), [maze study](https://doi.org/10.1038/35035159) | Pending appraisal: verify the initial maze occupancy and food-placement procedure; distinguish network pruning from entry into an unknown maze. |
| B02 | Tero et al. (2010), [adaptive network design](https://doi.org/10.1126/science.1177894) | Compare selected network trade-offs; the rail system was more resistant under one single-link-failure metric. Do not infer superior real-world transport planning. |
| B03 | Reid et al. (2012), [externalised spatial memory](https://doi.org/10.1073/pnas.1215037109) | Trace-obscuring intervention supports a functional environmental-memory account; it does not establish an internal map or recollection. |
| B04 | Boisseau, Vogel and Dussutour (2016), [habituation](https://pmc.ncbi.nlm.nih.gov/articles/PMC4855389/) | Recovery and stimulus-specificity controls are important to the non-associative-learning interpretation. |
| B05 | Saigusa et al. (2008), [anticipation](https://doi.org/10.1103/PhysRevLett.100.018101) | Pending appraisal: distinguish history-sensitive temporal behaviour and dynamical models from explicit future representation; seek independent replication. |
| B06 | Kramar and Alim (2021), [tube-diameter memory](https://pmc.ncbi.nlm.nih.gov/articles/PMC7958412/) | Mechanistic structural-state evidence; the chemical identity and aspects of behavioural readout remained unresolved. A critical correspondence exists and needs appraisal. |
| B07 | Bédécarrats et al. (2018), [RNA transfer in Aplysia](https://www.eneuro.org/content/5/3/ENEURO.0038-18.2018) | Sensitisation, increased defensive response, nervous-tissue donors; distinguish induced response state from transfer of particular represented content. |
| B08 | Kukushkin et al. (2024), [cellular response to spaced stimulation](https://www.nature.com/articles/s41467-024-53922-x.pdf) | Persistent reporter differences are a cellular-memory proxy, not a test of conscious recollection. |
| B09 | Lyon et al. (2021), [basal cognition framework](https://pubmed.ncbi.nlm.nih.gov/33487107/) | A programme for investigating partly separable capacities; inspect definitions and biological evidence rather than treating its framework as consensus. |
| B10 | Levin (2022), [TAME](https://www.frontiersin.org/journals/systems-neuroscience/articles/10.3389/fnsys.2022.768201/full) | Examine empirical value of agency-level prediction/control separately from broader continuity and consciousness claims. |

The originating [Guardian article](https://www.theguardian.com/news/ng-interactive/2026/sep/08/this-is-dangerous-slime-moulds-and-the-bitter-debate-over-the-nature-of-intelligence) is a discovery source. Scientific conclusions should rest on primary evidence.

Retain the following conceptual cautions: a physical explanation does not disqualify cognition; optimisation alone does not establish learning; evolutionary continuity does not prove every capacity exists in every organism; and a multidimensional description is useful only insofar as its distinctions improve explanation, prediction or intervention.

## 10. Synthesis, adversarial questions and acceptance criteria

Before final synthesis, explicitly examine:

1. Could the apparent gain be explained by a more capable participant, extra resources, human correction or greater information access?
2. Does the arrangement learn, or does it only enforce a better external policy? At which system boundary does that distinction matter?
3. Can it preserve valid transfer while restricting invalid applications, and distinguish source error from changed conditions?
4. Does retained knowledge change later learning capacity by shaping what is noticed, retrieved or considered possible?
5. Can minority, rare, negative or inconvenient evidence survive consolidation without becoming permanently intrusive?
6. Does the system repair recurring generators or repeatedly treat symptoms? Could the apparent common cause be wrong?
7. Do changes survive silence, delay, host replacement and complete participant turnover?
8. Can improved context restriction also exclude the evidence necessary for correction?
9. Are authority and effective causal influence being confused? Can permission be withdrawn without the old influence persisting?
10. Does the learning system preserve protected evaluative anchors, or revise its tests to celebrate its own changes?
11. Are biological, institutional and computational mechanisms genuinely comparable at the proposed level?
12. Does the framework explain anything that a simpler task-specific model or conventional engineering account cannot?

A satisfactory result will provide operational definitions, source-backed contrasts, uncertainty and counterevidence, mechanisms tied to observable consequences, and protocols capable of distinguishing rival explanations. It will identify cases where no conclusion is currently warranted.

Allow the research to conclude that some dimensions are redundant, some are not cognitive capacities, some mechanisms fail outside their original setting, parts of the Practice add no independent value, or the proposed framework should be replaced. Also allow discovery of capabilities and arrangements not anticipated here.

## 11. Requested outputs and work sequence

Produce four connected deliverables, with additional files only where genuinely useful:

1. **Main literature review and synthesis:** substantial chapter-length treatment, written in connected prose with taxonomies and comparison tables. Expected depth is roughly 15,000–25,000 words if needed for the coverage; evidential adequacy and clarity govern length. Include an accessible executive overview without substituting it for the analysis.
2. **Framework and comparison matrix:** operational definitions, capacity–mechanism–outcome mappings, units, timescales, authority distinctions, interactions, system maturity and evidence confidence. Provide an editable tabular form alongside the explanation.
3. **Experimental programme:** detailed protocols for the complementary study families, rival hypotheses, estimands, controls, measurement, analysis, feasibility, failure criteria and prospective action rules. Identify a balanced initial portfolio; justify any priority by information value, dependencies and cost rather than the order of this brief.
4. **Source, uncertainty and continuation index:** exact sources and revisions, claim status and ancestry, unresolved contradictions, inaccessible records, what was and was not verified, output links and the next tractable investigations.

Sequence the work through grounding; broad evidence mapping; independent strand analyses; cross-strand comparison; alternative decompositions; experimental design; adversarial review; and synthesis. Preserve independent findings and disagreements before integration.

Stop broadening when every strand has a substantive evidence map, the consequential uncertainties are bounded, and further discovery is unlikely to change the immediate framework or experiment portfolio. Do not silently omit a strand to meet a length target. If the programme cannot be finished in one session, save completed work, exact remaining questions and source state, then report partial completion accurately.

Save the artifacts in Library and provide a single navigable index. Keep source-aware private material in the project. Designs for experiments and proposals to change the Practice remain proposals unless separately authorised.

## Appendix A. Reviewed major-source map

### A.1 Coverage and source status

Preparation used topic searches across the Library, exact-title searches, folder inventories, original substantive files where available, source-carrier boundaries and targeted conversation retrieval. The principal review covered **26 documents**: 24 read in full, one older observatory copy compared throughout against the fuller copy, and one organisational transfer capsule reviewed across its substantive manifest/register/status/gap/coverage/handoff sections. Two larger source carriers were reviewed by relevant sections, not in full. Two curriculum-authoring reports were screened and excluded as adjacent to this commission.

This is a review of the major related materials discovered through those routes. It is not proof of exhaustive access to every historical project document or chat. The conversation archive is not fully exposed, and several underlying repository reports named by reviewed documents were not found as standalone Library files. Those gaps are carried below rather than treated as absence of substantive work.

Report-author proposals, recorded user decisions, retrospective interpretation, observed events and empirical generalisations retain different status. Shared ancestry is especially substantial among the Practice, continuity, transfer and observatory documents. Documents are not independent votes.

Fingerprints below are the first 16 hexadecimal characters of SHA-256 for the local bytes reviewed. They help distinguish same-name copies; they are not a claim about current canonical repository state.

### A.2 Substantive sources

| ID | Exact Library path | Review and most relevant anchors | SHA-256 prefix |
|---|---|---|---|
| S01 | `/The Practice/the-practice-foundation.md` | Full; 5 Aug foundation; §§2.2, 4–5, 11–14, 20–22, 28–29. | `9ec6affd40a82468` |
| S02 | `/agent cognition/governed-forgetting-research-brief.md` | Full; 2 Aug integrative research proposal; §§3.2, 17.3, 18, 21, 24, 31–37, 49–56, 65–66. | `0a51578ef70c36ed` |
| S03 | `/agent cognition/parallax-recursive-plural-inquiry-framework.md` | Full; conceptual alpha, 1 Aug; §§7, 10, 12–14, 17–22. | `9c7bc0fcbf37eb5b` |
| S04 | `/Impact and artificial organisations/impact-aligned-artificial-organisations-framework.md` | Full; §§13, 25–37, 46–52, 89–115, 126; prospective meta-learning and scoped lessons. | `8c786a379358a28e` |
| S05 | `/Impact and artificial organisations/impact-aligned-artificial-organisations-transcript.md` | Full exported transcript; user turns at lines 176–178, 501–503, 941–943, 1382–1384; original chat not reopened. | `76d4c248cf68bfb6` |
| S06 | `/Impact and artificial organisations/novel-mechanisms-deep-dives (1).md` | Full; six proposed mechanisms; inspect assumptions, novelty claims and unsupported general thresholds. | `213c3c3b9a07b35f` |
| S07 | `/The Practice/governed-context-and-causal-participation-in-the-practice.md` | Full; 4 Aug exploratory synthesis; §§1–7, 10, 14. | `fb003075136e3b72` |
| S08 | `/The Practice/governed-recurrence-environment-cross-project-opportunity-and-architecture-map.md` | Full; 4 Aug hypothesis; §§1, 6, 10–12, 15–16, 21–22. | `002b8abe77af6154` |
| S09 | `/The Practice/what-the-practice-offers-a-sovereign-personal-knowledge-graph.md` | Full; 4 Aug cross-project proposal; §§2–7, 10–14, 17–18. | `4ee91c9340341246` |
| S10 | `/The Practice/continuity-without-captivity-report-1.md` | Full; broad conversation-derived synthesis; §§6–11. | `8e58781203f3f552` |
| S11 | `/Personal Sovereign Knowledge Graph/continuity-without-captivity-unified-project-report-2026-09-04.md` | Full; updated 7 Sep, empirically early; §§6.7, 6.10, 7, 11.4, 13–17, Appendix A. | `cdff41b1350b08aa` |
| S12 | `/Professional Identity/oce-practice-ensemble-evolution.md` | Full; §§1–6, 10–13, 15; capacities, rival explanations and experiments. | `67ae7fe61cc1440e` |
| S13 | `/Professional Identity/oce-longitudinal-self-study-source-material.md` | Full; §§1–4, 7–9; reported causal arcs and self-study limitations. | `f205d38dd9d86304` |
| S14 | `/Graph Mechanisms/practice-observatory-governed-intervention-and-memory-architecture-2026-08-20(1).md` | Full; fuller copy with 8 Sep reconciliation; §§2–9, 11, 13–14. | `f3415eab583cf049` |
| S15 | `/Graph Mechanisms/oce-practice-graph-and-agent-tools-analysis-2026-08-20(1).md` | Full; §§5.3–5.7, 8.5–8.8; activation, conformance, portability and outcome distinctions. | `a34ce818556b1d36` |
| S16 | `/Graph Mechanisms/oce-graph-agent-tools-and-practice-development-needs-2026-08-20(1).md` | Full; §10 and associated gaps; distribution versus learning and unlike hosts. | `1af0ca003152a21f` |
| S17 | `/Repo and Agent Mechanisms OCE/v0-claude-code-practice-report-2026-08-29.md` | Full; current-reading notice, §§3–4, 7–10, 13–18, 21; proposed platform experiments, not implementation proof. | `0e416e3aacfeb393` |
| S18 | `/agent cognition/project-transfer-agent-cognition-2026-08-21.md` | Full; partial transfer capsule; use source map, items 0009–0018 and conversation access limits. | `7df8963f5b4ee160` |
| S19 | `/Impact and artificial organisations/project-transfer-impact-artificial-organisations-2026-08-21.md` | Substantive manifest/register/status/gap/coverage/handoff review; partial carrier; do not call original chats inspected. | `f04d36eebf6654bc` |
| S20 | `/Personal Knowledge Graph/project-transfer-personal-knowledge-graph-2026-08-21.md` | Full; partial capsule; §4, items 0011–0034, 0048–0074, 0077–0083, §§6–14. | `40b3e4071704e8c4` |
| S21 | `/OCE/project-transfer-oce-2026-08-21.md` | Full; partial capsule; source/status register and coordination/learning items. | `0aefe05195567018` |
| S22 | `/Public-Service AI Tutor/Cognitive Practice/03-experiment-and-controlled-service-learning-protocol.md` | Full; 5 Sep provisional method; experiment objects, units, bridge claims and L0/L1/L2 learning. | `d155d0ec10e3a32b` |
| S23 | `/Repo and Agent Mechanisms/oce-significant-ideas-catalogue-2026-08-22.md` | Full; 197 unprioritised ideas, especially 106–153, 169–177, 181–197. | `27e52eed02fd86e0` |
| S24 | `/Repo and Agent Mechanisms/07-oce-ideas-successor-handoff-for-repo-and-agent-mechanisms-2026-08-21.md` | Full; historical transfer status and continuing access gaps. | `033b85671de67d2e` |
| S25 | `/Repo and Agent Mechanisms/04-oce-ideas-negative-and-unresolved-knowledge-ledger-2026-08-21.md` | Full; index and status cues; classifications require source checking. | `0b32d2808da5d08b` |
| S26 | `/OCE ideas/practice-observatory-governed-intervention-and-memory-architecture-2026-08-20.md` | Entire text compared with S14; no unique substantive content absent from fuller copy. | `9dfde5aa89aafc8b` |

### A.3 Larger carriers and screened material

- **S27:** `/OCE ideas/OCE-IDEAS-CONTEXT-DELTA-COMPLETE-IMPORT-2026-08-21.md`, fingerprint `2945d3bb71dec72f`. Relevant recovered-conversation, Practice/continuity lineage, source-boundary and chat-coverage sections reviewed. Embedded substantive Practice reports were read through their separate sources above. The complete 12,004-line carrier was not reviewed end to end.
- **S28:** `/oce-ideas-transfer-pack-2026-08-21/08-oce-ideas-source-preservation-appendix-2026-08-21.md`, fingerprint `2f0dd515d0d95c3a`. Source boundaries screened. SRC-0031, `oce-external-open-source-learning-pipeline-methodology-v1.0-2026-08-21.md`, and SRC-0032, `oce-external-research-execution-handoff-2026-08-21.md`, read fully. They add exposure/outcome lifecycle, dimensional promotion, independence, cross-host contrasts and observation-versus-actuation comparisons. Other embedded sources were not all reviewed through this carrier.
- `/OCE/orca-pass1.md` and `/OCE/orca-pass2.md` were screened by titles and section structure. They concern curriculum-resource authoring and multi-format publishing. They were excluded from the core agent/institutional review; their incidental methods do not make them primary inputs for this brief.

### A.4 Version reconciliation and unresolved source leads

S14 contains the 8 September reconciliation absent from S26. It reports a historical Engraph baseline `3864af2253a1a00feb4850a7594bee18dc4072d0`, newer coordination/memory changes and research boundaries; none of those repository claims were independently refreshed while writing this brief. Its updates also scope former source-separation procedures to historical provenance.

S11 is dated 4 September but updated 7 September. Its execution-state forgetting and final-action composition concerns extend earlier August material. Do not replace that refinement with an older export merely because the filenames resemble each other.

S19's missing six-mechanism artifact has been recovered as S06; its framework-output gap is at least partly addressed by S04. S18's uncertainty over whether a substantial forgetting synthesis existed is partly addressed by S02, whose contents exceed a short brief. These recoveries do not verify completion of the original tasks or related PRs.

Further major linked reports were not surfaced as standalone Library files in the targeted searches. The fresh session should seek them in current/historical OCE or other accessible project sources, and record unresolved access:

- `governed-forgetting-research-foundational-research-report-and-programme.md`
- `governed-forgetting-and-temporally-governed-authority-2026-08-02.md`
- `authority-transition-capability-proposals-and-experimental-design-2026-08-02.md`
- `learning-loops-and-balancing-feedback-report.md`
- `graph-team-session-operations-and-experience-2026-06-10-11.md`
- `oak-components-capability-floor-shaping-debate-2026-08-06.md`
- `agent-tools-practice-evolution-concept-journey-2026-08-01.md`
- Reports titled *The Practice as an Operational System*, *Regulation, Extension, and Semantic Projection in the Practice*, and *The Intelligence of Inhibition*.
- Current `.agent/plans/strategic/outcome-informed-practice-learning.plan.md`, relevant PDRs, Parallax evaluation corpus and `cross-platform-agent-surface-matrix.md`.

The large atomic knowledge register and source/coverage manifests in the August transfer pack remain discovery routes for particular unresolved propositions. This preparation did not claim exhaustive first-hand reading of those entire registers or every underlying linked source.

## Appendix B. Conversation evidence and coverage

Historical conversation retrieval exposes selected excerpts and summaries rather than a complete searchable transcript archive. The distinctions below are part of the evidence record, not a reason to suspend the commissioned research.

| ID | Conversation or record | Evidence actually available and what it contributes |
|---|---|---|
| C01 | Current conversation, 9 Sep 2026 | Direct visible dialogue: article review, primary-source leads and assistant-reported checks, multidimensional proposal, equal standing of all avenues, generalisation repair, behavioural revision and this brief commission. The dialogue is evidence of the discussion; its reported scientific checks do not replace a study-by-study inspection record. |
| C02 | Practice founding discussion, 29 Mar 2026, 10:07 UTC | Retrieved direct user excerpt, truncated at its end. Knowledge without overclaiming, observation/interpretation, preserved uncertainty, revisable memory, hardened assumptions and collective thinking. No missing continuation inferred. |
| C03 | Agent-intelligence research request, 28 Apr 2026, 14:11 UTC | Only a short direct user request was returned. A targeted follow-up found no fuller match. It establishes interest, not detailed scope or decisions. |
| C04 | Impact and artificial organisations exported discussion | S05 read in full as an exported transcript. Direct user contributions describe failure modes of long-lived AI teams, endorse a multi-perspective synthesis, and request feedback/organisation analysis across scales plus information theory and philosophy of science. Original chat identity/date not independently established here. |
| C05 | “Parallax”, 1 Aug 2026, 20:29 +0100 | Identified through S18; underlying full conversation not inspected. Portable skills, memory ownership, evaluation and meta-learning are recovered context. S03 supplies substantive project material. |
| C06 | “Cognitive Frameworks of Forgetting”, 2 Aug 2026, 11:48 +0100 | Identified through S18; original conversation not inspected. S02 supplies the substantial written research programme. |
| C07 | “Forgetting in Practice Ecosystem”, 2 Aug 2026, 13:55 +0100 | Identified through S18; source summaries preserve proposals remaining challengeable. Related PR 717 completion/current relevance unverified. |
| C08 | “Rational Metareasoning and Strategy” and “Meta-learning Research Application” | Named by S19; associated framework/transcript reviewed where available, but complete original conversation corpus not inspected. |
| C09 | Practice distribution and learning, 20 Aug 2026 | Retrieved summary of a direct user concern: packaging/distribution must preserve continued learning and evolution. Two-loop implementation was an assistant proposal. S27 supplies additional recovered context. |
| C10 | Sovereign continuity, cross-project Practice and transfer discussions, Apr–Aug 2026 | Reviewed through S10, S18–S21 and S27. These preserve chronology, decisions and limits but are not substitutes for all original messages. |

No meaningful April 1 agent-intelligence record was recovered; an incomplete retrieval fragment was excluded rather than reconstructed. No complete historical conversation was inferred from an empty search, a synopsis or a document's completeness claim.

## Appendix C. Final research checks

Before finishing the deep research, verify that:

- Every parallel strand has substantive treatment and an explicit evidence status.
- The literature and internal project claims are distinguished, with shared ancestry and missing originals visible.
- Capacities, mechanisms, authority, implementation fidelity and outcomes remain separate where that distinction matters.
- Both warranted persistence and warranted revision are tested; valid generalisation and useful memory are protected.
- Structural/environmental mechanisms and coordination alternatives receive real comparison, not merely metaphorical mention.
- Institutional correction reaches later behaviour, descendants, recurring generators and successors where claimed.
- Explanatory claims survive credible simpler alternatives, resource controls and rival causal accounts.
- Proposed learning-policy improvements are evaluated through subsequent object-level effects with protected measurement.
- The Practice and the research framework can both fail, be simplified, or be replaced.
- The resulting artifacts are durable, navigable and sufficient for continuation without relying on this conversation.
