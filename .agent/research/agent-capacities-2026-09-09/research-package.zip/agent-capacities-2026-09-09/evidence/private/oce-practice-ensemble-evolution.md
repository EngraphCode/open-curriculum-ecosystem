---
title: From repository to recursive cognitive infrastructure
subtitle: How OCE, the Practice, and the wider human-agent ensemble are evolving
date: 2026-08-08
status: reflective source material
authority: non-normative; not an ADR, PDR, DDR, plan, instruction, or implementation decision
repository: oaknational/oak-open-curriculum-ecosystem
repository_baseline: 6b36bdf63642c944c767729de296379f8e1955ef
companion_sources:
  - oce-longitudinal-self-study-source-material.md
  - jim-cresswell-cv-linkedin-evidence-and-language.md
epistemic_posture: >
  Repository records are evidence of recorded decisions, mechanisms, observations, and
  revisions. Claims about the ensemble as a whole are interpretations. Jim Cresswell's
  recollections and lifelong interests are participant annotations and are not independently
  established by the repository.
---

# From repository to recursive cognitive infrastructure

## How OCE, the Practice, and the wider human–agent ensemble are evolving

## Purpose

This report is a companion to the longitudinal OCE self-study. Its narrower purpose is to
describe an evolution that has become easier to see once several strands are considered
together:

- OCE is no longer only a software repository or product codebase.
- the Practice is no longer only a set of engineering conventions or agent instructions;
- the human–agent ensemble is increasingly able to study, encode, exercise, criticise, and
  revise the mechanisms through which it studies, decides, builds, and learns;
- some of those mechanisms now explicitly test whether attempts to improve learning and
  reasoning are themselves effective;
- the same recursive leverage principle has a much longer participant history than OCE,
  although that earlier history is not repository-verifiable.

The report does **not** claim that OCE is a mind, that the Practice is autonomously
self-improving, that recursive machinery necessarily produces better outcomes, or that Jim
personally authored the many agent- and team-produced artefacts in the corpus.

The central observation is more limited and more defensible:

> OCE is evolving into a coupled environment in which product work, research, decision-making,
> memory, assurance, agent coordination, and the improvement of those processes increasingly
> participate in the same feedback system.

A second observation follows from the repository history:

> The system does not merely contain mechanisms intended to improve reasoning and learning.
> Some of those mechanisms have themselves been changed in response to evidence about how well
> they improve reasoning and learning.

That is recursive adaptation in an observable, bounded sense.

---

## 1. Three overlapping systems

It is useful to distinguish three things that increasingly overlap.

### 1.1 OCE: repository, product substrate, evidence store

The Oak Open Curriculum Ecosystem repository contains ordinary software-engineering
artefacts—source code, tests, build configuration, deployment mechanisms and product
surfaces—but it also carries:

- research and explorations;
- architectural, Practice, and design decision records;
- reports and audits;
- plans and plan history;
- operational and learning memory;
- rules, skills, templates, and agent-facing tools;
- coordination protocols and role models;
- falsifiers, predictions, rejected alternatives, retired experiments, and negative
  results.

This means the repository is not simply the place where the system is implemented. It is
also one of the principal places where the system records *how it came to believe what it
currently believes* and *how future participants should challenge those beliefs*.

The repository's own research index makes this distinction explicit: research is intended
to preserve discoveries and insights even when plans disappear; reports carry promoted
syntheses; plans are comparatively ephemeral. That separation creates a knowledge
substrate in which the history of inquiry can outlive a particular implementation.

### 1.2 The Practice: executable theories about how work should happen

The Practice began as, and still contains, practical mechanisms for helping agents and
people work safely and coherently in a large repository. But its centre of gravity has
moved beyond "instructions for agents".

The Practice now contains theories and mechanisms concerning:

- framing and reframing;
- reasoning;
- proportionality;
- concept exploration;
- planning;
- evidence and verification;
- decision records;
- cognitive diversity;
- delegation and agent roles;
- operational continuity;
- memory and forgetting;
- doctrine traction;
- adversarial review;
- learning speed;
- inhibition and operational eligibility;
- how and when these mechanisms themselves should be changed or retired.

A rule, PDR, skill, test or validator is therefore often an **implemented hypothesis about
future cognition or coordination**.

The distinction matters. If the Practice were only documentation, improvement would mean
writing better instructions. Once it becomes a mixed substrate of prose, schemas, tools,
rituals, agent roles, tests, validators, prompts, memory surfaces and evaluation suites,
improvement can change the environment in which later cognition occurs.

### 1.3 The ensemble: people, agents, artefacts, institutions and external reality

The whole operating system is larger than the repository or the Practice.

It includes:

- Jim as a participant, source of intent, critic, ratifier and designer of conditions;
- colleagues and other human specialists;
- agents using different models, harnesses, roles and contexts;
- the Practice and repository as persistent environmental structure;
- product code and deployed services;
- Linear, GitHub, Sentry, PostHog, Clerk, Vercel, Elastic and other external systems;
- Oak as an institution and public body;
- teachers, curriculum leaders, pupils and other affected people;
- AI hosts and standards outside Oak's control;
- incidents, costs, latency, failures, adoption, human attention and institutional risk.

Calling this an **ensemble** avoids two misleading simplifications.

The first is the "tool" model in which Jim thinks and agents merely execute. The corpus
contains many examples of agents generating alternatives, finding counterevidence, changing
a live theory, implementing mechanisms, criticising prior work and producing research Jim
did not pre-specify.

The second is the "autonomous organisation" model in which human purpose and authority
become incidental. The corpus repeatedly shows owner corrections changing the referent,
risk model, value function or authority structure in ways that cannot be derived from
repository consistency alone.

The interesting system is the coupling between these forms of cognition and authority.

---

## 2. The evolution is not a maturity ladder

A conventional story would describe OCE as moving from an immature repository toward a
mature engineering platform.

That is inadequate.

The longitudinal evidence is more consistent with **overlapping changes in what the system
is for, who bears the risk, what capabilities exist, and what questions have become
reachable**.

The early biological architecture, for example, belonged to a lower-consequence
experimental regime. Search research was able to build and remove plausible theories.
The MCP then crossed a boundary from high-impact experiment toward public product. At the
same time, the Practice increasingly became an object of its own research.

A better model is a set of interacting local regimes:

```text
product / technical work
        ↕
research and experimentation
        ↕
decision and assurance machinery
        ↕
learning and memory machinery
        ↕
machinery for evaluating and changing the machinery above
```

Different parts of the system can occupy different regimes at once. A production security
boundary may require strict conservatism while an adjacent research lane remains highly
speculative. A Practice mechanism may be enforced operationally while its underlying
theory remains defeasible.

The system therefore evolves through **temporary equilibria**, not through a one-way
sequence of maturity states.

---

## 3. From solving problems to changing the environment that solves problems

One recurring pattern across Jim's career and the OCE corpus is movement upstream from an
individual task toward the mechanism that produces many future tasks or decisions.

A useful leverage stack is:

| Order | Object of intervention | Example |
| --- | --- | --- |
| L0 | Do the work | implement a search feature, test a service, make an architectural choice |
| L1 | Improve how that class of work is done | build test automation, an evaluation framework, a planning discipline, a reasoning skill |
| L2 | Improve how L1 mechanisms are selected and improved | test whether rules fire, evaluate decision machinery, install tripwires, compare critics and generators |
| L3 | Improve how the system learns whether its improvement machinery works | two-speed learning, predictions and falsifiers on Practice changes, meta-evaluation of learning policies |
| L4 candidate | Use observed downstream effects to revise the system's own model, goals or allocation of cognitive effort | longitudinal self-study, cost/calm research, future external-impact feedback |

These are analytic labels, not prestige levels. L3 work is not automatically more valuable
than L0 work. A recursive mechanism that consumes attention without changing outcomes is
worse than a simple direct fix.

The point is that OCE increasingly makes higher-order intervention *possible and
observable*.

---

## 4. Concrete evidence that the improvement machinery improves itself

The strongest evidence comes from causal chains rather than from self-description.

### 4.1 Passive guidance → perturbation mechanisms → observable tripwires → simplification

[PDR-029: Perturbation-Mechanism Bundle][PDR-029] begins from repeated observations that
correct guidance can exist and still fail at the moment of action. Agents followed the
shape already present in an artefact; passive reminders did not reliably interrupt that
"artefact gravity".

The first response was itself instructional: first-principles prompts, standing-decision
surfaces and re-ratification rituals. The subsequent evidence was uncomfortable: the
documented interventions existed, yet later instances still occurred.

The system then changed its model of improvement. A guardrail was no longer considered
installed merely because it had been written down. The mechanism needed a firing surface.

Later evidence changed the mechanism again:

- tripwires needed an **observable artefact** when they fired, otherwise post-hoc inspection
  could not distinguish "consulted and considered" from "never fired";
- the response should often remain **advisory rather than mechanically enforcing**, because
  mechanical refusal can encourage route-around behaviour and replace judgement with
  compliance;
- the doctrine expanded into identity and shared-git failure classes where the same
  underlying mechanism recurred;
- subsequent review then **simplified** the tripwire model, rejecting layers that were only
  retrospectively counted as protection and removing host-specific accumulation from the
  portable doctrine.

The shape is recursive:

```text
guidance intended to improve action
  → evidence that guidance does not fire
  → tripwire mechanism
  → evidence that firing is not observable
  → observable-firing requirement
  → evidence about enforcement failure modes
  → advisory-response refinement
  → evidence of doctrine accumulation
  → simplification of the improvement mechanism
```

This is not a claim that PDR-029 is now correct. It is evidence that the system changed its
mechanism for improving behaviour because it learned about the failure modes of that
mechanism.

### 4.2 Doctrine traction: improving the model of why improvement fails

[PDR-098: Doctrine Traction][PDR-098] takes the next step.

Instead of asking only "how do we make rules work?", it decomposes doctrine traction into
three independent axes:

1. **firing** — what causes the check to happen;
2. **detection** — how the relevant condition is recognised;
3. **response** — what happens after recognition.

This dissolves an apparent contradiction among earlier Practice theories. A mechanism can
fire mechanically while using cognitive judgement for detection and still leave the final
response advisory.

More importantly, it identifies an **empty quadrant**: action-time, mechanically fired,
cognitively detected, advisory response for semantic failure modes.

The self-referential insight is explicit: the cure for recall-dependent doctrine cannot be
another recall-dependent rule saying "remember to apply the doctrine". That would
instantiate the defect it claims to solve.

The system has therefore improved not merely a guardrail but its **causal model of
guardrail efficacy**.

### 4.3 Fast learning → critique of fast learning → two-speed learning

[PDR-130: Two-Speed Learning][PDR-130] is one of the clearest examples of meta-learning in
the corpus.

The existing Practice had become good at fast learning:

```text
surprise
  → napkin
  → distillation
  → rule / skill / validator
```

That pipeline was useful for operational lessons. But the same pipeline was being used to
promote constitutional-class concepts: changes to how the system learns, decides or frames
work.

The critique is unusually direct: a system that promotes its own mechanisms through
retrospective success narratives cannot distinguish compounding infrastructure from
**"elaborate self-portraiture."**

The response is not to stop learning. It changes the learning system:

- fast operational lessons retain a fast path but acquire an expected observable effect
  and falsifier;
- deeper changes to how the Practice itself learns enter a slow lane;
- slow-lane entries require a prediction, falsifier and review date;
- the mechanism itself carries a self-retirement condition if the slow lane proves to be
  theatre.

This is improvement machinery becoming subject to **prospective experimental design**.

### 4.4 Reframing → a skill for reframing → infrastructure that protects reframing

The Concept Exploration and Planning skills expose another recursive chain.

The underlying cognitive move is familiar: a supplied question may already contain a
solution, sit at the wrong altitude, size the problem incorrectly, or foreclose a more
important question.

The [Concept Exploration skill][Concept-Exploration] encodes a reusable four-movement
process:

1. reflect on raw observations before imposing a frame;
2. define the problem space without naming a preferred solution;
3. reopen the solution space and challenge the fluent first answer;
4. synthesise proportionate proposals with warrants and falsifiers.

The [Planning skill][Plan-Skill] then prevents planning from silently collapsing unresolved
framing questions. It explicitly requires a problem frame of gap, affected party, causal
mechanism, constraints and success, and it requires altitude forks to be surfaced before
plan structure becomes commitment.

The important recursion is:

```text
reframe a question
  → notice reframing as a reusable high-value cognitive move
  → encode a method for reframing
  → make the method available to later agents
  → use that method to reframe later questions
  → observe where the reframing machinery itself fails
  → amend the method or its surrounding Practice
```

The current CV/LinkedIn exploration has itself provided a small worked example. A request
to "rewrite LinkedIn" became, under those skills, a different question: how should a
public professional and research surface system make the underlying work legible and
evidenced?

That is not proof of general effectiveness, but it is a traceable case of the machinery
participating in the cognitive move it was designed to support.

### 4.5 Cognitive diversity becomes a designed variable

[PDR-069][PDR-069] frames doctrine-first and first-principles reasoning as complementary
cognitive modes with different failure shapes. [PDR-123][PDR-123] turns experience from
multi-agent design work into a protocol that distinguishes generators, critics, synthesis
and proportionality.

The important variable is not agent count. It is whether another participant changes the
live theory.

The longitudinal corpus includes examples where:

- critics detect correlated over-elaboration among generators;
- an owner correction changes the referent of the problem;
- a cross-vendor review adds obligations absent from same-context convergence;
- a later observation invalidates an earlier causal explanation.

This gives the system a way to improve **the composition of cognition**, not merely the
content of one reasoning pass.

### 4.6 Parallax moves toward explicit meta-evaluation

The Parallax collection makes this recursive trajectory even more explicit.

Its evaluation suites test not only object-level reasoning but:

- missed activation and inappropriate activation;
- composition across methods;
- handoffs between cognitive artefacts;
- reopening decisions;
- recursive learning;
- metamorphic invariants;
- whether a changed learning policy improved later quality rather than simply reducing
  token cost.

A meta-learning policy therefore becomes something that can itself be evaluated against
downstream reasoning quality, calibration, decisions and outcomes.

That is a substantial move from "we have a good method" to "we need evidence about what
changing the method does".

---

## 5. The whole ensemble is becoming a programmable epistemic environment

A useful way to describe the emerging system is **programmable epistemic environment**.

That phrase does not imply sentience. It means that the environment surrounding a cognitive
act increasingly contains explicit, alterable structures affecting:

- what is remembered;
- what is forgotten or inhibited;
- what evidence is considered authoritative;
- what prompts reflection;
- when a rule fires;
- which cognitive mode or agent role participates;
- how alternative views are generated;
- how disagreement is preserved;
- what may become operational;
- what must remain advisory;
- what is measured;
- what would falsify a theory;
- when an old theory should be reopened.

Traditional organisations contain these mechanisms too, but often implicitly, socially and
unevenly. OCE increasingly makes them inspectable and, in some cases, executable.

This changes the unit of engineering.

The object being designed is no longer only the software product. Part of the object is the
**decision environment that will generate future software and future revisions of that
decision environment**.

---

## 6. Top-down intent and bottom-up emergence

The ensemble has a particularly interesting topology.

Jim supplies important top-down elements:

- mission and purpose;
- value judgement;
- risk tolerance;
- consequential authority;
- framing corrections;
- decisions about what should become operative;
- decisions about what forms of evidence matter.

Agents contribute bottom-up and lateral elements:

- local investigation;
- generated hypotheses;
- implementation;
- critique;
- error discovery;
- pattern detection;
- synthesis;
- alternative frames;
- unexpected interactions across many partially independent sessions.

The Practice forms a middle layer. It is both inherited structure and mutable product of
previous interactions.

A simplified picture is:

```mermaid
flowchart TD
    I[Human intent, values, risk judgement]
    P[Practice: skills, rules, roles, memory, decision mechanisms]
    A[Agent fleet: diverse local reasoning and action]
    R[Repository and deployed product]
    E[External evidence: users, incidents, metrics, institutions, vendors]

    I --> P
    P --> A
    A --> R
    R --> E
    E --> I
    E --> P
    A --> P
    P --> P
    I --> A
```

The self-loop on the Practice is deliberate: Practice mechanisms can cause research and
changes to the Practice itself. But that loop is not closed or autonomous; human judgement
and external evidence remain constitutive.

### Participant context: a much older fascination

Jim adds a personal history that the repository cannot establish independently.

He recalls thinking about the construction of minds since early childhood:

- top-down models of biological cognition;
- bottom-up machine intelligence emerging from fleets of automata;
- and, especially, top-down models composed from fleets of bottom-up automata fleets.

This should **not** be treated as evidence derived from OCE, and it need not appear in a CV.
It is nevertheless useful participant context for understanding why the current work feels
less like a sudden AI-era pivot and more like the arrival of a substrate capable of making
long-standing questions experimentally accessible.

The current ensemble has an evocative structural similarity to that old fascination:
purpose and constraints can be applied top-down while heterogeneous local agents operate
bottom-up, with persistent structures emerging in the middle and later becoming objects of
design.

That is an analogy, not a claim that the ensemble constitutes a mind.

---

## 7. The leverage principle predates the current machinery

Jim also supplies a much older participant principle:

> Learning is valuable, but investing a small fraction of effort in making investment in
> learning more effective can have greater leverage because the benefit compounds through
> future learning.

In his recollection, this intuition predates the first of his three physics degrees.

Again, the repository cannot prove the chronology. What it can show is a modern,
high-resolution manifestation of that principle.

The same shape is visible across career surfaces:

```text
manual testing
  → test automation
  → shared testing machinery
  → quality and CI/CD systems
  → engineering environments
  → decision and assurance environments
  → human-agent learning environments
  → mechanisms for evaluating and changing those learning environments
```

The claim is not that every step was consciously planned as one lifelong programme. The
stronger, more cautious hypothesis is that **the same leverage-seeking habit repeatedly
found expression in the substrate available at the time**.

OCE is distinctive because modern agent capabilities make that leverage loop far more
explicit and much faster to instantiate.

A system can now help research the theory of how it should research, turn the theory into
skills and rules, use them on later work, observe their failure, and propose changes to the
mechanism that proposed the changes.

---

## 8. Productisation couples the recursive system to external consequence

Recursive internal sophistication would be much less interesting if it remained detached
from consequential work.

The Curriculum MCP changes that.

The move from experiment through alpha to public beta means the same ensemble is producing
a public product through which Oak's curriculum can be consumed in AI hosts.

That changes what the recursive loops are allowed to optimise.

When the system was principally experimental, novelty and learning could justify
considerable variation. Once real teachers, pupils, Oak's reputation, privacy, accessibility,
security and institutional trust became risk bearers, balancing loops grew in importance.

The longitudinal readiness work reflects that change: release readiness was reframed away
from authentication and infrastructure milestones alone toward teacher value, pupil
safety, accessibility, operations, legal obligations, institutional risk and evidence of
value.

This external coupling is important because it supplies a potential reality check on the
entire recursive project.

If internal learning machinery becomes more elegant while the public product becomes less
useful, slower to improve, harder to maintain or less trustworthy, the system is not
"improving" in the sense that matters.

---

## 9. Reinforcing and balancing loops

The ensemble contains both reinforcing and balancing feedback.

### Reinforcing loops

Examples include:

```text
better research
  → better mechanisms
  → more capable agents
  → more ambitious research
  → better research
```

```text
better memory
  → less rediscovery
  → more cumulative work
  → more knowledge worth preserving
  → more investment in memory
```

```text
better agent tooling
  → more parallel work
  → more observations and failures
  → more agent-tooling research
  → better agent tooling
```

These loops can create genuine leverage. They can also create runaway complexity.

### Balancing loops

The Practice increasingly develops counterforces:

- falsifiers;
- negative controls;
- adversarial review;
- proportionality;
- friction budgets;
- simplification passes;
- forgetting;
- inhibition;
- retirement conditions;
- decision expiry;
- report-only rather than blocking mechanisms;
- "do not build" and "do not promote yet" outcomes.

The role of these balancing loops is not to reveal a universal optimum. Their interaction
can produce a temporarily useful equilibrium under current constraints.

When the environment changes—new model capabilities, a public release, different risk
bearers, a new host, accumulated process cost—the previous equilibrium may no longer be
useful.

This is why "for now" is an important part of the architecture.

---

## 10. Forgetting and inhibition are signs of a system learning to regulate itself

A system that only accumulates improvement mechanisms is not recursively intelligent; it
is merely recursive accumulation.

The recent forgetting and inhibition research is therefore important.

The Practice has begun to distinguish:

- preserving evidence from allowing evidence to remain operationally eligible;
- remembering a rejected theory from allowing it to govern current action;
- pausing from abandoning;
- deferring from suppressing;
- retiring from erasing;
- operational eligibility from truth or historical importance.

This gives the system mechanisms for **negative selection**.

The next generation of a learning system is not one that remembers everything and adds a
rule for every lesson. It is one that can preserve history while reducing causal influence
when that influence is no longer justified.

That is another form of improving the ability to improve: regulating the accumulated
improvement substrate itself.

---

## 11. What may be emerging

Several interpretations are now plausible.

### 11.1 A repository-native research organisation

The repository supports continuing programmes of inquiry, preserved evidence, experimental
methods, decisions, implementation and later re-analysis across agent sessions.

This resembles an institution of research more than an ordinary codebase.

### 11.2 A programmable cognitive ecology

Different agents, roles, skills and evidence sources occupy different niches. Their
interaction can be designed: generators, critics, Directors, Implementers, independent
reviewers, persistent memory and operational state.

The ecology is programmable because its selection pressures and interaction rules can be
changed.

### 11.3 A portable Practice

As Practice Core, skills and rules become portable, the system is testing whether cognitive
and operational infrastructure can move between repositories without importing every
local historical assumption.

If that works, the Practice becomes less "how OCE happens to work" and more a transferable
experimental substrate.

### 11.4 An experiment in ensemble intelligence

The ensemble exhibits some properties associated with intelligent organisations:

- persistent memory;
- distributed specialised cognition;
- role differentiation;
- feedback;
- conflict and selection;
- explicit uncertainty;
- theory revision;
- adaptation of learning mechanisms;
- inhibition and forgetting;
- ability to act on external systems.

That is enough to make ensemble intelligence a legitimate research question.

It is **not** enough to conclude that the system is a mind, has unified agency, possesses
consciousness, or independently determines its purposes.

### 11.5 A bridge between abstract cognition and public infrastructure

Perhaps the most unusual feature is that the cognitive experiment is not isolated in a
laboratory. It operates inside work that is also building real public digital
infrastructure.

The research substrate and the product substrate are coupled.

That creates both opportunity and responsibility.

---

## 12. Counter-reading: how this could all be wrong

Any account of recursive improvement is vulnerable to becoming self-confirming.

### 12.1 Learning theatre

The system may become very good at producing the artefacts of learning—reports, PDRs,
falsifiers, evaluations, lineage—without materially improving future decisions.

PDR-130 already names this risk.

### 12.2 Owner-model convergence

Agents trained repeatedly on prior corrections may become excellent predictors of Jim's
preferences rather than independent sources of challenge.

Apparent cognitive diversity can therefore conceal a convergent latent model.

### 12.3 Process mass

A system built to help agents think may consume so much agent and human attention that it
reduces actual productive cognition.

The existence of simplification, forgetting and inhibition work suggests this pressure is
already real.

### 12.4 Legibility bias

Mechanisms that produce clear, citable, machine-readable evidence may be selected over
valuable forms of judgement that are harder to formalise.

The system could therefore optimise for what its own infrastructure can see.

### 12.5 Recursive overfitting

The Practice may learn extremely specific lessons from OCE's unusual conditions and encode
them as if they were general cognitive truths.

Portability is therefore an empirical question, not a property granted by putting a PDR in
Practice Core.

### 12.6 Weak external closure

The evidence for internal adaptation is much stronger than the evidence linking that
adaptation to teacher, pupil, institutional or public outcomes.

Until more causal chains cross that boundary, "better at getting better" remains partly an
internal hypothesis.

---

## 13. A future evidence programme for recursive improvement

The next useful questions are empirical.

### 13.1 Mechanism traction

For a sample of rules, skills and PDR-derived mechanisms:

- Did the mechanism fire at the intended moment?
- Did it change an action or frame?
- Did the target failure recur with the mechanism available?
- What false positives or route-arounds occurred?
- What attention and compute did it consume?
- Was it later modified or retired?

### 13.2 Reframing quality

For Concept Exploration, metacognition, reason, proportionality and planning:

- Does using the machinery change the problem statement?
- Do independent readers judge the new frame as more decision-relevant?
- How often does reframing merely produce more abstraction?
- Does the resulting plan become smaller, clearer or more outcome-oriented?
- Are important options preserved that would otherwise have been foreclosed?

### 13.3 Meta-learning efficacy

For PDR-130 and Parallax-style recursive learning:

- Did a learning-policy change improve later object-level decisions?
- Did it improve calibration or defect discovery?
- Did it reduce cost only?
- Did it suppress useful variation?
- What would cause rollback?

### 13.4 Diversity value

Measure **movement**, not panel size:

- How often does an independent critic materially change a live theory?
- Are changes concentrated in cross-vendor or independent-context passes?
- How correlated are supposed independent agents?
- When does another agent add insight, and when does it merely add text?

### 13.5 Cost and calm

Measure the resources consumed by the Practice:

- context and token cost;
- gate runtime;
- human interruption;
- orientation time;
- failed loops;
- review rounds;
- corpus growth;
- time saved through remembered knowledge;
- work avoided through early reframing or refusal.

### 13.6 External causal chains

Select a small number of examples and trace:

```text
Practice change
  → changed agent behaviour
  → changed product decision
  → changed product capability
  → user / operational / institutional evidence
```

Only chains that cross this boundary support stronger claims about mission impact.

### 13.7 Cross-environment transfer

Apply selected Practice mechanisms in a different repository or domain.

If the mechanisms survive with little local doctrine, that supports a more general theory.
If they require OCE's entire conceptual history, the portability claim should narrow.

---

## 14. Implications for understanding Jim's role

The current evidence suggests a role different from conventional engineering management
and different from solitary technical authorship.

Jim increasingly operates by:

- selecting and reframing consequential questions;
- allocating attention to research;
- creating conditions for multiple forms of cognition to participate;
- providing intent and value judgement;
- deciding which theories become operative;
- refusing or removing mechanisms whose evidence does not justify their cost;
- turning useful cognitive moves into reusable infrastructure;
- asking the infrastructure to investigate its own effectiveness;
- comparing resulting behaviour with the intended effect;
- changing the environment for the next round.

The repository does **not** show that Jim personally performs every step. The point is the
opposite: leverage increasingly comes from changing the system in which many later steps
are performed by other people and agents.

This is why "researcher", "Principal Engineer", "systems thinker" and "AI leader" each
capture only a slice.

The distinctive activity is closer to **designing and participating in systems that
improve how systems are researched, decided, created and revised**.

That formulation should still be demonstrated through examples rather than used as an
unsupported title.

---

## 15. Participant annotation: the minds question

Jim's childhood fascination with constructed minds belongs in this report because it
changes the interpretation of the present work, but it must remain explicitly labelled as
participant context.

His remembered questions include:

- Can cognition be understood or constructed top-down from a model of biological mind?
- Can machine intelligence emerge bottom-up from fleets of simple automata?
- Can a top-down cognitive architecture be realised through fleets of bottom-up automata,
  themselves organised into larger fleets?

The current agentic environment finally makes variants of these questions experimentally
accessible at a practical scale.

A high-level intention can be represented explicitly. Many local cognitive processes can
operate with bounded information and partial autonomy. Persistent environmental structures
can shape those processes. Their output can alter the structures that shape later output.

That resemblance is intellectually important.

It should not be allowed to jump the evidential gap from "structurally reminiscent of a
long-standing model of constructed cognition" to "we have constructed a mind".

A productive research question is instead:

> Which properties of cognition and intelligent organisation emerge usefully from the
> interaction of top-down intent, bottom-up agent activity, persistent environmental
> structure, memory, feedback, selection, inhibition and recursive self-modification?

OCE is now capable of supplying empirical material for that question.

---

## 16. Closing synthesis

OCE began as software work and still produces software. But the boundary of the engineered
system has expanded.

The repository increasingly carries not only product state but research state, decision
history, operational memory, cognitive methods and mechanisms for changing those methods.

The Practice increasingly embodies theories about how people and agents should frame,
reason, decide, coordinate, verify, remember, forget and learn.

The wider ensemble increasingly uses those theories, produces evidence about them, changes
them, and sometimes develops new mechanisms for deciding how they should be changed.

The most important transition is therefore not:

```text
repository → sophisticated repository
```

It is closer to:

```text
build things
  → build systems that make building better
  → build systems that make deciding and learning better
  → observe failures in those systems
  → build and revise mechanisms for improving the improvement process
  → begin testing whether those recursive mechanisms produce better downstream outcomes
```

The underlying leverage intuition is much older than this repository according to Jim's
participant account. What is new is the substrate.

Contemporary AI agents, persistent repository memory, executable governance and public
digital infrastructure have made it possible to explore a question that previously lived
mainly as philosophy, instinct and small-scale engineering practice:

> What happens when a heterogeneous system can participate in improving the machinery by
> which it learns, frames questions, makes decisions, creates systems and decides how to
> improve that machinery again?

OCE does not yet answer that question.

It is becoming a place where the question can be investigated.

---

## Source notes

This report builds primarily on the companion `oce-longitudinal-self-study-source-material.md`,
the current conversation's participant annotations, and current/pinned OCE sources.

Key repository sources:

- [PDR-029 — Perturbation-Mechanism Bundle][PDR-029]
- [PDR-069 — Doctrine-first vs first-principles diversity][PDR-069]
- [PDR-098 — Doctrine Traction][PDR-098]
- [PDR-123 — Agentic Design Panel Protocol][PDR-123]
- [PDR-130 — Two-Speed Learning][PDR-130]
- [Concept Exploration skill][Concept-Exploration]
- [Planning skill][Plan-Skill]
- the Parallax skill and evaluation corpus under `.agent/skills/parallax*`
- `oce-longitudinal-self-study-source-material.md`
- `jim-cresswell-cv-linkedin-evidence-and-language.md`

[PDR-029]: https://github.com/oaknational/oak-open-curriculum-ecosystem/blob/6b36bdf63642c944c767729de296379f8e1955ef/.agent/practice-core/decision-records/PDR-029-perturbation-mechanism-bundle.md
[PDR-069]: https://github.com/oaknational/oak-open-curriculum-ecosystem/blob/6b36bdf63642c944c767729de296379f8e1955ef/.agent/practice-core/decision-records/PDR-069-doctrine-first-vs-first-principles-diversity.md
[PDR-098]: https://github.com/oaknational/oak-open-curriculum-ecosystem/blob/6b36bdf63642c944c767729de296379f8e1955ef/.agent/practice-core/decision-records/PDR-098-doctrine-traction-firing-detection-response.md
[PDR-123]: https://github.com/oaknational/oak-open-curriculum-ecosystem/blob/6b36bdf63642c944c767729de296379f8e1955ef/.agent/practice-core/decision-records/PDR-123-agentic-design-panel-protocol.md
[PDR-130]: https://github.com/oaknational/oak-open-curriculum-ecosystem/blob/6b36bdf63642c944c767729de296379f8e1955ef/.agent/practice-core/decision-records/PDR-130-two-speed-learning.md
[Concept-Exploration]: https://github.com/oaknational/oak-open-curriculum-ecosystem/blob/6b36bdf63642c944c767729de296379f8e1955ef/.agent/skills/concept-exploration/SKILL-CANONICAL.md
[Plan-Skill]: https://github.com/oaknational/oak-open-curriculum-ecosystem/blob/6b36bdf63642c944c767729de296379f8e1955ef/.agent/skills/plan/SKILL-CANONICAL.md
