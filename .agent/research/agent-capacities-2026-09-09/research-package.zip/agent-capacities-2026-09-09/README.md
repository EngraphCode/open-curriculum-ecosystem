# Adaptive capacities in agents, teams and institutions

A structured critical literature review and experimental programme, 9 September 2026.

[Read the complete report](report.md) · [Sources, limitations and continuation](source-index.md) · [Framework](framework.md) · [Editable matrix](comparison-matrix.csv) · [Twelve experimental families](experimental-programme.md)

The report includes the full framework, experimental programme, method and provenance appendices. Move this entire folder to preserve its frozen private and repository source snapshots. External literature remains identified by citations. This package contains private research material; no publication or repository change has been performed.

Status: research deliverables complete with explicitly bounded source access. Experiments are proposals and have not been executed. The repository evidence is pinned to EngraphCode/open-curriculum-ecosystem commit `123d2e3e9878b520c7fe1c51a39a8c1f324c1091`.
